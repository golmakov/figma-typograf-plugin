/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/code.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/text-diff/diff.js":
/*!****************************************!*\
  !*** ./node_modules/text-diff/diff.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * This library was modified by Harrison Liddiard. The source code to this
 * modified version can be found at https://github.com/liddiard/google-diff/.
 * The original source code can be found at
 * http://code.google.com/p/google-diff-match-patch/. This unofficial fork is
 * not maintained by or affiliated with Google Inc. The original attribution
 * and licensing information follows.
 */

/**
 * Diff Match and Patch
 *
 * Copyright 2006 Google Inc.
 * http://code.google.com/p/google-diff-match-patch/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @fileoverview Computes the difference between two texts to create a patch.
 * Applies the patch onto another text, allowing for errors.
 * @author fraser@google.com (Neil Fraser)
 */

/**
 * Class containing the diff.
 * @constructor
 */
function diff(options) {
  var options = options || {};

  // Defaults.
  // Redefine these in your program to override the defaults.

  // Number of seconds to map a diff before giving up (0 for infinity).
  this.Timeout = options.timeout || 1.0;
  // Cost of an empty edit operation in terms of edit characters.
  this.EditCost = options.editCost || 4;
}


//  DIFF FUNCTIONS


/**
 * The data structure representing a diff is an array of tuples:
 * [[DIFF_DELETE, 'Hello'], [DIFF_INSERT, 'Goodbye'], [DIFF_EQUAL, ' world.']]
 * which means: delete 'Hello', add 'Goodbye' and keep ' world.'
 */
var DIFF_DELETE = -1;
var DIFF_INSERT = 1;
var DIFF_EQUAL = 0;

/** @typedef {{0: number, 1: string}} */
diff.Diff;


/**
 * Find the differences between two texts.  Simplifies the problem by stripping
 * any common prefix or suffix off the texts before diffing.
 * @param {string} text1 Old string to be diffed.
 * @param {string} text2 New string to be diffed.
 * @param {boolean=} opt_checklines Optional speedup flag. If present and false,
 *     then don't run a line-level diff first to identify the changed areas.
 *     Defaults to true, which does a faster, slightly less optimal diff.
 * @param {number} opt_deadline Optional time when the diff should be complete
 *     by.  Used internally for recursive calls.  Users should set DiffTimeout
 *     instead.
 * @return {!Array.<!diff.Diff>} Array of diff tuples.
 */
diff.prototype.main = function(text1, text2, opt_checklines,
    opt_deadline) {
  // Set a deadline by which time the diff must be complete.
  if (typeof opt_deadline == 'undefined') {
    if (this.Timeout <= 0) {
      opt_deadline = Number.MAX_VALUE;
    } else {
      opt_deadline = (new Date).getTime() + this.Timeout * 1000;
    }
  }
  var deadline = opt_deadline;

  // Check for null inputs.
  if (text1 == null || text2 == null) {
    throw new Error('Null input. (diff_main)');
  }

  // Check for equality (speedup).
  if (text1 == text2) {
    if (text1) {
      return [[DIFF_EQUAL, text1]];
    }
    return [];
  }

  if (typeof opt_checklines == 'undefined') {
    opt_checklines = true;
  }
  var checklines = opt_checklines;

  // Trim off common prefix (speedup).
  var commonlength = this.commonPrefix(text1, text2);
  var commonprefix = text1.substring(0, commonlength);
  text1 = text1.substring(commonlength);
  text2 = text2.substring(commonlength);

  // Trim off common suffix (speedup).
  commonlength = this.commonSuffix(text1, text2);
  var commonsuffix = text1.substring(text1.length - commonlength);
  text1 = text1.substring(0, text1.length - commonlength);
  text2 = text2.substring(0, text2.length - commonlength);

  // Compute the diff on the middle block.
  var diffs = this.compute_(text1, text2, checklines, deadline);

  // Restore the prefix and suffix.
  if (commonprefix) {
    diffs.unshift([DIFF_EQUAL, commonprefix]);
  }
  if (commonsuffix) {
    diffs.push([DIFF_EQUAL, commonsuffix]);
  }
  this.cleanupMerge(diffs);
  return diffs;
};


/**
 * Find the differences between two texts.  Assumes that the texts do not
 * have any common prefix or suffix.
 * @param {string} text1 Old string to be diffed.
 * @param {string} text2 New string to be diffed.
 * @param {boolean} checklines Speedup flag.  If false, then don't run a
 *     line-level diff first to identify the changed areas.
 *     If true, then run a faster, slightly less optimal diff.
 * @param {number} deadline Time when the diff should be complete by.
 * @return {!Array.<!diff.Diff>} Array of diff tuples.
 * @private
 */
diff.prototype.compute_ = function(text1, text2, checklines,
    deadline) {
  var diffs;

  if (!text1) {
    // Just add some text (speedup).
    return [[DIFF_INSERT, text2]];
  }

  if (!text2) {
    // Just delete some text (speedup).
    return [[DIFF_DELETE, text1]];
  }

  var longtext = text1.length > text2.length ? text1 : text2;
  var shorttext = text1.length > text2.length ? text2 : text1;
  var i = longtext.indexOf(shorttext);
  if (i != -1) {
    // Shorter text is inside the longer text (speedup).
    diffs = [[DIFF_INSERT, longtext.substring(0, i)],
             [DIFF_EQUAL, shorttext],
             [DIFF_INSERT, longtext.substring(i + shorttext.length)]];
    // Swap insertions for deletions if diff is reversed.
    if (text1.length > text2.length) {
      diffs[0][0] = diffs[2][0] = DIFF_DELETE;
    }
    return diffs;
  }

  if (shorttext.length == 1) {
    // Single character string.
    // After the previous speedup, the character can't be an equality.
    return [[DIFF_DELETE, text1], [DIFF_INSERT, text2]];
  }

  // Check to see if the problem can be split in two.
  var hm = this.halfMatch_(text1, text2);
  if (hm) {
    // A half-match was found, sort out the return data.
    var text1_a = hm[0];
    var text1_b = hm[1];
    var text2_a = hm[2];
    var text2_b = hm[3];
    var mid_common = hm[4];
    // Send both pairs off for separate processing.
    var diffs_a = this.main(text1_a, text2_a, checklines, deadline);
    var diffs_b = this.main(text1_b, text2_b, checklines, deadline);
    // Merge the results.
    return diffs_a.concat([[DIFF_EQUAL, mid_common]], diffs_b);
  }

  if (checklines && text1.length > 100 && text2.length > 100) {
    return this.lineMode_(text1, text2, deadline);
  }

  return this.bisect_(text1, text2, deadline);
};


/**
 * Do a quick line-level diff on both strings, then rediff the parts for
 * greater accuracy.
 * This speedup can produce non-minimal diffs.
 * @param {string} text1 Old string to be diffed.
 * @param {string} text2 New string to be diffed.
 * @param {number} deadline Time when the diff should be complete by.
 * @return {!Array.<!diff.Diff>} Array of diff tuples.
 * @private
 */
diff.prototype.lineMode_ = function(text1, text2, deadline) {
  // Scan the text on a line-by-line basis first.
  var a = this.linesToChars_(text1, text2);
  text1 = a.chars1;
  text2 = a.chars2;
  var linearray = a.lineArray;

  var diffs = this.main(text1, text2, false, deadline);

  // Convert the diff back to original text.
  this.charsToLines_(diffs, linearray);
  // Eliminate freak matches (e.g. blank lines)
  this.cleanupSemantic(diffs);

  // Rediff any replacement blocks, this time character-by-character.
  // Add a dummy entry at the end.
  diffs.push([DIFF_EQUAL, '']);
  var pointer = 0;
  var count_delete = 0;
  var count_insert = 0;
  var text_delete = '';
  var text_insert = '';
  while (pointer < diffs.length) {
    switch (diffs[pointer][0]) {
      case DIFF_INSERT:
        count_insert++;
        text_insert += diffs[pointer][1];
        break;
      case DIFF_DELETE:
        count_delete++;
        text_delete += diffs[pointer][1];
        break;
      case DIFF_EQUAL:
        // Upon reaching an equality, check for prior redundancies.
        if (count_delete >= 1 && count_insert >= 1) {
          // Delete the offending records and add the merged ones.
          diffs.splice(pointer - count_delete - count_insert,
                       count_delete + count_insert);
          pointer = pointer - count_delete - count_insert;
          var a = this.main(text_delete, text_insert, false, deadline);
          for (var j = a.length - 1; j >= 0; j--) {
            diffs.splice(pointer, 0, a[j]);
          }
          pointer = pointer + a.length;
        }
        count_insert = 0;
        count_delete = 0;
        text_delete = '';
        text_insert = '';
        break;
    }
    pointer++;
  }
  diffs.pop();  // Remove the dummy entry at the end.

  return diffs;
};


/**
 * Find the 'middle snake' of a diff, split the problem in two
 * and return the recursively constructed diff.
 * See Myers 1986 paper: An O(ND) Difference Algorithm and Its Variations.
 * @param {string} text1 Old string to be diffed.
 * @param {string} text2 New string to be diffed.
 * @param {number} deadline Time at which to bail if not yet complete.
 * @return {!Array.<!diff.Diff>} Array of diff tuples.
 * @private
 */
diff.prototype.bisect_ = function(text1, text2, deadline) {
  // Cache the text lengths to prevent multiple calls.
  var text1_length = text1.length;
  var text2_length = text2.length;
  var max_d = Math.ceil((text1_length + text2_length) / 2);
  var v_offset = max_d;
  var v_length = 2 * max_d;
  var v1 = new Array(v_length);
  var v2 = new Array(v_length);
  // Setting all elements to -1 is faster in Chrome & Firefox than mixing
  // integers and undefined.
  for (var x = 0; x < v_length; x++) {
    v1[x] = -1;
    v2[x] = -1;
  }
  v1[v_offset + 1] = 0;
  v2[v_offset + 1] = 0;
  var delta = text1_length - text2_length;
  // If the total number of characters is odd, then the front path will collide
  // with the reverse path.
  var front = (delta % 2 != 0);
  // Offsets for start and end of k loop.
  // Prevents mapping of space beyond the grid.
  var k1start = 0;
  var k1end = 0;
  var k2start = 0;
  var k2end = 0;
  for (var d = 0; d < max_d; d++) {
    // Bail out if deadline is reached.
    if ((new Date()).getTime() > deadline) {
      break;
    }

    // Walk the front path one step.
    for (var k1 = -d + k1start; k1 <= d - k1end; k1 += 2) {
      var k1_offset = v_offset + k1;
      var x1;
      if (k1 == -d || (k1 != d && v1[k1_offset - 1] < v1[k1_offset + 1])) {
        x1 = v1[k1_offset + 1];
      } else {
        x1 = v1[k1_offset - 1] + 1;
      }
      var y1 = x1 - k1;
      while (x1 < text1_length && y1 < text2_length &&
             text1.charAt(x1) == text2.charAt(y1)) {
        x1++;
        y1++;
      }
      v1[k1_offset] = x1;
      if (x1 > text1_length) {
        // Ran off the right of the graph.
        k1end += 2;
      } else if (y1 > text2_length) {
        // Ran off the bottom of the graph.
        k1start += 2;
      } else if (front) {
        var k2_offset = v_offset + delta - k1;
        if (k2_offset >= 0 && k2_offset < v_length && v2[k2_offset] != -1) {
          // Mirror x2 onto top-left coordinate system.
          var x2 = text1_length - v2[k2_offset];
          if (x1 >= x2) {
            // Overlap detected.
            return this.bisectSplit_(text1, text2, x1, y1, deadline);
          }
        }
      }
    }

    // Walk the reverse path one step.
    for (var k2 = -d + k2start; k2 <= d - k2end; k2 += 2) {
      var k2_offset = v_offset + k2;
      var x2;
      if (k2 == -d || (k2 != d && v2[k2_offset - 1] < v2[k2_offset + 1])) {
        x2 = v2[k2_offset + 1];
      } else {
        x2 = v2[k2_offset - 1] + 1;
      }
      var y2 = x2 - k2;
      while (x2 < text1_length && y2 < text2_length &&
             text1.charAt(text1_length - x2 - 1) ==
             text2.charAt(text2_length - y2 - 1)) {
        x2++;
        y2++;
      }
      v2[k2_offset] = x2;
      if (x2 > text1_length) {
        // Ran off the left of the graph.
        k2end += 2;
      } else if (y2 > text2_length) {
        // Ran off the top of the graph.
        k2start += 2;
      } else if (!front) {
        var k1_offset = v_offset + delta - k2;
        if (k1_offset >= 0 && k1_offset < v_length && v1[k1_offset] != -1) {
          var x1 = v1[k1_offset];
          var y1 = v_offset + x1 - k1_offset;
          // Mirror x2 onto top-left coordinate system.
          x2 = text1_length - x2;
          if (x1 >= x2) {
            // Overlap detected.
            return this.bisectSplit_(text1, text2, x1, y1, deadline);
          }
        }
      }
    }
  }
  // Diff took too long and hit the deadline or
  // number of diffs equals number of characters, no commonality at all.
  return [[DIFF_DELETE, text1], [DIFF_INSERT, text2]];
};


/**
 * Given the location of the 'middle snake', split the diff in two parts
 * and recurse.
 * @param {string} text1 Old string to be diffed.
 * @param {string} text2 New string to be diffed.
 * @param {number} x Index of split point in text1.
 * @param {number} y Index of split point in text2.
 * @param {number} deadline Time at which to bail if not yet complete.
 * @return {!Array.<!diff.Diff>} Array of diff tuples.
 * @private
 */
diff.prototype.bisectSplit_ = function(text1, text2, x, y,
    deadline) {
  var text1a = text1.substring(0, x);
  var text2a = text2.substring(0, y);
  var text1b = text1.substring(x);
  var text2b = text2.substring(y);

  // Compute both diffs serially.
  var diffs = this.main(text1a, text2a, false, deadline);
  var diffsb = this.main(text1b, text2b, false, deadline);

  return diffs.concat(diffsb);
};


/**
 * Split two texts into an array of strings.  Reduce the texts to a string of
 * hashes where each Unicode character represents one line.
 * @param {string} text1 First string.
 * @param {string} text2 Second string.
 * @return {{chars1: string, chars2: string, lineArray: !Array.<string>}}
 *     An object containing the encoded text1, the encoded text2 and
 *     the array of unique strings.
 *     The zeroth element of the array of unique strings is intentionally blank.
 * @private
 */
diff.prototype.linesToChars_ = function(text1, text2) {
  var lineArray = [];  // e.g. lineArray[4] == 'Hello\n'
  var lineHash = {};   // e.g. lineHash['Hello\n'] == 4

  // '\x00' is a valid character, but various debuggers don't like it.
  // So we'll insert a junk entry to avoid generating a null character.
  lineArray[0] = '';

  /**
   * Split a text into an array of strings.  Reduce the texts to a string of
   * hashes where each Unicode character represents one line.
   * Modifies linearray and linehash through being a closure.
   * @param {string} text String to encode.
   * @return {string} Encoded string.
   * @private
   */
  function diff_linesToCharsMunge_(text) {
    var chars = '';
    // Walk the text, pulling out a substring for each line.
    // text.split('\n') would would temporarily double our memory footprint.
    // Modifying text would create many large strings to garbage collect.
    var lineStart = 0;
    var lineEnd = -1;
    // Keeping our own length variable is faster than looking it up.
    var lineArrayLength = lineArray.length;
    while (lineEnd < text.length - 1) {
      lineEnd = text.indexOf('\n', lineStart);
      if (lineEnd == -1) {
        lineEnd = text.length - 1;
      }
      var line = text.substring(lineStart, lineEnd + 1);
      lineStart = lineEnd + 1;

      if (lineHash.hasOwnProperty ? lineHash.hasOwnProperty(line) :
          (lineHash[line] !== undefined)) {
        chars += String.fromCharCode(lineHash[line]);
      } else {
        chars += String.fromCharCode(lineArrayLength);
        lineHash[line] = lineArrayLength;
        lineArray[lineArrayLength++] = line;
      }
    }
    return chars;
  }

  var chars1 = diff_linesToCharsMunge_(text1);
  var chars2 = diff_linesToCharsMunge_(text2);
  return {chars1: chars1, chars2: chars2, lineArray: lineArray};
};


/**
 * Rehydrate the text in a diff from a string of line hashes to real lines of
 * text.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 * @param {!Array.<string>} lineArray Array of unique strings.
 * @private
 */
diff.prototype.charsToLines_ = function(diffs, lineArray) {
  for (var x = 0; x < diffs.length; x++) {
    var chars = diffs[x][1];
    var text = [];
    for (var y = 0; y < chars.length; y++) {
      text[y] = lineArray[chars.charCodeAt(y)];
    }
    diffs[x][1] = text.join('');
  }
};


/**
 * Determine the common prefix of two strings.
 * @param {string} text1 First string.
 * @param {string} text2 Second string.
 * @return {number} The number of characters common to the start of each
 *     string.
 */
diff.prototype.commonPrefix = function(text1, text2) {
  // Quick check for common null cases.
  if (!text1 || !text2 || text1.charAt(0) != text2.charAt(0)) {
    return 0;
  }
  // Binary search.
  // Performance analysis: http://neil.fraser.name/news/2007/10/09/
  var pointermin = 0;
  var pointermax = Math.min(text1.length, text2.length);
  var pointermid = pointermax;
  var pointerstart = 0;
  while (pointermin < pointermid) {
    if (text1.substring(pointerstart, pointermid) ==
        text2.substring(pointerstart, pointermid)) {
      pointermin = pointermid;
      pointerstart = pointermin;
    } else {
      pointermax = pointermid;
    }
    pointermid = Math.floor((pointermax - pointermin) / 2 + pointermin);
  }
  return pointermid;
};


/**
 * Determine the common suffix of two strings.
 * @param {string} text1 First string.
 * @param {string} text2 Second string.
 * @return {number} The number of characters common to the end of each string.
 */
diff.prototype.commonSuffix = function(text1, text2) {
  // Quick check for common null cases.
  if (!text1 || !text2 ||
      text1.charAt(text1.length - 1) != text2.charAt(text2.length - 1)) {
    return 0;
  }
  // Binary search.
  // Performance analysis: http://neil.fraser.name/news/2007/10/09/
  var pointermin = 0;
  var pointermax = Math.min(text1.length, text2.length);
  var pointermid = pointermax;
  var pointerend = 0;
  while (pointermin < pointermid) {
    if (text1.substring(text1.length - pointermid, text1.length - pointerend) ==
        text2.substring(text2.length - pointermid, text2.length - pointerend)) {
      pointermin = pointermid;
      pointerend = pointermin;
    } else {
      pointermax = pointermid;
    }
    pointermid = Math.floor((pointermax - pointermin) / 2 + pointermin);
  }
  return pointermid;
};


/**
 * Determine if the suffix of one string is the prefix of another.
 * @param {string} text1 First string.
 * @param {string} text2 Second string.
 * @return {number} The number of characters common to the end of the first
 *     string and the start of the second string.
 * @private
 */
diff.prototype.commonOverlap_ = function(text1, text2) {
  // Cache the text lengths to prevent multiple calls.
  var text1_length = text1.length;
  var text2_length = text2.length;
  // Eliminate the null case.
  if (text1_length == 0 || text2_length == 0) {
    return 0;
  }
  // Truncate the longer string.
  if (text1_length > text2_length) {
    text1 = text1.substring(text1_length - text2_length);
  } else if (text1_length < text2_length) {
    text2 = text2.substring(0, text1_length);
  }
  var text_length = Math.min(text1_length, text2_length);
  // Quick check for the worst case.
  if (text1 == text2) {
    return text_length;
  }

  // Start by looking for a single character match
  // and increase length until no match is found.
  // Performance analysis: http://neil.fraser.name/news/2010/11/04/
  var best = 0;
  var length = 1;
  while (true) {
    var pattern = text1.substring(text_length - length);
    var found = text2.indexOf(pattern);
    if (found == -1) {
      return best;
    }
    length += found;
    if (found == 0 || text1.substring(text_length - length) ==
        text2.substring(0, length)) {
      best = length;
      length++;
    }
  }
};


/**
 * Do the two texts share a substring which is at least half the length of the
 * longer text?
 * This speedup can produce non-minimal diffs.
 * @param {string} text1 First string.
 * @param {string} text2 Second string.
 * @return {Array.<string>} Five element Array, containing the prefix of
 *     text1, the suffix of text1, the prefix of text2, the suffix of
 *     text2 and the common middle.  Or null if there was no match.
 * @private
 */
diff.prototype.halfMatch_ = function(text1, text2) {
  if (this.Timeout <= 0) {
    // Don't risk returning a non-optimal diff if we have unlimited time.
    return null;
  }
  var longtext = text1.length > text2.length ? text1 : text2;
  var shorttext = text1.length > text2.length ? text2 : text1;
  if (longtext.length < 4 || shorttext.length * 2 < longtext.length) {
    return null;  // Pointless.
  }
  var dmp = this;  // 'this' becomes 'window' in a closure.

  /**
   * Does a substring of shorttext exist within longtext such that the substring
   * is at least half the length of longtext?
   * Closure, but does not reference any external variables.
   * @param {string} longtext Longer string.
   * @param {string} shorttext Shorter string.
   * @param {number} i Start index of quarter length substring within longtext.
   * @return {Array.<string>} Five element Array, containing the prefix of
   *     longtext, the suffix of longtext, the prefix of shorttext, the suffix
   *     of shorttext and the common middle.  Or null if there was no match.
   * @private
   */
  function diff_halfMatchI_(longtext, shorttext, i) {
    // Start with a 1/4 length substring at position i as a seed.
    var seed = longtext.substring(i, i + Math.floor(longtext.length / 4));
    var j = -1;
    var best_common = '';
    var best_longtext_a, best_longtext_b, best_shorttext_a, best_shorttext_b;
    while ((j = shorttext.indexOf(seed, j + 1)) != -1) {
      var prefixLength = dmp.commonPrefix(longtext.substring(i),
                                          shorttext.substring(j));
      var suffixLength = dmp.commonSuffix(longtext.substring(0, i),
                                          shorttext.substring(0, j));
      if (best_common.length < suffixLength + prefixLength) {
        best_common = shorttext.substring(j - suffixLength, j) +
            shorttext.substring(j, j + prefixLength);
        best_longtext_a = longtext.substring(0, i - suffixLength);
        best_longtext_b = longtext.substring(i + prefixLength);
        best_shorttext_a = shorttext.substring(0, j - suffixLength);
        best_shorttext_b = shorttext.substring(j + prefixLength);
      }
    }
    if (best_common.length * 2 >= longtext.length) {
      return [best_longtext_a, best_longtext_b,
              best_shorttext_a, best_shorttext_b, best_common];
    } else {
      return null;
    }
  }

  // First check if the second quarter is the seed for a half-match.
  var hm1 = diff_halfMatchI_(longtext, shorttext,
                             Math.ceil(longtext.length / 4));
  // Check again based on the third quarter.
  var hm2 = diff_halfMatchI_(longtext, shorttext,
                             Math.ceil(longtext.length / 2));
  var hm;
  if (!hm1 && !hm2) {
    return null;
  } else if (!hm2) {
    hm = hm1;
  } else if (!hm1) {
    hm = hm2;
  } else {
    // Both matched.  Select the longest.
    hm = hm1[4].length > hm2[4].length ? hm1 : hm2;
  }

  // A half-match was found, sort out the return data.
  var text1_a, text1_b, text2_a, text2_b;
  if (text1.length > text2.length) {
    text1_a = hm[0];
    text1_b = hm[1];
    text2_a = hm[2];
    text2_b = hm[3];
  } else {
    text2_a = hm[0];
    text2_b = hm[1];
    text1_a = hm[2];
    text1_b = hm[3];
  }
  var mid_common = hm[4];
  return [text1_a, text1_b, text2_a, text2_b, mid_common];
};


/**
 * Reduce the number of edits by eliminating semantically trivial equalities.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 */
diff.prototype.cleanupSemantic = function(diffs) {
  var changes = false;
  var equalities = [];  // Stack of indices where equalities are found.
  var equalitiesLength = 0;  // Keeping our own length var is faster in JS.
  /** @type {?string} */
  var lastequality = null;
  // Always equal to diffs[equalities[equalitiesLength - 1]][1]
  var pointer = 0;  // Index of current position.
  // Number of characters that changed prior to the equality.
  var length_insertions1 = 0;
  var length_deletions1 = 0;
  // Number of characters that changed after the equality.
  var length_insertions2 = 0;
  var length_deletions2 = 0;
  while (pointer < diffs.length) {
    if (diffs[pointer][0] == DIFF_EQUAL) {  // Equality found.
      equalities[equalitiesLength++] = pointer;
      length_insertions1 = length_insertions2;
      length_deletions1 = length_deletions2;
      length_insertions2 = 0;
      length_deletions2 = 0;
      lastequality = diffs[pointer][1];
    } else {  // An insertion or deletion.
      if (diffs[pointer][0] == DIFF_INSERT) {
        length_insertions2 += diffs[pointer][1].length;
      } else {
        length_deletions2 += diffs[pointer][1].length;
      }
      // Eliminate an equality that is smaller or equal to the edits on both
      // sides of it.
      if (lastequality && (lastequality.length <=
          Math.max(length_insertions1, length_deletions1)) &&
          (lastequality.length <= Math.max(length_insertions2,
                                           length_deletions2))) {
        // Duplicate record.
        diffs.splice(equalities[equalitiesLength - 1], 0,
                     [DIFF_DELETE, lastequality]);
        // Change second copy to insert.
        diffs[equalities[equalitiesLength - 1] + 1][0] = DIFF_INSERT;
        // Throw away the equality we just deleted.
        equalitiesLength--;
        // Throw away the previous equality (it needs to be reevaluated).
        equalitiesLength--;
        pointer = equalitiesLength > 0 ? equalities[equalitiesLength - 1] : -1;
        length_insertions1 = 0;  // Reset the counters.
        length_deletions1 = 0;
        length_insertions2 = 0;
        length_deletions2 = 0;
        lastequality = null;
        changes = true;
      }
    }
    pointer++;
  }

  // Normalize the diff.
  if (changes) {
    this.cleanupMerge(diffs);
  }
  this.cleanupSemanticLossless(diffs);

  // Find any overlaps between deletions and insertions.
  // e.g: <del>abcxxx</del><ins>xxxdef</ins>
  //   -> <del>abc</del>xxx<ins>def</ins>
  // e.g: <del>xxxabc</del><ins>defxxx</ins>
  //   -> <ins>def</ins>xxx<del>abc</del>
  // Only extract an overlap if it is as big as the edit ahead or behind it.
  pointer = 1;
  while (pointer < diffs.length) {
    if (diffs[pointer - 1][0] == DIFF_DELETE &&
        diffs[pointer][0] == DIFF_INSERT) {
      var deletion = diffs[pointer - 1][1];
      var insertion = diffs[pointer][1];
      var overlap_length1 = this.commonOverlap_(deletion, insertion);
      var overlap_length2 = this.commonOverlap_(insertion, deletion);
      if (overlap_length1 >= overlap_length2) {
        if (overlap_length1 >= deletion.length / 2 ||
            overlap_length1 >= insertion.length / 2) {
          // Overlap found.  Insert an equality and trim the surrounding edits.
          diffs.splice(pointer, 0,
              [DIFF_EQUAL, insertion.substring(0, overlap_length1)]);
          diffs[pointer - 1][1] =
              deletion.substring(0, deletion.length - overlap_length1);
          diffs[pointer + 1][1] = insertion.substring(overlap_length1);
          pointer++;
        }
      } else {
        if (overlap_length2 >= deletion.length / 2 ||
            overlap_length2 >= insertion.length / 2) {
          // Reverse overlap found.
          // Insert an equality and swap and trim the surrounding edits.
          diffs.splice(pointer, 0,
              [DIFF_EQUAL, deletion.substring(0, overlap_length2)]);
          diffs[pointer - 1][0] = DIFF_INSERT;
          diffs[pointer - 1][1] =
              insertion.substring(0, insertion.length - overlap_length2);
          diffs[pointer + 1][0] = DIFF_DELETE;
          diffs[pointer + 1][1] =
              deletion.substring(overlap_length2);
          pointer++;
        }
      }
      pointer++;
    }
    pointer++;
  }
};


/**
 * Look for single edits surrounded on both sides by equalities
 * which can be shifted sideways to align the edit to a word boundary.
 * e.g: The c<ins>at c</ins>ame. -> The <ins>cat </ins>came.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 */
diff.prototype.cleanupSemanticLossless = function(diffs) {
  /**
   * Given two strings, compute a score representing whether the internal
   * boundary falls on logical boundaries.
   * Scores range from 6 (best) to 0 (worst).
   * Closure, but does not reference any external variables.
   * @param {string} one First string.
   * @param {string} two Second string.
   * @return {number} The score.
   * @private
   */
  function diff_cleanupSemanticScore_(one, two) {
    if (!one || !two) {
      // Edges are the best.
      return 6;
    }

    // Each port of this function behaves slightly differently due to
    // subtle differences in each language's definition of things like
    // 'whitespace'.  Since this function's purpose is largely cosmetic,
    // the choice has been made to use each language's native features
    // rather than force total conformity.
    var char1 = one.charAt(one.length - 1);
    var char2 = two.charAt(0);
    var nonAlphaNumeric1 = char1.match(diff.nonAlphaNumericRegex_);
    var nonAlphaNumeric2 = char2.match(diff.nonAlphaNumericRegex_);
    var whitespace1 = nonAlphaNumeric1 &&
        char1.match(diff.whitespaceRegex_);
    var whitespace2 = nonAlphaNumeric2 &&
        char2.match(diff.whitespaceRegex_);
    var lineBreak1 = whitespace1 &&
        char1.match(diff.linebreakRegex_);
    var lineBreak2 = whitespace2 &&
        char2.match(diff.linebreakRegex_);
    var blankLine1 = lineBreak1 &&
        one.match(diff.blanklineEndRegex_);
    var blankLine2 = lineBreak2 &&
        two.match(diff.blanklineStartRegex_);

    if (blankLine1 || blankLine2) {
      // Five points for blank lines.
      return 5;
    } else if (lineBreak1 || lineBreak2) {
      // Four points for line breaks.
      return 4;
    } else if (nonAlphaNumeric1 && !whitespace1 && whitespace2) {
      // Three points for end of sentences.
      return 3;
    } else if (whitespace1 || whitespace2) {
      // Two points for whitespace.
      return 2;
    } else if (nonAlphaNumeric1 || nonAlphaNumeric2) {
      // One point for non-alphanumeric.
      return 1;
    }
    return 0;
  }

  var pointer = 1;
  // Intentionally ignore the first and last element (don't need checking).
  while (pointer < diffs.length - 1) {
    if (diffs[pointer - 1][0] == DIFF_EQUAL &&
        diffs[pointer + 1][0] == DIFF_EQUAL) {
      // This is a single edit surrounded by equalities.
      var equality1 = diffs[pointer - 1][1];
      var edit = diffs[pointer][1];
      var equality2 = diffs[pointer + 1][1];

      // First, shift the edit as far left as possible.
      var commonOffset = this.commonSuffix(equality1, edit);
      if (commonOffset) {
        var commonString = edit.substring(edit.length - commonOffset);
        equality1 = equality1.substring(0, equality1.length - commonOffset);
        edit = commonString + edit.substring(0, edit.length - commonOffset);
        equality2 = commonString + equality2;
      }

      // Second, step character by character right, looking for the best fit.
      var bestEquality1 = equality1;
      var bestEdit = edit;
      var bestEquality2 = equality2;
      var bestScore = diff_cleanupSemanticScore_(equality1, edit) +
          diff_cleanupSemanticScore_(edit, equality2);
      while (edit.charAt(0) === equality2.charAt(0)) {
        equality1 += edit.charAt(0);
        edit = edit.substring(1) + equality2.charAt(0);
        equality2 = equality2.substring(1);
        var score = diff_cleanupSemanticScore_(equality1, edit) +
            diff_cleanupSemanticScore_(edit, equality2);
        // The >= encourages trailing rather than leading whitespace on edits.
        if (score >= bestScore) {
          bestScore = score;
          bestEquality1 = equality1;
          bestEdit = edit;
          bestEquality2 = equality2;
        }
      }

      if (diffs[pointer - 1][1] != bestEquality1) {
        // We have an improvement, save it back to the diff.
        if (bestEquality1) {
          diffs[pointer - 1][1] = bestEquality1;
        } else {
          diffs.splice(pointer - 1, 1);
          pointer--;
        }
        diffs[pointer][1] = bestEdit;
        if (bestEquality2) {
          diffs[pointer + 1][1] = bestEquality2;
        } else {
          diffs.splice(pointer + 1, 1);
          pointer--;
        }
      }
    }
    pointer++;
  }
};

// Define some regex patterns for matching boundaries.
diff.nonAlphaNumericRegex_ = /[^a-zA-Z0-9]/;
diff.whitespaceRegex_ = /\s/;
diff.linebreakRegex_ = /[\r\n]/;
diff.blanklineEndRegex_ = /\n\r?\n$/;
diff.blanklineStartRegex_ = /^\r?\n\r?\n/;

/**
 * Reduce the number of edits by eliminating operationally trivial equalities.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 */
diff.prototype.cleanupEfficiency = function(diffs) {
  var changes = false;
  var equalities = [];  // Stack of indices where equalities are found.
  var equalitiesLength = 0;  // Keeping our own length var is faster in JS.
  /** @type {?string} */
  var lastequality = null;
  // Always equal to diffs[equalities[equalitiesLength - 1]][1]
  var pointer = 0;  // Index of current position.
  // Is there an insertion operation before the last equality.
  var pre_ins = false;
  // Is there a deletion operation before the last equality.
  var pre_del = false;
  // Is there an insertion operation after the last equality.
  var post_ins = false;
  // Is there a deletion operation after the last equality.
  var post_del = false;
  while (pointer < diffs.length) {
    if (diffs[pointer][0] == DIFF_EQUAL) {  // Equality found.
      if (diffs[pointer][1].length < this.EditCost &&
          (post_ins || post_del)) {
        // Candidate found.
        equalities[equalitiesLength++] = pointer;
        pre_ins = post_ins;
        pre_del = post_del;
        lastequality = diffs[pointer][1];
      } else {
        // Not a candidate, and can never become one.
        equalitiesLength = 0;
        lastequality = null;
      }
      post_ins = post_del = false;
    } else {  // An insertion or deletion.
      if (diffs[pointer][0] == DIFF_DELETE) {
        post_del = true;
      } else {
        post_ins = true;
      }
      /*
       * Five types to be split:
       * <ins>A</ins><del>B</del>XY<ins>C</ins><del>D</del>
       * <ins>A</ins>X<ins>C</ins><del>D</del>
       * <ins>A</ins><del>B</del>X<ins>C</ins>
       * <ins>A</del>X<ins>C</ins><del>D</del>
       * <ins>A</ins><del>B</del>X<del>C</del>
       */
      if (lastequality && ((pre_ins && pre_del && post_ins && post_del) ||
                           ((lastequality.length < this.EditCost / 2) &&
                            (pre_ins + pre_del + post_ins + post_del) == 3))) {
        // Duplicate record.
        diffs.splice(equalities[equalitiesLength - 1], 0,
                     [DIFF_DELETE, lastequality]);
        // Change second copy to insert.
        diffs[equalities[equalitiesLength - 1] + 1][0] = DIFF_INSERT;
        equalitiesLength--;  // Throw away the equality we just deleted;
        lastequality = null;
        if (pre_ins && pre_del) {
          // No changes made which could affect previous entry, keep going.
          post_ins = post_del = true;
          equalitiesLength = 0;
        } else {
          equalitiesLength--;  // Throw away the previous equality.
          pointer = equalitiesLength > 0 ?
              equalities[equalitiesLength - 1] : -1;
          post_ins = post_del = false;
        }
        changes = true;
      }
    }
    pointer++;
  }

  if (changes) {
    this.cleanupMerge(diffs);
  }
};


/**
 * Reorder and merge like edit sections.  Merge equalities.
 * Any edit section can move as long as it doesn't cross an equality.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 */
diff.prototype.cleanupMerge = function(diffs) {
  diffs.push([DIFF_EQUAL, '']);  // Add a dummy entry at the end.
  var pointer = 0;
  var count_delete = 0;
  var count_insert = 0;
  var text_delete = '';
  var text_insert = '';
  var commonlength;
  while (pointer < diffs.length) {
    switch (diffs[pointer][0]) {
      case DIFF_INSERT:
        count_insert++;
        text_insert += diffs[pointer][1];
        pointer++;
        break;
      case DIFF_DELETE:
        count_delete++;
        text_delete += diffs[pointer][1];
        pointer++;
        break;
      case DIFF_EQUAL:
        // Upon reaching an equality, check for prior redundancies.
        if (count_delete + count_insert > 1) {
          if (count_delete !== 0 && count_insert !== 0) {
            // Factor out any common prefixies.
            commonlength = this.commonPrefix(text_insert, text_delete);
            if (commonlength !== 0) {
              if ((pointer - count_delete - count_insert) > 0 &&
                  diffs[pointer - count_delete - count_insert - 1][0] ==
                  DIFF_EQUAL) {
                diffs[pointer - count_delete - count_insert - 1][1] +=
                    text_insert.substring(0, commonlength);
              } else {
                diffs.splice(0, 0, [DIFF_EQUAL,
                                    text_insert.substring(0, commonlength)]);
                pointer++;
              }
              text_insert = text_insert.substring(commonlength);
              text_delete = text_delete.substring(commonlength);
            }
            // Factor out any common suffixies.
            commonlength = this.commonSuffix(text_insert, text_delete);
            if (commonlength !== 0) {
              diffs[pointer][1] = text_insert.substring(text_insert.length -
                  commonlength) + diffs[pointer][1];
              text_insert = text_insert.substring(0, text_insert.length -
                  commonlength);
              text_delete = text_delete.substring(0, text_delete.length -
                  commonlength);
            }
          }
          // Delete the offending records and add the merged ones.
          if (count_delete === 0) {
            diffs.splice(pointer - count_insert,
                count_delete + count_insert, [DIFF_INSERT, text_insert]);
          } else if (count_insert === 0) {
            diffs.splice(pointer - count_delete,
                count_delete + count_insert, [DIFF_DELETE, text_delete]);
          } else {
            diffs.splice(pointer - count_delete - count_insert,
                count_delete + count_insert, [DIFF_DELETE, text_delete],
                [DIFF_INSERT, text_insert]);
          }
          pointer = pointer - count_delete - count_insert +
                    (count_delete ? 1 : 0) + (count_insert ? 1 : 0) + 1;
        } else if (pointer !== 0 && diffs[pointer - 1][0] == DIFF_EQUAL) {
          // Merge this equality with the previous one.
          diffs[pointer - 1][1] += diffs[pointer][1];
          diffs.splice(pointer, 1);
        } else {
          pointer++;
        }
        count_insert = 0;
        count_delete = 0;
        text_delete = '';
        text_insert = '';
        break;
    }
  }
  if (diffs[diffs.length - 1][1] === '') {
    diffs.pop();  // Remove the dummy entry at the end.
  }

  // Second pass: look for single edits surrounded on both sides by equalities
  // which can be shifted sideways to eliminate an equality.
  // e.g: A<ins>BA</ins>C -> <ins>AB</ins>AC
  var changes = false;
  pointer = 1;
  // Intentionally ignore the first and last element (don't need checking).
  while (pointer < diffs.length - 1) {
    if (diffs[pointer - 1][0] == DIFF_EQUAL &&
        diffs[pointer + 1][0] == DIFF_EQUAL) {
      // This is a single edit surrounded by equalities.
      if (diffs[pointer][1].substring(diffs[pointer][1].length -
          diffs[pointer - 1][1].length) == diffs[pointer - 1][1]) {
        // Shift the edit over the previous equality.
        diffs[pointer][1] = diffs[pointer - 1][1] +
            diffs[pointer][1].substring(0, diffs[pointer][1].length -
                                        diffs[pointer - 1][1].length);
        diffs[pointer + 1][1] = diffs[pointer - 1][1] + diffs[pointer + 1][1];
        diffs.splice(pointer - 1, 1);
        changes = true;
      } else if (diffs[pointer][1].substring(0, diffs[pointer + 1][1].length) ==
          diffs[pointer + 1][1]) {
        // Shift the edit over the next equality.
        diffs[pointer - 1][1] += diffs[pointer + 1][1];
        diffs[pointer][1] =
            diffs[pointer][1].substring(diffs[pointer + 1][1].length) +
            diffs[pointer + 1][1];
        diffs.splice(pointer + 1, 1);
        changes = true;
      }
    }
    pointer++;
  }
  // If shifts were made, the diff needs reordering and another shift sweep.
  if (changes) {
    this.cleanupMerge(diffs);
  }
};


/**
 * loc is a location in text1, compute and return the equivalent location in
 * text2.
 * e.g. 'The cat' vs 'The big cat', 1->1, 5->8
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 * @param {number} loc Location within text1.
 * @return {number} Location within text2.
 */
diff.prototype.xIndex = function(diffs, loc) {
  var chars1 = 0;
  var chars2 = 0;
  var last_chars1 = 0;
  var last_chars2 = 0;
  var x;
  for (x = 0; x < diffs.length; x++) {
    if (diffs[x][0] !== DIFF_INSERT) {  // Equality or deletion.
      chars1 += diffs[x][1].length;
    }
    if (diffs[x][0] !== DIFF_DELETE) {  // Equality or insertion.
      chars2 += diffs[x][1].length;
    }
    if (chars1 > loc) {  // Overshot the location.
      break;
    }
    last_chars1 = chars1;
    last_chars2 = chars2;
  }
  // Was the location was deleted?
  if (diffs.length != x && diffs[x][0] === DIFF_DELETE) {
    return last_chars2;
  }
  // Add the remaining character length.
  return last_chars2 + (loc - last_chars1);
};


/**
 * Convert a diff array into a pretty HTML report.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 * @return {string} HTML representation.
 */
diff.prototype.prettyHtml = function(diffs) {
  var html = [];
  var pattern_amp = /&/g;
  var pattern_lt = /</g;
  var pattern_gt = />/g;
  var pattern_br = /\n/g;
  for (var x = 0; x < diffs.length; x++) {
    var op = diffs[x][0];    // Operation (insert, delete, equal)
    var data = diffs[x][1];  // Text of change.
    var text = data.replace(pattern_amp, '&amp;').replace(pattern_lt, '&lt;')
        .replace(pattern_gt, '&gt;').replace(pattern_br, '<br/>');
    switch (op) {
      case DIFF_INSERT:
        html[x] = '<ins>' + text + '</ins>';
        break;
      case DIFF_DELETE:
        html[x] = '<del>' + text + '</del>';
        break;
      case DIFF_EQUAL:
        html[x] = '<span>' + text + '</span>';
        break;
    }
  }
  return html.join('');
};


/**
 * Compute and return the source text (all equalities and deletions).
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 * @return {string} Source text.
 */
diff.prototype.text1 = function(diffs) {
  var text = [];
  for (var x = 0; x < diffs.length; x++) {
    if (diffs[x][0] !== DIFF_INSERT) {
      text[x] = diffs[x][1];
    }
  }
  return text.join('');
};


/**
 * Compute and return the destination text (all equalities and insertions).
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 * @return {string} Destination text.
 */
diff.prototype.text2 = function(diffs) {
  var text = [];
  for (var x = 0; x < diffs.length; x++) {
    if (diffs[x][0] !== DIFF_DELETE) {
      text[x] = diffs[x][1];
    }
  }
  return text.join('');
};


/**
 * Compute the Levenshtein distance; the number of inserted, deleted or
 * substituted characters.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 * @return {number} Number of changes.
 */
diff.prototype.levenshtein = function(diffs) {
  var levenshtein = 0;
  var insertions = 0;
  var deletions = 0;
  for (var x = 0; x < diffs.length; x++) {
    var op = diffs[x][0];
    var data = diffs[x][1];
    switch (op) {
      case DIFF_INSERT:
        insertions += data.length;
        break;
      case DIFF_DELETE:
        deletions += data.length;
        break;
      case DIFF_EQUAL:
        // A deletion and an insertion is one substitution.
        levenshtein += Math.max(insertions, deletions);
        insertions = 0;
        deletions = 0;
        break;
    }
  }
  levenshtein += Math.max(insertions, deletions);
  return levenshtein;
};


/**
 * Crush the diff into an encoded string which describes the operations
 * required to transform text1 into text2.
 * E.g. =3\t-2\t+ing  -> Keep 3 chars, delete 2 chars, insert 'ing'.
 * Operations are tab-separated.  Inserted text is escaped using %xx notation.
 * @param {!Array.<!diff.Diff>} diffs Array of diff tuples.
 * @return {string} Delta text.
 */
diff.prototype.toDelta = function(diffs) {
  var text = [];
  for (var x = 0; x < diffs.length; x++) {
    switch (diffs[x][0]) {
      case DIFF_INSERT:
        text[x] = '+' + encodeURI(diffs[x][1]);
        break;
      case DIFF_DELETE:
        text[x] = '-' + diffs[x][1].length;
        break;
      case DIFF_EQUAL:
        text[x] = '=' + diffs[x][1].length;
        break;
    }
  }
  return text.join('\t').replace(/%20/g, ' ');
};


/**
 * Given the original text1, and an encoded string which describes the
 * operations required to transform text1 into text2, compute the full diff.
 * @param {string} text1 Source string for the diff.
 * @param {string} delta Delta text.
 * @return {!Array.<!diff.Diff>} Array of diff tuples.
 * @throws {!Error} If invalid input.
 */
diff.prototype.fromDelta = function(text1, delta) {
  var diffs = [];
  var diffsLength = 0;  // Keeping our own length var is faster in JS.
  var pointer = 0;  // Cursor in text1
  var tokens = delta.split(/\t/g);
  for (var x = 0; x < tokens.length; x++) {
    // Each token begins with a one character parameter which specifies the
    // operation of this token (delete, insert, equality).
    var param = tokens[x].substring(1);
    switch (tokens[x].charAt(0)) {
      case '+':
        try {
          diffs[diffsLength++] = [DIFF_INSERT, decodeURI(param)];
        } catch (ex) {
          // Malformed URI sequence.
          throw new Error('Illegal escape in diff_fromDelta: ' + param);
        }
        break;
      case '-':
        // Fall through.
      case '=':
        var n = parseInt(param, 10);
        if (isNaN(n) || n < 0) {
          throw new Error('Invalid number in diff_fromDelta: ' + param);
        }
        var text = text1.substring(pointer, pointer += n);
        if (tokens[x].charAt(0) == '=') {
          diffs[diffsLength++] = [DIFF_EQUAL, text];
        } else {
          diffs[diffsLength++] = [DIFF_DELETE, text];
        }
        break;
      default:
        // Blank tokens are ok (from a trailing \t).
        // Anything else is an error.
        if (tokens[x]) {
          throw new Error('Invalid diff operation in diff_fromDelta: ' +
                          tokens[x]);
        }
    }
  }
  if (pointer != text1.length) {
    throw new Error('Delta length (' + pointer +
        ') does not equal source text length (' + text1.length + ').');
  }
  return diffs;
};


// Export these global variables so that they survive Google's JS compiler.
// In a browser, 'this' will be 'window'.
// Users of node.js should 'require' the uncompressed version since Google's
// JS compiler may break the following exports for non-browser environments.
this['diff'] = diff;
this['DIFF_DELETE'] = DIFF_DELETE;
this['DIFF_INSERT'] = DIFF_INSERT;
this['DIFF_EQUAL'] = DIFF_EQUAL;

module.exports = diff;


/***/ }),

/***/ "./node_modules/typograf/dist/typograf.min.js":
/*!****************************************************!*\
  !*** ./node_modules/typograf/dist/typograf.min.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/*! typograf | © 2019 Denis Seleznev | MIT  License | https://github.com/typograf/typograf */
!function(e,t){ true?module.exports=t():undefined}(this,function(){"use strict";function r(e){return(r="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}function a(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function n(e,t){for(var a=0;a<t.length;a++){var n=t[a];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(e,n.key,n)}}function t(e,t,a){return t&&n(e.prototype,t),a&&n(e,a),e}function i(e,t){return function(e){if(Array.isArray(e))return e}(e)||function(e,t){var a=[],n=!0,r=!1,s=void 0;try{for(var i,u=e[Symbol.iterator]();!(n=(i=u.next()).done)&&(a.push(i.value),!t||a.length!==t);n=!0);}catch(e){r=!0,s=e}finally{try{n||null==u.return||u.return()}finally{if(r)throw s}}return a}(e,t)||function(){throw new TypeError("Invalid attempt to destructure non-iterable instance")}()}var s=["a","abbr","acronym","b","bdo","big","br","button","cite","code","dfn","em","i","img","input","kbd","label","map","object","q","samp","script","select","small","span","strong","sub","sup","textarea","time","tt","var"],u=[["iexcl",161],["cent",162],["pound",163],["curren",164],["yen",165],["brvbar",166],["sect",167],["uml",168],["copy",169],["ordf",170],["laquo",171],["not",172],["reg",174],["macr",175],["deg",176],["plusmn",177],["sup2",178],["sup3",179],["acute",180],["micro",181],["para",182],["middot",183],["cedil",184],["sup1",185],["ordm",186],["raquo",187],["frac14",188],["frac12",189],["frac34",190],["iquest",191],["Agrave",192],["Aacute",193],["Acirc",194],["Atilde",195],["Auml",196],["Aring",197],["AElig",198],["Ccedil",199],["Egrave",200],["Eacute",201],["Ecirc",202],["Euml",203],["Igrave",204],["Iacute",205],["Icirc",206],["Iuml",207],["ETH",208],["Ntilde",209],["Ograve",210],["Oacute",211],["Ocirc",212],["Otilde",213],["Ouml",214],["times",215],["Oslash",216],["Ugrave",217],["Uacute",218],["Ucirc",219],["Uuml",220],["Yacute",221],["THORN",222],["szlig",223],["agrave",224],["aacute",225],["acirc",226],["atilde",227],["auml",228],["aring",229],["aelig",230],["ccedil",231],["egrave",232],["eacute",233],["ecirc",234],["euml",235],["igrave",236],["iacute",237],["icirc",238],["iuml",239],["eth",240],["ntilde",241],["ograve",242],["oacute",243],["ocirc",244],["otilde",245],["ouml",246],["divide",247],["oslash",248],["ugrave",249],["uacute",250],["ucirc",251],["uuml",252],["yacute",253],["thorn",254],["yuml",255],["fnof",402],["Alpha",913],["Beta",914],["Gamma",915],["Delta",916],["Epsilon",917],["Zeta",918],["Eta",919],["Theta",920],["Iota",921],["Kappa",922],["Lambda",923],["Mu",924],["Nu",925],["Xi",926],["Omicron",927],["Pi",928],["Rho",929],["Sigma",931],["Tau",932],["Upsilon",933],["Phi",934],["Chi",935],["Psi",936],["Omega",937],["alpha",945],["beta",946],["gamma",947],["delta",948],["epsilon",949],["zeta",950],["eta",951],["theta",952],["iota",953],["kappa",954],["lambda",955],["mu",956],["nu",957],["xi",958],["omicron",959],["pi",960],["rho",961],["sigmaf",962],["sigma",963],["tau",964],["upsilon",965],["phi",966],["chi",967],["psi",968],["omega",969],["thetasym",977],["upsih",978],["piv",982],["bull",8226],["hellip",8230],["prime",8242],["Prime",8243],["oline",8254],["frasl",8260],["weierp",8472],["image",8465],["real",8476],["trade",8482],["alefsym",8501],["larr",8592],["uarr",8593],["rarr",8594],["darr",8595],["harr",8596],["crarr",8629],["lArr",8656],["uArr",8657],["rArr",8658],["dArr",8659],["hArr",8660],["forall",8704],["part",8706],["exist",8707],["empty",8709],["nabla",8711],["isin",8712],["notin",8713],["ni",8715],["prod",8719],["sum",8721],["minus",8722],["lowast",8727],["radic",8730],["prop",8733],["infin",8734],["ang",8736],["and",8743],["or",8744],["cap",8745],["cup",8746],["int",8747],["there4",8756],["sim",8764],["cong",8773],["asymp",8776],["ne",8800],["equiv",8801],["le",8804],["ge",8805],["sub",8834],["sup",8835],["nsub",8836],["sube",8838],["supe",8839],["oplus",8853],["otimes",8855],["perp",8869],["sdot",8901],["lceil",8968],["rceil",8969],["lfloor",8970],["rfloor",8971],["lang",9001],["rang",9002],["spades",9824],["clubs",9827],["hearts",9829],["diams",9830],["loz",9674],["OElig",338],["oelig",339],["Scaron",352],["scaron",353],["Yuml",376],["circ",710],["tilde",732],["ndash",8211],["mdash",8212],["lsquo",8216],["rsquo",8217],["sbquo",8218],["ldquo",8220],["rdquo",8221],["bdquo",8222],["dagger",8224],["Dagger",8225],["permil",8240],["lsaquo",8249],["rsaquo",8250],["euro",8364],["NestedGreaterGreater",8811],["NestedLessLess",8810]],l=[["nbsp",160],["thinsp",8201],["ensp",8194],["emsp",8195],["shy",173],["zwnj",8204],["zwj",8205],["lrm",8206],["rlm",8207]],e=new(function(){function e(){a(this,e),this._entities=this._prepareEntities([].concat(u,l)),this._entitiesByName={},this._entitiesByNameEntity={},this._entitiesByDigitEntity={},this._entitiesByUtf={},this._entities.forEach(function(e){this._entitiesByName[e.name]=e,this._entitiesByNameEntity[e.nameEntity]=e,this._entitiesByDigitEntity[e.digitEntity]=e,this._entitiesByUtf[e.utf]=e},this),this._invisibleEntities=this._prepareEntities(l)}return t(e,[{key:"toUtf",value:function(e){var a=this;-1!==e.text.search(/&#/)&&(e.text=this.decHexToUtf(e.text)),-1!==e.text.search(/&[a-z]/i)&&(e.text=e.text.replace(/&[a-z\d]{2,31};/gi,function(e){var t=a._entitiesByNameEntity[e];return t?t.utf:e}))}},{key:"decHexToUtf",value:function(e){return e.replace(/&#(\d{1,6});/gi,function(e,t){return String.fromCharCode(parseInt(t,10))}).replace(/&#x([\da-f]{1,6});/gi,function(e,t){return String.fromCharCode(parseInt(t,16))})}},{key:"restore",value:function(e){var t=e.prefs.htmlEntity,a=t.type,n=this._entities;"name"!==a&&"digit"!==a||((t.onlyInvisible||t.list)&&(n=[],t.onlyInvisible&&(n=n.concat(this._invisibleEntities)),t.list&&(n=n.concat(this._prepareListParam(t.list)))),e.text=this._restoreEntitiesByIndex(e.text,a+"Entity",n))}},{key:"getByUtf",value:function(e,t){var a="";switch(t){case"digit":a=this._entitiesByDigitEntity[e];break;case"name":a=this._entitiesByNameEntity[e];break;default:a=e}return a}},{key:"_prepareEntities",value:function(e){var s=[];return e.forEach(function(e){var t=i(e,2),a=t[0],n=t[1],r=String.fromCharCode(n);s.push({name:a,nameEntity:"&"+a+";",digitEntity:"&#"+n+";",utf:r,reName:new RegExp("&"+a+";","g"),reUtf:new RegExp(r,"g")})},this),s}},{key:"_prepareListParam",value:function(e){var a=[];return e.forEach(function(e){var t=this._entitiesByName[e];t&&a.push(t)},this),a}},{key:"_restoreEntitiesByIndex",value:function(t,a,e){return e.forEach(function(e){t=t.replace(e.reUtf,e[a])}),t}}]),e}()),o=function(){function e(){a(this,e);var t=[["\x3c!--","--\x3e"],["<!ENTITY",">"],["<!DOCTYPE",">"],["<\\?xml","\\?>"],["<!\\[CDATA\\[","\\]\\]>"]];["code","kbd","object","pre","samp","script","style","var"].forEach(function(e){t.push(["<"+e+"(\\s[^>]*?)?>","</"+e+">"])},this),this._tags={own:[],html:t.map(this._prepareRegExp),url:[f._reUrl]},this._groups=["own","html","url"]}return t(e,[{key:"add",value:function(e){this._tags.own.push(this._prepareRegExp(e))}},{key:"show",value:function(t,a){for(var e=f._privateLabel,n=new RegExp(e+"tf\\d+"+e,"g"),r=new RegExp(e+"tf\\d"),s=function(e){return t.safeTags.hidden[a][e]||e},i=0,u=this._tags[a].length;i<u&&(t.text=t.text.replace(n,s),-1!==t.text.search(r));i++);}},{key:"hide",value:function(t,e){t.safeTags=t.safeTags||{hidden:{},i:0},t.safeTags.hidden[e]={};var a=this._pasteLabel.bind(this,t,e);this._tags[e].forEach(function(e){t.text=t.text.replace(this._prepareRegExp(e),a)},this)}},{key:"hideHTMLTags",value:function(e){if(e.isHTML){var t=this._pasteLabel.bind(this,e,"html");e.text=e.text.replace(/<\/?[a-z][^]*?>/gi,t).replace(/&lt;\/?[a-z][^]*?&gt;/gi,t).replace(/&[gl]t;/gi,t)}}},{key:"getPrevLabel",value:function(e,t){for(var a=t-1;0<=a;a--)if(e[a]===f._privateLabel)return e.slice(a,t+1);return!1}},{key:"getNextLabel",value:function(e,t){for(var a=t+1;a<e.length;a++)if(e[a]===f._privateLabel)return e.slice(t,a+1);return!1}},{key:"getTagByLabel",value:function(a,n){var r=!1;return this._groups.some(function(e){var t=a.safeTags.hidden[e][n];return void 0!==t&&(r={group:e,value:t}),r}),r}},{key:"getTagInfo",value:function(e){if(e){var t={group:e.group};switch(e.group){case"html":t.name=e.value.split(/[<\s>]/)[1],t.isInline=-1<s.indexOf(t.name),t.isClosing=-1<e.value.search(/^<\//);break;case"url":t.isInline=!0;break;case"own":t.isInline=!1}return t}}},{key:"_pasteLabel",value:function(e,t,a){var n=e.safeTags,r=f._privateLabel+"tf"+n.i+f._privateLabel;return n.hidden[t][r]=a,n.i++,r}},{key:"_prepareRegExp",value:function(e){var t;if(e instanceof RegExp)t=e;else{var a=i(e,3),n=a[0],r=a[1],s=a[2];void 0===s&&(s="[^]*?"),t=new RegExp(n+s+r,"gi")}return t}}]),e}(),f=function(){function l(e){a(this,l),this._prefs="object"===r(e)?e:{},this._prefs.locale=l._prepareLocale(this._prefs.locale),this._prefs.live=this._prefs.live||!1,this._safeTags=new o,this._settings={},this._enabledRules={},this._innerRulesByQueues={},this._innerRules=[].concat(this._innerRules),this._innerRules.forEach(function(e){var t=e.queue||"default";this._innerRulesByQueues[t]=this._innerRulesByQueues[t]||[],this._innerRulesByQueues[t].push(e)},this),this._rulesByQueues={},this._rules=[].concat(this._rules),this._rules.forEach(function(e){var t=e.queue||"default";this._prepareRule(e),this._rulesByQueues[t]=this._rulesByQueues[t]||[],this._rulesByQueues[t].push(e)},this),this._prefs.disableRule&&this.disableRule(this._prefs.disableRule),this._prefs.enableRule&&this.enableRule(this._prefs.enableRule),this._separatePartsTags=["title","p","h[1-6]","select","legend"]}return t(l,[{key:"execute",value:function(e,t){if(!(e=""+e))return"";var a=this._prepareContext(e);return this._preparePrefs(a,t),this._process(a)}},{key:"_prepareContext",value:function(e){return{text:e,isHTML:this._isHTML(e),prefs:l.deepCopy(this._prefs),getData:function(t){return"char"===t?this.prefs.locale.map(function(e){return l.getData(e+"/"+t)}).join(""):l.getData(this.prefs.locale[0]+"/"+t)}}}},{key:"_preparePrefs",value:function(e,t){t=t||{};for(var a=e.prefs,n=0,r=["htmlEntity","lineEnding","processingSeparateParts","ruleFilter"];n<r.length;n++){var s=r[n];s in t?a[s]=t[s]:s in this._prefs&&(a[s]=this._prefs[s])}a.htmlEntity=a.htmlEntity||{},a.locale=l._prepareLocale(t.locale,this._prefs.locale);var i=a.locale,u=i[0];if(!i.length||!u)throw Error('Not defined the property "locale".');if(!l.hasLocale(u))throw Error('"'+u+'" is not supported locale.')}},{key:"_isHTML",value:function(e){return-1!==e.search(/(<\/?[a-z]|<!|&[lg]t;)/i)}},{key:"_splitBySeparateParts",value:function(r){if(!r.isHTML||!1===r.prefs.processingSeparateParts)return[r.text];var s=[],i=l._privateSeparateLabel,e=new RegExp("<("+this._separatePartsTags.join("|")+")(\\s[^>]*?)?>[^]*?</\\1>","gi"),u=0;return r.text.replace(e,function(e,t,a,n){return u!==n&&s.push((u?i:"")+r.text.slice(u,n)+i),s.push(e),u=n+e.length,e}),s.push(u?i+r.text.slice(u,r.text.length):r.text),s}},{key:"_process",value:function(t){t.text=this._removeCR(t.text),this._executeRules(t,"start"),this._safeTags.hide(t,"own"),this._executeRules(t,"hide-safe-tags-own"),this._safeTags.hide(t,"html"),this._executeRules(t,"hide-safe-tags-html");var e=t.isHTML,a=new RegExp(l._privateSeparateLabel,"g");return t.text=this._splitBySeparateParts(t).map(function(e){return t.text=e,t.isHTML=this._isHTML(e),this._safeTags.hideHTMLTags(t),this._safeTags.hide(t,"url"),this._executeRules(t,"hide-safe-tags-url"),this._executeRules(t,"hide-safe-tags"),l.HtmlEntities.toUtf(t),this._prefs.live&&(t.text=l._replaceNbsp(t.text)),this._executeRules(t,"utf"),this._executeRules(t),l.HtmlEntities.restore(t),this._executeRules(t,"html-entities"),this._safeTags.show(t,"url"),this._executeRules(t,"show-safe-tags-url"),t.text.replace(a,"")},this).join(""),t.isHTML=e,this._safeTags.show(t,"html"),this._executeRules(t,"show-safe-tags-html"),this._safeTags.show(t,"own"),this._executeRules(t,"show-safe-tags-own"),this._executeRules(t,"end"),this._fixLineEnding(t.text,t.prefs.lineEnding)}},{key:"getSetting",value:function(e,t){return this._settings[e]&&this._settings[e][t]}},{key:"setSetting",value:function(e,t,a){return this._settings[e]=this._settings[e]||{},this._settings[e][t]=a,this}},{key:"isEnabledRule",value:function(e){return this._enabledRules[e]}},{key:"isDisabledRule",value:function(e){return!this._enabledRules[e]}},{key:"enableRule",value:function(e){return this._enable(e,!0)}},{key:"disableRule",value:function(e){return this._enable(e,!1)}},{key:"addSafeTag",value:function(e,t,a){var n=e instanceof RegExp?e:[e,t,a];return this._safeTags.add(n),this}},{key:"_executeRules",value:function(t,e){e=e||"default";var a=this._rulesByQueues[e],n=this._innerRulesByQueues[e];n&&n.forEach(function(e){this._ruleIterator(t,e)},this),a&&a.forEach(function(e){this._ruleIterator(t,e)},this)}},{key:"_ruleIterator",value:function(e,t){var a=t._locale,n=this._prefs.live;if(!(!0===n&&!1===t.live||!1===n&&!0===t.live)&&("common"===a||a===e.prefs.locale[0])&&this.isEnabledRule(t.name)){if(e.prefs.ruleFilter&&!e.prefs.ruleFilter(t))return;this._onBeforeRule&&this._onBeforeRule(t.name,e.text,e),e.text=t.handler.call(this,e.text,this._settings[t.name],e),this._onAfterRule&&this._onAfterRule(t.name,e.text,e)}}},{key:"_removeCR",value:function(e){return e.replace(/\r\n?/g,"\n")}},{key:"_fixLineEnding",value:function(e,t){return"CRLF"===t?e.replace(/\n/g,"\r\n"):"CR"===t?e.replace(/\n/g,"\r"):e}},{key:"_prepareRule",value:function(e){var t=e.name,a=r(e.settings),n={};"object"===a?n=l.deepCopy(e.settings):"function"===a&&(n=e.settings(e)),this._settings[t]=n,this._enabledRules[t]=e._enabled}},{key:"_enable",value:function(e,t){return Array.isArray(e)?e.forEach(function(e){this._enableByMask(e,t)},this):this._enableByMask(e,t),this}},{key:"_enableByMask",value:function(e,a){if(e)if(-1!==e.search(/\*/)){var n=new RegExp(e.replace(/\//g,"\\/").replace(/\*/g,".*"));this._rules.forEach(function(e){var t=e.name;n.test(t)&&(this._enabledRules[t]=a)},this)}else this._enabledRules[e]=a}},{key:"_getRule",value:function(t){var a=null;return this._rules.some(function(e){return e.name===t&&(a=e,!0)}),a}}],[{key:"addRule",value:function(e){var t=i(e.name.split("/"),3),a=t[0],n=t[1],r=t[2];return e._enabled=!0!==e.disabled,e._locale=a,e._group=n,e._name=r,this.addLocale(e._locale),this._setIndex(e),this.prototype._rules.push(e),this._sortRules(this.prototype._rules),this}},{key:"addInnerRule",value:function(e){return this.prototype._innerRules.push(e),e._locale=e.name.split("/")[0],this}},{key:"deepCopy",value:function(e){return"object"===r(e)?JSON.parse(JSON.stringify(e)):e}},{key:"_repeat",value:function(e,t){for(var a="";1==(1&t)&&(a+=e),0!==(t>>>=1);)e+=e;return a}},{key:"_replace",value:function(e,t){for(var a=0;a<t.length;a++)e=e.replace(t[a][0],t[a][1]);return e}},{key:"_replaceNbsp",value:function(e){return e.replace(/\u00A0/g," ")}},{key:"_setIndex",value:function(e){var t=e.index,a=r(t),n=this.groupIndexes[e._group];"undefined"===a?t=n:"string"===a&&(t=n+parseInt(e.index,10)),e._index=t}},{key:"_sortRules",value:function(e){e.sort(function(e,t){return e._index>t._index?1:-1})}},{key:"_mix",value:function(t,a){Object.keys(a).forEach(function(e){t[e]=a[e]})}}]),l}();function c(e,t,a,n){return t+a.replace(/([^\u00A0])\u00A0([^\u00A0])/g,"$1 $2")+n}f._mix(f,{version:"6.8.2",inlineElements:s,blockElements:["address","article","aside","blockquote","canvas","dd","div","dl","fieldset","figcaption","figure","footer","form","h1","h2","h3","h4","h5","h6","header","hgroup","hr","li","main","nav","noscript","ol","output","p","pre","section","table","tfoot","ul","video"],groupIndexes:{symbols:110,space:210,dash:310,punctuation:410,nbsp:510,number:610,money:710,date:810,other:910,optalign:1010,typo:1110,html:1210},HtmlEntities:e,_reUrl:new RegExp("(https?|file|ftp)://([a-zA-Z0-9/+-=%&:_.~?]+[a-zA-Z0-9#+]*)","g"),_privateLabel:"\uf000",_privateSeparateLabel:"\uf001"}),f._mix(f.prototype,{_rules:[],_innerRules:[]}),f._mix(f,{getData:function(e){return this._data[e]},setData:function(t,e){"string"==typeof t?(this.addLocale(t),this._data[t]=e):"object"===r(t)&&Object.keys(t).forEach(function(e){this.addLocale(e),this._data[e]=t[e]},this)},_data:{}}),f._mix(f,{addLocale:function(e){var t=(e||"").split("/")[0];t&&"common"!==t&&!this.hasLocale(t)&&(this._locales.push(t),this._locales.sort())},getLocales:function(){return this._locales},hasLocale:function(e){return"common"===e||-1!==this._locales.indexOf(e)},_prepareLocale:function(e,t){var a=e||t,n=a;return Array.isArray(a)||(n=[a]),n},_locales:[]}),f.setData("be/char","\u0430\u0431\u0432\u0433\u0434\u0435\u0436\u0437\u0439\u043a\u043b\u043c\u043d\u043e\u043f\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u044b\u044c\u044d\u044e\u044f\u0451\u0456\u045e\u0491"),f.setData("be/quote",{left:"\xab\u201c",right:"\xbb\u201d"}),f.setData("bg/char","\u0430\u0431\u0432\u0433\u0434\u0435\u0436\u0437\u0438\u0439\u043a\u043b\u043c\u043d\u043e\u043f\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u0449\u044a\u044c\u044e\u044f"),f.setData("bg/quote",{left:"\u201e\u2019",right:"\u201c\u2019"}),f.setData("ca/char","abcdefghijlmnopqrstuvxyz\xe0\xe7\xe8\xe9\xed\xef\xf2\xf3\xfa\xfc"),f.setData("ca/quote",{left:"\xab\u201c",right:"\xbb\u201d"}),f.setData("common/char","a-z"),f.setData("common/dash","--?|\u2012|\u2013|\u2014"),f.setData("common/quote",'\xab\u2039\xbb\u203a\u201e\u201c\u201f\u201d"'),f.setData("cs/char","a-z\xe1\xe9\xed\xf3\xfa\xfd\u010d\u010f\u011b\u0148\u0159\u0161\u0165\u016f\u017e"),f.setData("cs/quote",{left:"\u201e\u201a",right:"\u201c\u2018"}),f.setData("da/char","a-z\xe5\xe6\xf8"),f.setData("da/quote",{left:"\xbb\u203a",right:"\xab\u2039"}),f.setData("de/char","a-z\xdf\xe4\xf6\xfc"),f.setData("de/quote",{left:"\u201e\u201a",right:"\u201c\u2018"}),f.setData("el/char","\u0390\u03ac\u03ad\u03ae\u03af\u03b0\u03b1\u03b2\u03b3\u03b4\u03b5\u03b6\u03b7\u03b8\u03b9\u03ba\u03bb\u03bc\u03bd\u03be\u03bf\u03c0\u03c1\u03c2\u03c3\u03c4\u03c5\u03c6\u03c7\u03c8\u03c9\u03ca\u03cb\u03cc\u03cd\u03ce\u03f2\u1f71\u1f73\u1f75\u1f77\u1f79\u1f7b\u1f7d"),f.setData("el/quote",{left:"\xab\u201c",right:"\xbb\u201d"}),f.setData("en-GB/char","a-z"),f.setData("en-GB/quote",{left:"\u2018\u201c",right:"\u2019\u201d"}),f.setData("en-US/char","a-z"),f.setData("en-US/quote",{left:"\u201c\u2018",right:"\u201d\u2019"}),f.setData("eo/char","abcdefghijklmnoprstuvz\u0109\u011d\u0125\u0135\u015d\u016d"),f.setData("eo/quote",{left:"\u201c\u2018",right:"\u201d\u2019"}),f.setData("es/char","a-z\xe1\xe9\xed\xf1\xf3\xfa\xfc"),f.setData("es/quote",{left:"\xab\u201c",right:"\xbb\u201d"}),f.setData("et/char","abdefghijklmnoprstuvz\xe4\xf5\xf6\xfc\u0161\u017e"),f.setData("et/quote",{left:"\u201e\xab",right:"\u201c\xbb"}),f.setData("fi/char","abcdefghijklmnopqrstuvy\xf6\xe4\xe5"),f.setData("fi/quote",{left:"\u201d\u2019",right:"\u201d\u2019"}),f.setData("fr/char","a-z\xe0\xe2\xe7\xe8\xe9\xea\xeb\xee\xef\xf4\xfb\xfc\u0153\xe6"),f.setData("fr/quote",{left:"\xab\u2039",right:"\xbb\u203a",spacing:!0}),f.setData("ga/char","abcdefghilmnoprstuvwxyz\xe1\xe9\xed\xf3\xfa"),f.setData("ga/quote",{left:"\u201c\u2018",right:"\u201d\u2019"}),f.setData("hu/char","a-z\xe1\xe4\xe9\xed\xf3\xf6\xfa\xfc\u0151\u0171"),f.setData("hu/quote",{left:"\u201e\xbb",right:"\u201d\xab"}),f.setData("it/char","a-z\xe0\xe9\xe8\xec\xf2\xf9"),f.setData("it/quote",{left:"\xab\u201c",right:"\xbb\u201d"}),f.setData("lv/char","abcdefghijklmnopqrstuvxz\xe6\u0153"),f.setData("lv/quote",{left:"\xab\u201e",right:"\xbb\u201c"}),f.setData("nl/char","a-z\xe4\xe7\xe8\xe9\xea\xeb\xee\xef\xf1\xf6\xfb\xfc"),f.setData("nl/quote",{left:"\u2018\u201c",right:"\u2019\u201d"}),f.setData("no/char","a-z\xe5\xe6\xe8\xe9\xea\xf2\xf3\xf4\xf8"),f.setData("no/quote",{left:"\xab\u2019",right:"\xbb\u2019"}),f.setData("pl/char","abcdefghijklmnoprstuvwxyz\xf3\u0105\u0107\u0119\u0142\u0144\u015b\u017a\u017c"),f.setData("pl/quote",{left:"\u201e\xab",right:"\u201d\xbb"}),f.setData("ro/char","abcdefghijklmnoprstuvxz\xee\u0103\u0219\u021b"),f.setData("ro/quote",{left:"\u201e\xab",right:"\u201d\xbb"}),f.setData("ru/char","\u0430-\u044f\u0451"),f.setData({"ru/dashBefore":"(^| |\\n)","ru/dashAfter":"(?=[\xa0 ,.?:!]|$)","ru/dashAfterDe":"(?=[,.?:!]|[\xa0 ][^\u0410-\u042f\u0401]|$)"}),f.setData({"ru/l":"\u0430-\u044f\u0451a-z","ru/L":"\u0410-\u042f\u0401A-Z"}),f.setData({"ru/month":"\u044f\u043d\u0432\u0430\u0440\u044c|\u0444\u0435\u0432\u0440\u0430\u043b\u044c|\u043c\u0430\u0440\u0442|\u0430\u043f\u0440\u0435\u043b\u044c|\u043c\u0430\u0439|\u0438\u044e\u043d\u044c|\u0438\u044e\u043b\u044c|\u0430\u0432\u0433\u0443\u0441\u0442|\u0441\u0435\u043d\u0442\u044f\u0431\u0440\u044c|\u043e\u043a\u0442\u044f\u0431\u0440\u044c|\u043d\u043e\u044f\u0431\u0440\u044c|\u0434\u0435\u043a\u0430\u0431\u0440\u044c","ru/monthGenCase":"\u044f\u043d\u0432\u0430\u0440\u044f|\u0444\u0435\u0432\u0440\u0430\u043b\u044f|\u043c\u0430\u0440\u0442\u0430|\u0430\u043f\u0440\u0435\u043b\u044f|\u043c\u0430\u044f|\u0438\u044e\u043d\u044f|\u0438\u044e\u043b\u044f|\u0430\u0432\u0433\u0443\u0441\u0442\u0430|\u0441\u0435\u043d\u0442\u044f\u0431\u0440\u044f|\u043e\u043a\u0442\u044f\u0431\u0440\u044f|\u043d\u043e\u044f\u0431\u0440\u044f|\u0434\u0435\u043a\u0430\u0431\u0440\u044f","ru/monthPreCase":"\u044f\u043d\u0432\u0430\u0440\u0435|\u0444\u0435\u0432\u0440\u0430\u043b\u0435|\u043c\u0430\u0440\u0442\u0435|\u0430\u043f\u0440\u0435\u043b\u0435|\u043c\u0430\u0435|\u0438\u044e\u043d\u0435|\u0438\u044e\u043b\u0435|\u0430\u0432\u0433\u0443\u0441\u0442\u0435|\u0441\u0435\u043d\u0442\u044f\u0431\u0440\u0435|\u043e\u043a\u0442\u044f\u0431\u0440\u0435|\u043d\u043e\u044f\u0431\u0440\u0435|\u0434\u0435\u043a\u0430\u0431\u0440\u0435","ru/shortMonth":"\u044f\u043d\u0432|\u0444\u0435\u0432|\u043c\u0430\u0440|\u0430\u043f\u0440|\u043c\u0430[\u0435\u0439\u044f]|\u0438\u044e\u043d|\u0438\u044e\u043b|\u0430\u0432\u0433|\u0441\u0435\u043d|\u043e\u043a\u0442|\u043d\u043e\u044f|\u0434\u0435\u043a"}),f.setData("ru/quote",{left:"\xab\u201e\u201a",right:"\xbb\u201c\u2018",removeDuplicateQuotes:!0}),f.setData("ru/weekday","\u043f\u043e\u043d\u0435\u0434\u0435\u043b\u044c\u043d\u0438\u043a|\u0432\u0442\u043e\u0440\u043d\u0438\u043a|\u0441\u0440\u0435\u0434\u0430|\u0447\u0435\u0442\u0432\u0435\u0440\u0433|\u043f\u044f\u0442\u043d\u0438\u0446\u0430|\u0441\u0443\u0431\u0431\u043e\u0442\u0430|\u0432\u043e\u0441\u043a\u0440\u0435\u0441\u0435\u043d\u044c\u0435"),f.setData("sk/char","abcdefghijklmnoprstuvwxyz\xe1\xe4\xe9\xed\xf3\xf4\xfa\xfd\u010d\u010f\u013e\u0148\u0155\u0161\u0165\u017e"),f.setData("sk/quote",{left:"\u201e\u201a",right:"\u201c\u2018"}),f.setData("sl/char","a-z\u010d\u0161\u017e"),f.setData("sl/quote",{left:"\u201e\u201a",right:"\u201c\u2018"}),f.setData("sr/char","abcdefghijklmnoprstuvz\u0107\u010d\u0111\u0161\u017e"),f.setData("sr/quote",{left:"\u201e\u2019",right:"\u201d\u2019"}),f.setData("sv/char","a-z\xe4\xe5\xe9\xf6"),f.setData("sv/quote",{left:"\u201d\u2019",right:"\u201d\u2019"}),f.setData("tr/char","abcdefghijklmnoprstuvyz\xe2\xe7\xee\xf6\xfb\xfc\u011f\u0131\u015f"),f.setData("tr/quote",{left:"\u201c\u2018",right:"\u201d\u2019"}),f.setData("uk/char","\u0430\u0431\u0432\u0433\u0434\u0435\u0436\u0437\u0438\u0439\u043a\u043b\u043c\u043d\u043e\u043f\u0440\u0441\u0442\u0443\u0444\u0445\u0446\u0447\u0448\u0449\u044c\u044e\u044f\u0454\u0456\u0457\u0491"),f.setData("uk/quote",{left:"\xab\u201e",right:"\xbb\u201c"}),f.addRule({name:"common/html/e-mail",queue:"end",handler:function(e,t,a){return a.isHTML?e:e.replace(/(^|[\s;(])([\w\-.]{2,64})@([\w\-.]{2,64})\.([a-z]{2,64})([)\s.,!?]|$)/gi,'$1<a href="mailto:$2@$3.$4">$2@$3.$4</a>$5')},disabled:!0,htmlAttrs:!1}),f.addRule({name:"common/html/escape",index:"+100",queue:"end",handler:function(e){var t={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#x2F;"};return e.replace(/[&<>"'/]/g,function(e){return t[e]})},disabled:!0}),f.addRule({name:"common/html/nbr",index:"+10",queue:"end",handler:function(e){return e.replace(/([^\n>])\n(?=[^\n])/g,"$1<br/>\n")},disabled:!0,htmlAttrs:!1}),f.addRule({name:"common/html/p",index:"+5",queue:"end",handler:function(e){var n=new RegExp("<("+f.blockElements.join("|")+")[>\\s]"),t=e.split("\n\n");return t.forEach(function(e,t,a){e.trim()&&(n.test(e)||(a[t]=e.replace(/^(\s*)/,"$1<p>").replace(/(\s*)$/,"</p>$1")))}),t.join("\n\n")},disabled:!0,htmlAttrs:!1}),f.addRule({name:"common/html/processingAttrs",queue:"hide-safe-tags-own",handler:function(e,t,a){var u=this,n=new RegExp("(^|\\s)("+t.attrs.join("|")+")=(\"[^\"]*?\"|'[^']*?')","gi"),l=f.deepCopy(a.prefs);return l.ruleFilter=function(e){return!1!==e.htmlAttrs},e.replace(/(<[-\w]+\s)([^>]+?)(?=>)/g,function(e,t,a){return t+a.replace(n,function(e,t,a,n){var r=n[0],s=n[n.length-1],i=n.slice(1,-1);return t+a+"="+r+u.execute(i,l)+s})})},settings:{attrs:["title","placeholder"]},disabled:!0,htmlAttrs:!1}),f.addRule({name:"common/html/quot",queue:"hide-safe-tags",handler:function(e){return e.replace(/&quot;/g,'"')}}),f.addRule({name:"common/html/stripTags",index:"+99",queue:"end",handler:function(e){return e.replace(/<[^>]+>/g,"")},disabled:!0}),f.addRule({name:"common/html/url",queue:"end",handler:function(e,t,a){return a.isHTML?e:e.replace(f._reUrl,function(e,t,a){a=a.replace(/([^/]+\/?)(\?|#)$/,"$1").replace(/^([^/]+)\/$/,"$1"),"http"===t?a=a.replace(/^([^/]+)(:80)([^\d]|\/|$)/,"$1$3"):"https"===t&&(a=a.replace(/^([^/]+)(:443)([^\d]|\/|$)/,"$1$3"));var n=a,r=t+"://"+a,s='<a href="'+r+'">';return"http"===t||"https"===t?(n=n.replace(/^www\./,""),s+("http"===t?n:t+"://"+n)+"</a>"):s+r+"</a>"})},disabled:!0,htmlAttrs:!1}),f.addRule({name:"common/nbsp/afterNumber",handler:function(e,t,a){var n="(^|\\D)(\\d{1,5}) (["+a.getData("char")+"]+)";return e.replace(new RegExp(n,"gi"),"$1$2\xa0$3")},disabled:!0}),f.addRule({name:"common/nbsp/afterParagraphMark",handler:function(e){return e.replace(/\xb6 ?(?=\d)/g,"\xb6\xa0")}}),f.addRule({name:"common/nbsp/afterSectionMark",handler:function(e,t,a){var n=a.prefs.locale[0];return e.replace(/\xa7[ \u00A0\u2009]?(?=\d|I|V|X)/g,"ru"===n?"\xa7\u202f":"\xa7\xa0")}}),f.addRule({name:"common/nbsp/afterShortWord",handler:function(e,t,a){var n=t.lengthShortWord,r="(^|["+(" \xa0("+f._privateLabel+f.getData("common/quote"))+"])(["+a.getData("char")+"]{1,"+n+"}) ",s=new RegExp(r,"gim");return e.replace(s,"$1$2\xa0").replace(s,"$1$2\xa0")},settings:{lengthShortWord:2}}),f.addRule({name:"common/nbsp/beforeShortLastNumber",handler:function(e,t,a){var n=a.getData("char"),r=n.toUpperCase(),s=new RegExp("(["+n+r+"]) (?=\\d{1,"+t.lengthLastNumber+"}[-+\u2212%'\""+a.getData("quote").right+"]?([.!?\u2026]( ["+r+"]|$)|$))","gm");return e.replace(s,"$1\xa0")},live:!1,settings:{lengthLastNumber:2}}),f.addRule({name:"common/nbsp/beforeShortLastWord",handler:function(e,t,a){var n=a.getData("char"),r=n.toUpperCase(),s=new RegExp("(["+n+"\\d]) (["+n+r+"]{1,"+t.lengthLastWord+"}[.!?\u2026])( ["+r+"]|$)","g");return e.replace(s,"$1\xa0$2$3")},settings:{lengthLastWord:3}}),f.addRule({name:"common/nbsp/dpi",handler:function(e){return e.replace(/(\d) ?(lpi|dpi)(?!\w)/,"$1\xa0$2")}}),f.addRule({name:"common/nbsp/nowrap",queue:"end",handler:function(e){return e.replace(/(<nowrap>)(.*?)(<\/nowrap>)/g,c).replace(/(<nobr>)(.*?)(<\/nobr>)/g,c)}}),f.addRule({name:"common/nbsp/replaceNbsp",queue:"utf",live:!1,handler:f._replaceNbsp,disabled:!0}),f.addRule({name:"common/number/fraction",handler:function(e){return e.replace(/(^|\D)1\/2(\D|$)/g,"$1\xbd$2").replace(/(^|\D)1\/4(\D|$)/g,"$1\xbc$2").replace(/(^|\D)3\/4(\D|$)/g,"$1\xbe$2")}}),f.addRule({name:"common/number/mathSigns",handler:function(e){return f._replace(e,[[/!=/g,"\u2260"],[/<=/g,"\u2264"],[/(^|[^=])>=/g,"$1\u2265"],[/<=>/g,"\u21d4"],[/<</g,"\u226a"],[/>>/g,"\u226b"],[/~=/g,"\u2245"],[/(^|[^+])\+-/g,"$1\xb1"]])}}),f.addRule({name:"common/number/times",handler:function(e){return e.replace(/(\d)[ \u00A0]?[x\u0445][ \u00A0]?(\d)/g,"$1\xd7$2")}}),f.addRule({name:"common/other/delBOM",queue:"start",index:-1,handler:function(e){return 65279===e.charCodeAt(0)?e.slice(1):e}}),f.addRule({name:"common/other/repeatWord",handler:function(e,t,a){var n="[;:,.?! \n"+f.getData("common/quote")+"]",r=new RegExp("("+n+"|^)(["+a.getData("char")+"]{"+t.min+",}) \\2("+n+"|$)","gi");return e.replace(r,"$1$2$3")},settings:{min:2},disabled:!0}),f.addRule({name:"common/punctuation/apostrophe",handler:function(e,t,a){var n="(["+a.getData("char")+"])",r=new RegExp(n+"'"+n,"gi");return e.replace(r,"$1\u2019$2")}}),f.addRule({name:"common/punctuation/delDoublePunctuation",handler:function(e){return e.replace(/(^|[^,]),,(?!,)/g,"$1,").replace(/(^|[^:])::(?!:)/g,"$1:").replace(/(^|[^!?.])\.\.(?!\.)/g,"$1.").replace(/(^|[^;]);;(?!;)/g,"$1;").replace(/(^|[^?])\?\?(?!\?)/g,"$1?")}}),f.addRule({name:"common/punctuation/hellip",handler:function(e,t,a){return"ru"===a.prefs.locale[0]?e.replace(/(^|[^.])\.{3,4}(?=[^.]|$)/g,"$1\u2026"):e.replace(/(^|[^.])\.{3}(\.?)(?=[^.]|$)/g,"$1\u2026$2")}});var d,p,g,h,m,v,R,$,b,_={bufferQuotes:{left:"\uf005\uf006\uf007",right:"\uf008\uf009\uf0a0"},maxLevel:3,beforeLeft:" \n\t\xa0[(",afterRight:" \n\t\xa0!?.:;#*,\u2026)",process:function(e){var t=e.context.text;if(!this.count(t).total)return t;var a=e.settings,n=e.settings.left[0]===e.settings.right[0];return n&&(e.settings=f.deepCopy(e.settings),e.settings.left=this.bufferQuotes.left.slice(0,e.settings.left.length),e.settings.right=this.bufferQuotes.right.slice(0,e.settings.right.length)),e.settings.spacing&&(t=this.removeSpacing(t,e.settings)),t=this.set(t,e),e.settings.spacing&&(t=this.setSpacing(t,e.settings)),e.settings.removeDuplicateQuotes&&(t=this.removeDuplicates(t,e.settings)),n&&(t=this.returnOriginalQuotes(t,a,e.settings),e.settings=a),t},returnOriginalQuotes:function(e,t,a){for(var n={},r=0;r<a.left.length;r++)n[a.left[r]]=t.left[r],n[a.right[r]]=t.right[r];return e.replace(new RegExp("["+a.left+a.right+"]","g"),function(e){return n[e]})},count:function(e){var t={total:0};return e.replace(new RegExp("["+f.getData("common/quote")+"]","g"),function(e){return t[e]||(t[e]=0),t[e]++,t.total++,e}),t},removeDuplicates:function(e,t){var a=t.left[0],n=t.left[1]||a,r=t.right[0];return a!==n?e:e.replace(new RegExp(a+a,"g"),a).replace(new RegExp(r+r,"g"),r)},removeSpacing:function(e,t){for(var a=0,n=t.left.length;a<n;a++){var r=t.left[a],s=t.right[a];e=e.replace(new RegExp(r+"([ \u202f\xa0])","g"),r).replace(new RegExp("([ \u202f\xa0])"+s,"g"),s)}return e},setSpacing:function(e,t){for(var a=0,n=t.left.length;a<n;a++){var r=t.left[a],s=t.right[a];e=e.replace(new RegExp(r+"([^\u202f])","g"),r+"\u202f$1").replace(new RegExp("([^\u202f])"+s,"g"),"$1\u202f"+s)}return e},set:function(e,t){var a=f._privateLabel,n=f.getData("common/quote"),r=t.settings.left[0],s=t.settings.left[1]||r,i=t.settings.right[0],u=new RegExp("(^|["+this.beforeLeft+"])(["+n+"]{1,"+this.maxLevel+"})(?=[^\\s"+a+"])","gim"),l=new RegExp("([^\\s"+a+"])(["+n+"]{1,"+this.maxLevel+"})(?=["+this.afterRight+"]|$)","gim");return e=e.replace(u,function(e,t,a){return t+f._repeat(r,a.length)}).replace(l,function(e,t,a){return t+f._repeat(i,a.length)}),e=this.setAboveTags(e,t),r!==s&&(e=this.setInner(e,t.settings)),e},setAboveTags:function(o,c){var d=this,p=f._privateLabel,e=f.getData("common/quote"),g=c.settings.left[0],h=c.settings.right[0];return o.replace(new RegExp("(^|.)(["+e+"])(.|$)","gm"),function(e,t,a,n,r){if(t!==p&&n!==p)return e;if(t===p&&n===p)return'"'===a?t+d.getAboveTwoTags(o,r+1,c)+n:e;if(t===p){var s=-1<d.afterRight.indexOf(n),i=d.getPrevTagInfo(o,r-1,c);return s&&i&&"html"===i.group?t+(i.isClosing?h:g)+n:t+(!n||s?h:g)+n}var u=-1<d.beforeLeft.indexOf(t),l=d.getNextTagInfo(o,r+1,c);return u&&l&&"html"===l.group?t+(l.isClosing?h:g)+n:t+(!t||u?g:h)+n})},getAboveTwoTags:function(e,t,a){var n=this.getPrevTagInfo(e,t,a),r=this.getNextTagInfo(e,t,a);if(n&&"html"===n.group){if(!n.isClosing)return a.settings.left[0];if(r&&r.isClosing&&n.isClosing)return a.settings.right[0]}return e[t]},getPrevTagInfo:function(e,t,a){var n=a.safeTags.getPrevLabel(e,t-1);if(n){var r=a.safeTags.getTagByLabel(a.context,n);if(r)return a.safeTags.getTagInfo(r)}return null},getNextTagInfo:function(e,t,a){var n=a.safeTags.getNextLabel(e,t+1);if(n){var r=a.safeTags.getTagByLabel(a.context,n);if(r)return a.safeTags.getTagInfo(r)}return null},setInner:function(e,t){for(var a=[],n=[],r=0;r<t.left.length;r++)a.push(t.left[r]),n.push(t.right[r]);for(var s=t.left[0],i=t.right[0],u=a.length-1,l=-1,o="",c=0,d=e.length;c<d;c++){var p=e[c];p===s?(u<++l&&(l=u),o+=a[l]):p===i?l<=-1?o+=n[l=0]:(o+=n[l],--l<-1&&(l=-1)):('"'===p&&(l=-1),o+=p)}var g=this.count(o,t);return g[s]!==g[i]?e:o}};function x(e){var t,a,n=e[0],r="";if(e.length<8)return y(e);if(10<e.length)if("+"===n){if("7"!==e[1])return e;t=!0,e=e.substr(2)}else"8"===n&&(a=!0,e=e.substr(1));for(var s=8;2<=s;s--){var i=+e.substr(0,s);if(-1<R.indexOf(i)){r=e.substr(0,s),e=e.substr(s);break}}return r||(r=e.substr(0,5),e=e.substr(5)),(t?"+7\xa0":"")+(a?"8\xa0":"")+function(e){var t=+e,a=e.length,n=[e],r=!1;if(3<a)switch(a){case 4:n=[e.substr(0,2),e.substr(2,2)];break;case 5:n=[e.substr(0,3),e.substr(3,3)];break;case 6:n=[e.substr(0,2),e.substr(2,2),e.substr(4,2)]}else r=900<t&&t<=999||495==t||499==t;return n=n.join("-"),r?n:"("+n+")"}(r)+"\xa0"+y(e)}function y(e){var t="";return e.length%2&&(t=e[0],t+=e.length<=5?"-":"",e=e.substr(1,e.length-1)),t+e.split(/(?=(?:\d\d)+$)/).join("-")}function E(e){return e.replace(/[^\d+]/g,"")}return f.addRule({name:"common/punctuation/quote",handler:function(e,t,a){var n=t[a.prefs.locale[0]];return n?_.process({context:a,settings:n,safeTags:this._safeTags}):e},settings:function(){var t={};return f.getLocales().forEach(function(e){t[e]=f.deepCopy(f.getData(e+"/quote"))}),t}}),f.addRule({name:"common/punctuation/quoteLink",queue:"show-safe-tags-html",index:"+5",handler:function(e,t,a){var n=this.getSetting("common/punctuation/quote",a.prefs.locale[0]);if(!n)return e;var r=f.HtmlEntities,s=r.getByUtf(n.left[0]),i=r.getByUtf(n.right[0]),u=r.getByUtf(n.left[1]),l=r.getByUtf(n.right[1]);u=u?"|"+u:"",l=l?"|"+l:"";var o=new RegExp("(<[aA]\\s[^>]*?>)("+s+u+")([^]*?)("+i+l+")(</[aA]>)","g");return e.replace(o,"$2$1$3$5$4")}}),f.addRule({name:"common/symbols/arrow",handler:function(e){return f._replace(e,[[/(^|[^-])->(?!>)/g,"$1\u2192"],[/(^|[^<])<-(?!-)/g,"$1\u2190"]])}}),f.addRule({name:"common/symbols/cf",handler:function(e){var t=new RegExp('(^|[\\s(\\[+\u2248\xb1\u2212\u2014\u2013\\-])(\\d+(?:[.,]\\d+)?)[ \xa0\u2009]?(C|F)([\\W\\s.,:!?")\\]]|$)',"mg");return e.replace(t,"$1$2\u2009\xb0$3$4")}}),f.addRule({name:"common/symbols/copy",handler:function(e){return f._replace(e,[[/\(r\)/gi,"\xae"],[/(copyright )?\((c|\u0441)\)/gi,"\xa9"],[/\(tm\)/gi,"\u2122"]])}}),f.addRule({name:"common/space/afterPunctuation",handler:function(e){var t=f._privateLabel,a=new RegExp("(!|;|\\?)([^).\u2026!;?\\s[\\])"+t+f.getData("common/quote")+"])","g"),n=new RegExp('(\\D)(,|:)([^)",:.?\\s\\/\\\\'+t+"])","g");return e.replace(a,"$1 $2").replace(n,"$1$2 $3")}}),f.addRule({name:"common/space/beforeBracket",handler:function(e,t,a){var n=new RegExp("(["+a.getData("char")+".!?,;\u2026)])\\(","gi");return e.replace(n,"$1 (")}}),f.addRule({name:"common/space/bracket",handler:function(e){return e.replace(/(\() +/g,"(").replace(/ +\)/g,")")}}),f.addRule({name:"common/space/delBeforePercent",handler:function(e){return e.replace(/(\d)( |\u00A0)(%|\u2030|\u2031)/g,"$1$3")}}),f.addRule({name:"common/space/delBeforePunctuation",handler:function(e){return e.replace(/([!?]) (?=[!?])/g,"$1").replace(/(^|[^!?:;,.\u2026]) ([!?:;,.])(?!\))/g,"$1$2")}}),f.addRule({name:"common/space/delLeadingBlanks",handler:function(e){return e.replace(/\n[ \t]+/g,"\n")},disabled:!0}),f.addRule({name:"common/space/delRepeatN",index:"-1",handler:function(e){return e.replace(/\n{3,}/g,"\n\n")}}),f.addRule({name:"common/space/delRepeatSpace",index:"-1",handler:function(e){return e.replace(/([^\n \t])[ \t]{2,}(?![\n \t])/g,"$1 ")}}),f.addRule({name:"common/space/delTrailingBlanks",index:"-3",handler:function(e){return e.replace(/[ \t]+\n/g,"\n")}}),f.addRule({name:"common/space/replaceTab",index:"-5",handler:function(e){return e.replace(/\t/g,"    ")}}),f.addRule({name:"common/space/squareBracket",handler:function(e){return e.replace(/(\[) +/g,"[").replace(/ +\]/g,"]")}}),f.addRule({name:"common/space/trimLeft",index:"-4",handler:String.prototype.trimLeft?function(e){return e.trimLeft()}:function(e){return e.replace(/^[\s\uFEFF\xA0]+/g,"")}}),f.addRule({name:"common/space/trimRight",index:"-3",live:!1,handler:String.prototype.trimRight?function(e){return e.trimRight()}:function(e){return e.replace(/[\s\uFEFF\xA0]+$/g,"")}}),f.addRule({name:"en-US/dash/main",index:"-5",handler:function(e){var t=f.getData("common/dash"),a="[ ".concat("\xa0","]"),n="[ ".concat("\xa0","\n]"),r=new RegExp("".concat(a,"(").concat(t,")(").concat(n,")"),"g");return e.replace(r,"".concat("\xa0").concat("\u2014","$2"))}}),f.addRule({name:"ru/date/fromISO",handler:function(e){var t="(-|\\.|\\/)",a="(-|\\/)",n=new RegExp("(^|\\D)(\\d{4})"+t+"(\\d{2})"+t+"(\\d{2})(\\D|$)","gi"),r=new RegExp("(^|\\D)(\\d{2})"+a+"(\\d{2})"+a+"(\\d{4})(\\D|$)","gi");return e.replace(n,"$1$6.$4.$2$7").replace(r,"$1$4.$2.$6$7")}}),f.addRule({name:"ru/date/weekday",handler:function(e){var t=f.getData("ru/monthGenCase"),a=f.getData("ru/weekday"),n=new RegExp("(\\d)( |\xa0)("+t+"),( |\xa0)("+a+")","gi");return e.replace(n,function(){var e=arguments;return e[1]+e[2]+e[3].toLowerCase()+","+e[4]+e[5].toLowerCase()})}}),f.addRule({name:"ru/dash/centuries",handler:function(e,t){var a="("+f.getData("common/dash")+")",n=new RegExp("(X|I|V)[ |\xa0]?"+a+"[ |\xa0]?(X|I|V)","g");return e.replace(n,"$1"+t.dash+"$3")},settings:{dash:"\u2013"}}),f.addRule({name:"ru/dash/daysMonth",handler:function(e,t){var a=new RegExp("(^|\\s)([123]?\\d)("+f.getData("common/dash")+")([123]?\\d)[ \xa0]("+f.getData("ru/monthGenCase")+")","g");return e.replace(a,"$1$2"+t.dash+"$4\xa0$5")},settings:{dash:"\u2013"}}),f.addRule({name:"ru/dash/de",handler:function(e){var t=new RegExp("([a-\u044f\u0451]+) \u0434\u0435"+f.getData("ru/dashAfterDe"),"g");return e.replace(t,"$1-\u0434\u0435")},disabled:!0}),f.addRule({name:"ru/dash/decade",handler:function(e,t){var a=new RegExp("(^|\\s)(\\d{3}|\\d)0("+f.getData("common/dash")+")(\\d{3}|\\d)0(-\u0435[ \xa0])(?=\u0433\\.?[ \xa0]?\u0433|\u0433\u043e\u0434)","g");return e.replace(a,"$1$20"+t.dash+"$40$5")},settings:{dash:"\u2013"}}),f.addRule({name:"ru/dash/directSpeech",handler:function(e){var t=f.getData("common/dash"),a=new RegExp('(["\xbb\u2018\u201c,])[ |\xa0]?('+t+")[ |\xa0]","g"),n=new RegExp("(^|"+f._privateLabel+")("+t+")( |\xa0)","gm"),r=new RegExp("([.\u2026?!])[ \xa0]("+t+")[ \xa0]","g");return e.replace(a,"$1\xa0\u2014 ").replace(n,"$1\u2014\xa0").replace(r,"$1 \u2014\xa0")}}),f.addRule({name:"ru/dash/izpod",handler:function(e){var t=new RegExp(f.getData("ru/dashBefore")+"(\u0418|\u0438)\u0437 \u043f\u043e\u0434"+f.getData("ru/dashAfter"),"g");return e.replace(t,"$1$2\u0437-\u043f\u043e\u0434")}}),f.addRule({name:"ru/dash/izza",handler:function(e){var t=new RegExp(f.getData("ru/dashBefore")+"(\u0418|\u0438)\u0437 \u0437\u0430"+f.getData("ru/dashAfter"),"g");return e.replace(t,"$1$2\u0437-\u0437\u0430")}}),f.addRule({name:"ru/dash/ka",handler:function(e){var t=new RegExp("([a-\u044f\u0451]+) \u043a\u0430(\u0441\u044c)?"+f.getData("ru/dashAfter"),"g");return e.replace(t,"$1-\u043a\u0430$2")}}),f.addRule({name:"ru/dash/koe",handler:function(e){var t=new RegExp(f.getData("ru/dashBefore")+"([\u041a\u043a]\u043e[\u0435\u0439])\\s([\u0430-\u044f\u0451]{3,})"+f.getData("ru/dashAfter"),"g");return e.replace(t,"$1$2-$3")}}),f.addRule({name:"ru/dash/main",index:"-5",handler:function(e){var t=f.getData("common/dash"),a=new RegExp("([ \xa0])("+t+")([ \xa0\\n])","g");return e.replace(a,"\xa0\u2014$3")}}),f.addRule({name:"ru/dash/month",handler:function(e,t){var a="("+f.getData("ru/month")+")",n="("+f.getData("ru/monthPreCase")+")",r=f.getData("common/dash"),s=new RegExp(a+" ?("+r+") ?"+a,"gi"),i=new RegExp(n+" ?("+r+") ?"+n,"gi"),u="$1"+t.dash+"$3";return e.replace(s,u).replace(i,u)},settings:{dash:"\u2013"}}),f.addRule({name:"ru/dash/surname",handler:function(e){var t=new RegExp("([\u0410-\u042f\u0401][\u0430-\u044f\u0451]+)\\s-([\u0430-\u044f\u0451]{1,3})(?![^\u0430-\u044f\u0451]|$)","g");return e.replace(t,"$1\xa0\u2014$2")}}),f.addRule({name:"ru/dash/taki",handler:function(e){var t=new RegExp("(\u0432\u0435\u0440\u043d\u043e|\u0434\u043e\u0432\u043e\u043b\u044c\u043d\u043e|\u043e\u043f\u044f\u0442\u044c|\u043f\u0440\u044f\u043c\u043e|\u0442\u0430\u043a|\u0432\u0441[\u0435\u0451]|\u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043b\u044c\u043d\u043e|\u043d\u0435\u0443\u0436\u0435\u043b\u0438)\\s(\u0442\u0430\u043a\u0438)"+f.getData("ru/dashAfter"),"g");return e.replace(t,"$1-$2")}}),f.addRule({name:"ru/dash/time",handler:function(e,t){var a=new RegExp(f.getData("ru/dashBefore")+"(\\d?\\d:[0-5]\\d)"+f.getData("common/dash")+"(\\d?\\d:[0-5]\\d)"+f.getData("ru/dashAfter"),"g");return e.replace(a,"$1$2"+t.dash+"$3")},settings:{dash:"\u2013"}}),f.addRule({name:"ru/dash/to",handler:function(e){var t=new RegExp("("+["\u043e\u0442\u043a\u0443\u0434\u0430","\u043a\u0443\u0434\u0430","\u0433\u0434\u0435","\u043a\u043e\u0433\u0434\u0430","\u0437\u0430\u0447\u0435\u043c","\u043f\u043e\u0447\u0435\u043c\u0443","\u043a\u0430\u043a","\u043a\u0430\u043a\u043e[\u0435\u0439\u043c]","\u043a\u0430\u043a\u0430\u044f","\u043a\u0430\u043a\u0438[\u0435\u043c\u0445]","\u043a\u0430\u043a\u0438\u043c\u0438","\u043a\u0430\u043a\u0443\u044e","\u0447\u0442\u043e","\u0447\u0435\u0433\u043e","\u0447\u0435[\u0439\u043c]","\u0447\u044c\u0438\u043c?","\u043a\u0442\u043e","\u043a\u043e\u0433\u043e","\u043a\u043e\u043c\u0443","\u043a\u0435\u043c"].join("|")+")( | -|- )(\u0442\u043e|\u043b\u0438\u0431\u043e|\u043d\u0438\u0431\u0443\u0434\u044c)"+f.getData("ru/dashAfter"),"gi");return e.replace(t,"$1-$3")}}),f.addRule({name:"ru/dash/weekday",handler:function(e,t){var a="("+f.getData("ru/weekday")+")",n=new RegExp(a+" ?("+f.getData("common/dash")+") ?"+a,"gi");return e.replace(n,"$1"+t.dash+"$3")},settings:{dash:"\u2013"}}),f.addRule({name:"ru/dash/years",handler:function(e,s){var t=f.getData("common/dash"),a=new RegExp("(\\D|^)(\\d{4})[ \xa0]?("+t+")[ \xa0]?(\\d{4})(?=[ \xa0]?\u0433)","g");return e.replace(a,function(e,t,a,n,r){return parseInt(a,10)<parseInt(r,10)?t+a+s.dash+r:e})},settings:{dash:"\u2013"}}),f.addRule({name:"ru/money/currency",handler:function(e){var t="([$\u20ac\xa5\u04b0\xa3\u20a4\u20bd])",a=new RegExp("(^|[\\D]{2})"+t+" ?([\\d.,]+([ \xa0\u2009\u202f]\\d{3})*)([ \xa0\u2009\u202f]?(\u0442\u044b\u0441\\.|\u043c\u043b\u043d|\u043c\u043b\u0440\u0434|\u0442\u0440\u043b\u043d))?","gm"),n=new RegExp("(^|[\\D])([\\d.,]+) ?"+t,"gm");return e.replace(a,function(e,t,a,n,r,s,i){return t+n+(i?"\xa0"+i:"")+"\xa0"+a}).replace(n,"$1$2\xa0$3")},disabled:!0}),f.addRule({name:"ru/money/ruble",handler:function(e){var t="$1\xa0\u20bd",a="(\\d+)( |\xa0)?(\u0440|\u0440\u0443\u0431)\\.",n=new RegExp("^"+a+"$","g"),r=new RegExp(a+"(?=[!?,:;])","g"),s=new RegExp(a+"(?=\\s+[A-\u042f\u0401])","g");return e.replace(n,t).replace(r,t).replace(s,t+".")},disabled:!0}),f.addRule({name:"ru/number/comma",handler:function(e){return e.replace(/(^|\s)(\d+)\.(\d+[\u00A0\u2009\u202F ]*?[%\u2030\xb0\xd7x])/gim,"$1$2,$3")}}),f.addRule({name:"ru/number/ordinals",handler:function(e,t,a){var n=new RegExp("(\\d[%\u2030]?)-(\u044b\u0439|\u043e\u0439|\u0430\u044f|\u043e\u0435|\u044b\u0435|\u044b\u043c|\u043e\u043c|\u044b\u0445|\u043e\u0433\u043e|\u043e\u043c\u0443|\u044b\u043c\u0438)(?!["+a.getData("char")+"])","g");return e.replace(n,function(e,t,a){return t+"-"+{"\u043e\u0439":"\u0439","\u044b\u0439":"\u0439","\u0430\u044f":"\u044f","\u043e\u0435":"\u0435","\u044b\u0435":"\u0435","\u044b\u043c":"\u043c","\u043e\u043c":"\u043c","\u044b\u0445":"\u0445","\u043e\u0433\u043e":"\u0433\u043e","\u043e\u043c\u0443":"\u043c\u0443","\u044b\u043c\u0438":"\u043c\u0438"}[a]})}}),d=["typograf-oa-lbracket","typograf-oa-n-lbracket","typograf-oa-sp-lbracket"],p="ru/optalign/bracket",f.addRule({name:p,handler:function(e){return e.replace(/( |\u00A0)\(/g,'<span class="typograf-oa-sp-lbracket">$1</span><span class="typograf-oa-lbracket">(</span>').replace(/^\(/gm,'<span class="typograf-oa-n-lbracket">(</span>')},disabled:!0,htmlAttrs:!1}).addInnerRule({name:p,queue:"start",handler:function(e){return f._removeOptAlignTags(e,d)}}).addInnerRule({name:p,queue:"end",handler:function(e){return f._removeOptAlignTagsFromTitle(e,d)}}),g=["typograf-oa-comma","typograf-oa-comma-sp"],h="ru/optalign/comma",f.addRule({name:h,handler:function(e,t,a){var n=new RegExp("(["+a.getData("char")+"\\d\u0301]+), ","gi");return e.replace(n,'$1<span class="typograf-oa-comma">,</span><span class="typograf-oa-comma-sp"> </span>')},disabled:!0,htmlAttrs:!1}).addInnerRule({name:h,queue:"start",handler:function(e){return f._removeOptAlignTags(e,g)}}).addInnerRule({name:h,queue:"end",handler:function(e){return f._removeOptAlignTagsFromTitle(e,g)}}),f._removeOptAlignTags=function(e,t){var a=new RegExp('<span class="('+t.join("|")+')">([^]*?)</span>',"g");return e.replace(a,"$2")},f._removeOptAlignTagsFromTitle=function(e,t){return e.replace(/<title>[^]*?<\/title>/i,function(e){return f._removeOptAlignTags(e,t)})},m=["typograf-oa-lquote","typograf-oa-n-lquote","typograf-oa-sp-lquote"],v="ru/optalign/quote",f.addRule({name:v,handler:function(e){var t=this.getSetting("common/punctuation/quote","ru"),a="(["+t.left[0]+(t.left[1]||"")+"])",n=new RegExp("(^|\n\n|"+f._privateLabel+")("+a+")","g"),r=new RegExp("([^\n"+f._privateLabel+"])([ \xa0\n])("+a+")","gi");return e.replace(n,'$1<span class="typograf-oa-n-lquote">$2</span>').replace(r,'$1<span class="typograf-oa-sp-lquote">$2</span><span class="typograf-oa-lquote">$3</span>')},disabled:!0,htmlAttrs:!1}).addInnerRule({name:v,queue:"start",handler:function(e){return f._removeOptAlignTags(e,m)}}).addInnerRule({name:v,queue:"end",handler:function(e){return f._removeOptAlignTagsFromTitle(e,m)}}),f.addRule({name:"ru/nbsp/abbr",handler:function(e){function t(e,t,a,n){return"\u0434\u0434"===a&&"\u043c\u043c"===n?e:-1<["\u0440\u0444","\u0440\u0443","\u0440\u0443\u0441","\u043e\u0440\u0433","\u0443\u043a\u0440","\u0431\u0433","\u0441\u0440\u0431"].indexOf(n)?e:t+a+".\xa0"+n+"."}var a=new RegExp("(^|\\s|"+f._privateLabel+")([\u0430-\u044f\u0451]{1,3})\\. ?([\u0430-\u044f\u0451]{1,3})\\.","g");return e.replace(a,t).replace(a,t)}}),f.addRule({name:"ru/nbsp/addr",handler:function(e){return e.replace(/(\s|^)(\u0434\u043e\u043c|\u0434\.|\u043a\u0432\.|\u043f\u043e\u0434\.|\u043f-\u0434) *(\d+)/gi,"$1$2\xa0$3").replace(/(\s|^)(\u043c\u043a\u0440-\u043d|\u043c\u043a-\u043d|\u043c\u043a\u0440\.|\u043c\u043a\u0440\u043d)\s/gi,"$1$2\xa0").replace(/(\s|^)(\u044d\u0442\.) *(-?\d+)/gi,"$1$2\xa0$3").replace(/(\s|^)(\d+) +\u044d\u0442\u0430\u0436([^\u0430-\u044f\u0451]|$)/gi,"$1$2\xa0\u044d\u0442\u0430\u0436$3").replace(/(\s|^)\u043b\u0438\u0442\u0435\u0440\s([\u0410-\u042f]|$)/gi,"$1\u043b\u0438\u0442\u0435\u0440\xa0$2").replace(/(\s|^)(\u043e\u0431\u043b|\u043a\u0440|\u0441\u0442|\u043f\u043e\u0441|\u0441|\u0434|\u0443\u043b|\u043f\u0435\u0440|\u043f\u0440|\u043f\u0440-\u0442|\u043f\u0440\u043e\u0441\u043f|\u043f\u043b|\u0431\u0443\u043b|\u0431-\u0440|\u043d\u0430\u0431|\u0448|\u0442\u0443\u043f|\u043e\u0444|\u043a\u043e\u043c\u043d?|\u0443\u0447|\u0432\u043b|\u0432\u043b\u0430\u0434|\u0441\u0442\u0440|\u043a\u043e\u0440)\. *([\u0430-\u044f\u0451a-z\d]+)/gi,"$1$2.\xa0$3").replace(/(\D[ \u00A0]|^)\u0433\. ?([\u0410-\u042f\u0401])/gm,"$1\u0433.\xa0$2")}}),f.addRule({name:"ru/nbsp/afterNumberSign",handler:function(e){return e.replace(/\u2116[ \u00A0\u2009]?(\d|\u043f\/\u043f)/g,"\u2116\u202f$1")}}),f.addRule({name:"ru/nbsp/beforeParticle",index:"+5",handler:function(e){var t="(\u043b\u0438|\u043b\u044c|\u0436\u0435|\u0436|\u0431\u044b|\u0431)",a=new RegExp("([\u0410-\u042f\u0401\u0430-\u044f\u0451]) "+t+'(?=[,;:?!"\u2018\u201c\xbb])',"g"),n=new RegExp("([\u0410-\u042f\u0401\u0430-\u044f\u0451])[ \xa0]"+t+"[ \xa0]","g");return e.replace(a,"$1\xa0$2").replace(n,"$1\xa0$2 ")}}),f.addRule({name:"ru/nbsp/centuries",handler:function(e){var t=f.getData("common/dash"),a="(^|\\s)([VIX]+)",n='(?=[,;:?!"\u2018\u201c\xbb]|$)',r=new RegExp(a+"[ \xa0]?\u0432\\.?"+n,"gm"),s=new RegExp(a+"("+t+")([VIX]+)[ \xa0]?\u0432\\.?([ \xa0]?\u0432\\.?)?"+n,"gm");return e.replace(r,"$1$2\xa0\u0432.").replace(s,"$1$2$3$4\xa0\u0432\u0432.")}}),f.addRule({name:"ru/nbsp/dayMonth",handler:function(e){var t=new RegExp("(\\d{1,2}) ("+f.getData("ru/shortMonth")+")","gi");return e.replace(t,"$1\xa0$2")}}),f.addRule({name:"ru/nbsp/groupNumbers",handler:function(e){var t=new RegExp("(^ ?|\\D |".concat(f._privateLabel,")(\\d{1,3}([ \xa0\u202f\u2009]\\d{3})+)(?! ?[\\d-])"),"gm");return e.replace(t,function(e,t,a){return t+a.replace(/\s/g,"\u202f")})}}),f.addRule({name:"ru/nbsp/initials",handler:function(e){var t=f.getData("ru/quote"),a=new RegExp("(^|[\xa0\u202f "+t.left+f._privateLabel+'"])([\u0410-\u042f\u0401])\\.[\xa0\u202f ]?([\u0410-\u042f\u0401])\\.[\xa0\u202f ]?([\u0410-\u042f\u0401][\u0430-\u044f\u0451]+)(?=[\\s.,;:?!"'+t.right+"]|$)","gm");return e.replace(a,"$1$2.\xa0$3.\xa0$4")}}),f.addRule({name:"ru/nbsp/m",index:"+5",handler:function(e){var t=f._privateLabel,a=new RegExp("(^|[\\s,."+t+"])(\\d+)[ \xa0]?(\u043c\u043c?|\u0441\u043c|\u043a\u043c|\u0434\u043c|\u0433\u043c|mm?|km|cm|dm)([23\xb2\xb3])?([\\s.!?,;"+t+"]|$)","gm");return e.replace(a,function(e,t,a,n,r,s){return t+a+"\xa0"+n+{2:"\xb2","\xb2":"\xb2",3:"\xb3","\xb3":"\xb3","":""}[r||""]+("\xa0"===s?" ":s)})}}),f.addRule({name:"ru/nbsp/mln",handler:function(e){return e.replace(/(\d) ?(\u0442\u044b\u0441|\u043c\u043b\u043d|\u043c\u043b\u0440\u0434|\u0442\u0440\u043b\u043d)(\.|\s|$)/gi,"$1\xa0$2$3")}}),f.addRule({name:"ru/nbsp/ooo",handler:function(e){return e.replace(/(^|[^a-\u044f\u0451A-\u042f\u0401])(\u041e\u041e\u041e|\u041e\u0410\u041e|\u0417\u0410\u041e|\u041d\u0418\u0418|\u041f\u0411\u041e\u042e\u041b) /g,"$1$2\xa0")}}),f.addRule({name:"ru/nbsp/page",handler:function(e){var t=new RegExp("(^|[)\\s"+f._privateLabel+"])(\u0441\u0442\u0440|\u0433\u043b|\u0440\u0438\u0441|\u0438\u043b\u043b?|\u0441\u0442|\u043f|c)\\. *(\\d+)([\\s.,?!;:]|$)","gim");return e.replace(t,"$1$2.\xa0$3$4")}}),f.addRule({name:"ru/nbsp/ps",handler:function(e){var t=new RegExp("(^|\\s|"+f._privateLabel+")[p\u0437]\\.[ \xa0]?([p\u0437]\\.[ \xa0]?)?[s\u044b]\\.:? ","gim");return e.replace(t,function(e,t,a){return t+(a?"P.\xa0P.\xa0S. ":"P.\xa0S. ")})}}),f.addRule({name:"ru/nbsp/rubleKopek",handler:function(e){return e.replace(/(\d) ?(?=(\u0440\u0443\u0431|\u043a\u043e\u043f)\.)/g,"$1\xa0")}}),f.addRule({name:"ru/nbsp/see",handler:function(e){var t=new RegExp("(^|\\s|"+f._privateLabel+"|\\()(\u0441\u043c|\u0438\u043c)\\.[ \xa0]?([\u0430-\u044f\u04510-9a-z]+)([\\s.,?!]|$)","gi");return e.replace(t,function(e,t,a,n,r){return("\xa0"===t?" ":t)+a+".\xa0"+n+r})}}),f.addRule({name:"ru/nbsp/year",handler:function(e){return e.replace(/(^|\D)(\d{4}) ?\u0433([ ,;.\n]|$)/g,"$1$2\xa0\u0433$3")}}),f.addRule({name:"ru/nbsp/years",index:"+5",handler:function(e){var t=f.getData("common/dash"),a=new RegExp("(^|\\D)(\\d{4})("+t+')(\\d{4})[ \xa0]?\u0433\\.?([ \xa0]?\u0433\\.)?(?=[,;:?!"\u2018\u201c\xbb\\s]|$)',"gm");return e.replace(a,"$1$2$3$4\xa0\u0433\u0433.")}}),f.addRule({name:"ru/other/accent",handler:function(e){return e.replace(/([\u0430-\u044f\u0451])([\u0410\u0415\u0401\u0418\u041e\u0423\u042b\u042d\u042e\u042f])([^\u0410-\u042f\u0401\w]|$)/g,function(e,t,a,n){return t+a.toLowerCase()+"\u0301"+n})},disabled:!0}),R=[],[4162,416332,8512,851111,4722,4725,391379,8442,4732,4152,4154451,4154459,4154455,41544513,8142,8332,8612,8622,3525,812,8342,8152,3812,4862,3422,342633,8112,9142,8452,3432,3434,3435,4812,8432,8439,3822,4872,3412,3511,3512,3022,4112,4852,4855,3852,3854,8182,818,90,3472,4741,4764,4832,4922,8172,8202,8722,4932,493,3952,3951,3953,411533,4842,3842,3843,8212,4942,"39131-39179","39190-39199",391,4712,4742,8362,495,499,4966,4964,4967,498,8312,8313,3832,383612,3532,8412,4232,423370,423630,8632,8642,8482,4242,8672,8652,4752,4822,482502,4826300,3452,8422,4212,3466,3462,8712,8352,"901-934","936-939","950-953",958,"960-969","977-989","991-997",999].forEach(function(e){if("string"==typeof e)for(var t=e.split("-"),a=+t[0];a<=+t[1];a++)R.push(a);else R.push(e)}),f.addRule({name:"ru/other/phone-number",live:!1,handler:function(e){var t=f._privateLabel,a=new RegExp("(^|,| |"+t+")(\\+7[\\d\\(\\) \xa0-]{10,18})(?=,|;|"+t+"|$)","gm");return e.replace(a,function(e,t,a){var n=E(a);return 12===n.length?t+x(n):e}).replace(/(^|[^\u0430-\u044f\u0451])([\u260e\u260f\u2706\ud83d\udce0\ud83d\udcde\ud83d\udcf1]|\u0442\.|\u0442\u0435\u043b\.|\u0444\.|\u043c\u043e\u0431\.|\u0444\u0430\u043a\u0441|\u0441\u043e\u0442\u043e\u0432\u044b\u0439|\u043c\u043e\u0431\u0438\u043b\u044c\u043d\u044b\u0439|\u0442\u0435\u043b\u0435\u0444\u043e\u043d)(:?\s*?)([+\d(][\d \u00A0\-()]{3,}\d)/gi,function(e,t,a,n,r){var s=E(r);return 5<=s.length?t+a+n+x(s):e})}}),f.addRule({name:"ru/punctuation/ano",handler:function(e){var t=new RegExp("([^!?,:;\\-\u2012\u2013\u2014\\s])(\\s+)(\u0430|\u043d\u043e)(?= |\xa0|\\n)","g");return e.replace(t,"$1,$2$3")},queue:"hide-safe-tags-html"}),f.addRule({name:"ru/punctuation/exclamation",live:!1,handler:function(e){return e.replace(/(^|[^!])!{2}($|[^!])/gm,"$1!$2").replace(/(^|[^!])!{4}($|[^!])/gm,"$1!!!$2")}}),f.addRule({name:"ru/punctuation/exclamationQuestion",index:"+5",handler:function(e){var t=new RegExp("(^|[^!])!\\?([^?]|$)","g");return e.replace(t,"$1?!$2")}}),f.addRule({name:"ru/punctuation/hellipQuestion",handler:function(e){return e.replace(/(^|[^.])(\.\.\.|\u2026),/g,"$1\u2026").replace(/(!|\?)(\.\.\.|\u2026)(?=[^.]|$)/g,"$1..")}}),f.addRule({name:"ru/space/afterHellip",handler:function(e){return e.replace(/([\u0430-\u044f\u0451])(\.\.\.|\u2026)([\u0410-\u042f\u0401])/g,"$1$2 $3").replace(/([?!]\.\.)([\u0430-\u044f\u0451a-z])/gi,"$1 $2")}}),f.addRule({name:"ru/space/year",handler:function(e,t,a){var n=new RegExp("(^| |\xa0)(\\d{3,4})(\u0433\u043e\u0434([\u0430\u0443\u0435]|\u043e\u043c)?)([^"+a.getData("char")+"]|$)","g");return e.replace(n,"$1$2 $3$5")}}),f.addRule({name:"ru/symbols/NN",handler:function(e){return e.replace(/\u2116\u2116/g,"\u2116")}}),$={A:"\u0410",a:"\u0430",B:"\u0412",E:"\u0415",e:"\u0435",K:"\u041a",M:"\u041c",H:"\u041d",O:"\u041e",o:"\u043e",P:"\u0420",p:"\u0440",C:"\u0421",c:"\u0441",T:"\u0422",y:"\u0443",X:"\u0425",x:"\u0445"},b=Object.keys($).join(""),f.addRule({name:"ru/typo/switchingKeyboardLayout",handler:function(e){var t=new RegExp("(["+b+"]{1,3})(?=[\u0410-\u042f\u0401\u0430-\u044f\u0451]+?)","g");return e.replace(t,function(e,t){for(var a="",n=0;n<t.length;n++)a+=$[t[n]];return a})}}),f});

/***/ }),

/***/ "./src/code.js":
/*!*********************!*\
  !*** ./src/code.js ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_typograf_dist_typograf_min_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/typograf/dist/typograf.min.js */ "./node_modules/typograf/dist/typograf.min.js");
/* harmony import */ var _node_modules_typograf_dist_typograf_min_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_typograf_dist_typograf_min_js__WEBPACK_IMPORTED_MODULE_0__);

const tp = new _node_modules_typograf_dist_typograf_min_js__WEBPACK_IMPORTED_MODULE_0__({locale: ['ru', 'en-US']});

const Diff = __webpack_require__(/*! text-diff */ "./node_modules/text-diff/diff.js");
const diff = new Diff();

function haveMixedStyle(obj, start = 0, end) {
    if (end === undefined) { 
        end = obj.characters.length;
    }
    return obj.getRangeFontName(start, end) === figma.mixed ||
           obj.getRangeFontSize(start, end) === figma.mixed || 
           obj.getRangeTextCase(start, end) === figma.mixed || 
           obj.getRangeTextDecoration(start, end) === figma.mixed || 
           obj.getRangeLetterSpacing(start, end) === figma.mixed || 
           obj.getRangeLineHeight(start, end) === figma.mixed || 
           obj.getRangeFills(start, end) === figma.mixed ||
           obj.getRangeTextStyleId(start, end) === figma.mixed ||
           obj.getRangeFillStyleId(start, end) === figma.mixed;
}

function getTextnodeStyle(obj, start = 0, end) {
    if (end === undefined) { 
        end = obj.characters.length;
    }
    let style = {};

    style.FontName = obj.getRangeFontName(start, end);
    style.FontSize = obj.getRangeFontSize(start, end);
    style.TextCase = obj.getRangeTextCase(start, end);
    style.TextDecoration = obj.getRangeTextDecoration(start, end);
    style.LetterSpacing = obj.getRangeLetterSpacing(start, end);
    style.LineHeight = obj.getRangeLineHeight(start, end);
    style.Fills = obj.getRangeFills(start, end);
    style.TextStyleId = obj.getRangeTextStyleId(start, end);
    style.FillStyleId = obj.getRangeFillStyleId(start, end);

    return style;    
}

function findStyleBorder(obj, start, left, right) {
    if (haveMixedStyle(obj, start, right)) {
        let mid = Math.floor((left + right)/2);
        if (haveMixedStyle(obj, start, mid) === false) {
            if (haveMixedStyle(obj, start, mid +1) || mid === right) {
                return mid;
            } else {
                return findStyleBorder(obj, start, mid+1, right);
            }
        } else {
            return findStyleBorder(obj, start, left, mid);
        }
    } else {
        return right;
    }
}

function saveTextnodeStyle(obj) {
    let end = obj.characters.length;
    let start = 0;
    let style = [];

    while (start < end) {
        let border = findStyleBorder(obj, start, start, end);
        style.push({
            start: start,
            end: border,
            style: getTextnodeStyle(obj, start, border)
        });
        start = border;
    }
    return style;
}

function applyTextnodeStyles(obj, styles) {
    styles.forEach(async function(st) {
        // Фигма требует, чтобы перед любыми операциями с текстом, происходила асинхронная загрузка шрифта — https://www.figma.com/plugin-docs/api/TextNode/
        await figma.loadFontAsync(st.style.FontName);
        obj.setRangeFontName(st.start, st.end, st.style.FontName);
        obj.setRangeFontSize(st.start, st.end, st.style.FontSize);
        obj.setRangeTextCase(st.start, st.end, st.style.TextCase);
        obj.setRangeTextDecoration(st.start, st.end, st.style.TextDecoration);
        obj.setRangeLetterSpacing(st.start, st.end, st.style.LetterSpacing);
        obj.setRangeLineHeight(st.start, st.end, st.style.LineHeight);
        obj.setRangeFills(st.start, st.end, st.style.Fills);
        obj.setRangeTextStyleId(st.start, st.end, st.style.TextStyleId);
        obj.setRangeFillStyleId(st.start, st.end, st.style.FillStyleId);
    })
}

async function loadFontsFromStyles(styles) {
    for (const st of styles) {
        await figma.loadFontAsync(st.style.FontName);
    }
}

function adjustStylesPositions(styles, textDiff) {
    console.log(textDiff)
    let position = 0;
    let correction = 0;
    let adjusted = [];

    for (let st of styles) {
        console.log('pos ', position, 'cor', correction, 'st', st.start, 'en', st.end)
        st.start = st.start + correction;
        while (position <= st.end) {
            let d = textDiff.shift();
            console.log(d)
            if (d === undefined) {
                break;
            }
            correction = correction + d[0]*d[1].length;
            position = position + (d[0] == 0 ? d[1].length : d[0]*d[1].length);
        }
        st.end = st.end + correction;
        console.log('New st', st.start, 'en', st.end)
        adjusted.push(st);
    }

    return adjusted;
}


async function typografText(obj) {
    if (obj.hasMissingFont != true) {
        let styles = saveTextnodeStyle(obj);
        await loadFontsFromStyles(styles).then(() => {
            const text = obj.characters;
            const newText = tp.execute(text);
            let textDiff = diff.main(text, newText);
            const newStyles = adjustStylesPositions(styles, textDiff);
            console.log(newStyles)

            obj.characters = newText;
            applyTextnodeStyles(obj, newStyles);
        });
    } else {
        figma.closePlugin("Text with missing fonts can't be typografed");
    }
}

const selection = figma.currentPage.selection.filter(layer => layer.type === 'TEXT');
if (selection.length === 0) {
    figma.closePlugin("Select at least 1 text layer");
} else {
    const promises = selection.map(typografText);
    Promise.all(promises).then(resolve => {
        figma.closePlugin();
    });
}


/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3RleHQtZGlmZi9kaWZmLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy90eXBvZ3JhZi9kaXN0L3R5cG9ncmFmLm1pbi5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvY29kZS5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7QUNsRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxlQUFlLHNCQUFzQjtBQUNyQzs7O0FBR0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixXQUFXLFNBQVM7QUFDcEI7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQjtBQUNBO0FBQ0EsWUFBWSxvQkFBb0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsV0FBVyxRQUFRO0FBQ25CO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsWUFBWSxvQkFBb0I7QUFDaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPO0FBQ2xCLFlBQVksb0JBQW9CO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLG9DQUFvQyxRQUFRO0FBQzVDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGNBQWM7O0FBRWQ7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixZQUFZLG9CQUFvQjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixjQUFjO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixXQUFXO0FBQzVCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsK0JBQStCLGlCQUFpQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0EsK0JBQStCLGlCQUFpQjtBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixZQUFZLG9CQUFvQjtBQUNoQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPO0FBQ2xCLGFBQWE7QUFDYjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxxQkFBcUI7QUFDckIsb0JBQW9COztBQUVwQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLE9BQU87QUFDcEIsY0FBYyxPQUFPO0FBQ3JCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFVBQVU7QUFDVjs7O0FBR0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0IsV0FBVyxnQkFBZ0I7QUFDM0I7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLGtCQUFrQjtBQUNuQztBQUNBO0FBQ0EsbUJBQW1CLGtCQUFrQjtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixZQUFZLE9BQU87QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsWUFBWSxPQUFPO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQSxXQUFXLE9BQU87QUFDbEIsV0FBVyxPQUFPO0FBQ2xCLFlBQVksT0FBTztBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsT0FBTztBQUNsQixXQUFXLE9BQU87QUFDbEIsWUFBWSxlQUFlO0FBQzNCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjtBQUNBLGlCQUFpQjs7QUFFakI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLE9BQU87QUFDcEIsYUFBYSxPQUFPO0FBQ3BCLGFBQWEsT0FBTztBQUNwQixjQUFjLGVBQWU7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQSxHQUFHO0FBQ0g7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQSxXQUFXLG9CQUFvQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQSxzQkFBc0I7QUFDdEIsMkJBQTJCO0FBQzNCLGFBQWEsUUFBUTtBQUNyQjtBQUNBO0FBQ0Esa0JBQWtCO0FBQ2xCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMENBQTBDO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUssT0FBTztBQUNaO0FBQ0E7QUFDQSxPQUFPO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQStCO0FBQy9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLE9BQU87QUFDcEIsYUFBYSxPQUFPO0FBQ3BCLGNBQWMsT0FBTztBQUNyQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBO0FBQ0EsS0FBSztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLFdBQVcsb0JBQW9CO0FBQy9CO0FBQ0E7QUFDQTtBQUNBLHNCQUFzQjtBQUN0QiwyQkFBMkI7QUFDM0IsYUFBYSxRQUFRO0FBQ3JCO0FBQ0E7QUFDQSxrQkFBa0I7QUFDbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMENBQTBDO0FBQzFDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLLE9BQU87QUFDWjtBQUNBO0FBQ0EsT0FBTztBQUNQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDJCQUEyQjtBQUMzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNULDZCQUE2QjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsb0JBQW9CO0FBQy9CO0FBQ0E7QUFDQSwrQkFBK0I7QUFDL0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVztBQUNYO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQjtBQUNoQjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE9BQU87QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsb0JBQW9CO0FBQy9CLFdBQVcsT0FBTztBQUNsQixZQUFZLE9BQU87QUFDbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLGtCQUFrQjtBQUMvQixzQ0FBc0M7QUFDdEM7QUFDQTtBQUNBLHNDQUFzQztBQUN0QztBQUNBO0FBQ0EsdUJBQXVCO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBLFdBQVcsb0JBQW9CO0FBQy9CLFlBQVksT0FBTztBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixrQkFBa0I7QUFDbkMseUJBQXlCO0FBQ3pCLDJCQUEyQjtBQUMzQiwrQ0FBK0MsNEJBQTRCO0FBQzNFLGtDQUFrQztBQUNsQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0IsWUFBWSxPQUFPO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixrQkFBa0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0IsWUFBWSxPQUFPO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixrQkFBa0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBLG9DQUFvQztBQUNwQztBQUNBLFdBQVcsb0JBQW9CO0FBQy9CLFlBQVksT0FBTztBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCLGtCQUFrQjtBQUNuQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxvQkFBb0I7QUFDL0IsWUFBWSxPQUFPO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLGlCQUFpQixrQkFBa0I7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0EsV0FBVyxPQUFPO0FBQ2xCLFdBQVcsT0FBTztBQUNsQixZQUFZLG9CQUFvQjtBQUNoQyxZQUFZLE9BQU87QUFDbkI7QUFDQTtBQUNBO0FBQ0Esc0JBQXNCO0FBQ3RCLGtCQUFrQjtBQUNsQjtBQUNBLGlCQUFpQixtQkFBbUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7Ozs7Ozs7Ozs7OztBQ3IzQ0E7QUFDQSxlQUFlLEtBQW9ELG9CQUFvQixTQUE4RCxDQUFDLGlCQUFpQixhQUFhLGNBQWMsaUZBQWlGLGdCQUFnQixhQUFhLG9HQUFvRyxLQUFLLGdCQUFnQiw4RUFBOEUsZ0JBQWdCLFlBQVksV0FBVyxLQUFLLFdBQVcsK0dBQStHLGtCQUFrQix1Q0FBdUMsZ0JBQWdCLG1CQUFtQiw2QkFBNkIsbUJBQW1CLDRCQUE0QixJQUFJLGlDQUFpQywyREFBMkQsT0FBTyxTQUFTLFNBQVMsUUFBUSxJQUFJLDhCQUE4QixRQUFRLGNBQWMsU0FBUyxrQkFBa0IsNEVBQTRFLEdBQUcscXNIQUFxc0gsYUFBYSxzRkFBc0YsOEJBQThCLCtCQUErQix1QkFBdUIsb0NBQW9DLG9KQUFvSix3REFBd0QsYUFBYSw4QkFBOEIsV0FBVyw0SEFBNEgsTUFBTSxnQkFBZ0IsaUNBQWlDLGlCQUFpQixJQUFJLEVBQUUsb0NBQW9DLHdCQUF3QixJQUFJLEVBQUUsa0JBQWtCLDJDQUEyQyx1QkFBdUIsSUFBSSxFQUFFLGtCQUFrQiwyQ0FBMkMsR0FBRyxFQUFFLGdDQUFnQyxtREFBbUQsbU9BQW1PLEVBQUUsbUNBQW1DLFNBQVMsVUFBVSw2Q0FBNkMsTUFBTSwyQ0FBMkMsTUFBTSxZQUFZLFVBQVUsRUFBRSx5Q0FBeUMsU0FBUyw2QkFBNkIsb0RBQW9ELFFBQVEsMEJBQTBCLHVCQUF1QixrQ0FBa0MsK0JBQStCLEVBQUUsVUFBVSxFQUFFLDBDQUEwQyxTQUFTLDZCQUE2Qiw4QkFBOEIsYUFBYSxVQUFVLEVBQUUsb0RBQW9ELDZCQUE2QiwwQkFBMEIsS0FBSyxLQUFLLGlCQUFpQixhQUFhLFVBQVUsK0dBQStHLGdGQUFnRiwyQ0FBMkMsbUJBQW1CLHNEQUFzRCxtQ0FBbUMsYUFBYSw0QkFBNEIsNkNBQTZDLEVBQUUsK0JBQStCLCtGQUErRixrQ0FBa0MsNEJBQTRCLHdEQUF3RCxPQUFPLEVBQUUsK0JBQStCLHdCQUF3QixTQUFTLEtBQUsseUJBQXlCLHNDQUFzQyxrQ0FBa0MsZ0RBQWdELFFBQVEsRUFBRSxxQ0FBcUMsYUFBYSwyQ0FBMkMsMERBQTBELGlCQUFpQix1QkFBdUIsU0FBUyxFQUFFLHVDQUF1QyxjQUFjLEtBQUssb0RBQW9ELFVBQVUsRUFBRSx1Q0FBdUMsY0FBYyxXQUFXLG9EQUFvRCxVQUFVLEVBQUUsd0NBQXdDLFNBQVMscUNBQXFDLDhCQUE4Qix1QkFBdUIsZ0JBQWdCLElBQUksS0FBSyxFQUFFLG1DQUFtQyxNQUFNLE9BQU8sZUFBZSxnQkFBZ0IsbUhBQW1ILE1BQU0sd0JBQXdCLE1BQU0sd0JBQXdCLFdBQVcsRUFBRSx3Q0FBd0MsNERBQTRELGlDQUFpQyxFQUFFLHVDQUF1QyxNQUFNLDJCQUEyQixLQUFLLGtDQUFrQyxpREFBaUQsVUFBVSxLQUFLLGdCQUFnQixjQUFjLDBDQUEwQyxxSUFBcUksc0JBQXNCLDRCQUE0QixtRkFBbUYseUJBQXlCLGdHQUFnRyw2QkFBNkIsb0VBQW9FLHlCQUF5QixzR0FBc0csMk1BQTJNLGFBQWEsa0NBQWtDLHNCQUFzQiw4QkFBOEIsaURBQWlELEVBQUUsd0NBQXdDLE9BQU8sZ0ZBQWdGLG1EQUFtRCwwQkFBMEIsb0RBQW9ELEVBQUUsd0NBQXdDLFFBQVEsMkZBQTJGLFdBQVcsS0FBSyxXQUFXLHlEQUF5RCw2QkFBNkIsd0RBQXdELHNCQUFzQixtRUFBbUUsb0VBQW9FLEVBQUUsZ0NBQWdDLDBDQUEwQyxNQUFNLEVBQUUsOENBQThDLGtFQUFrRSw2SEFBNkgsMENBQTBDLDRFQUE0RSxzREFBc0QsRUFBRSxpQ0FBaUMsOE1BQThNLHlEQUF5RCw0REFBNEQsZ2RBQWdkLHlQQUF5UCxFQUFFLHFDQUFxQyxnREFBZ0QsRUFBRSx1Q0FBdUMsOENBQThDLDhCQUE4QixFQUFFLHNDQUFzQyw4QkFBOEIsRUFBRSx1Q0FBdUMsOEJBQThCLEVBQUUsbUNBQW1DLDJCQUEyQixFQUFFLG9DQUFvQywyQkFBMkIsRUFBRSx1Q0FBdUMsb0NBQW9DLG1DQUFtQyxFQUFFLHdDQUF3QyxlQUFlLDJEQUEyRCx5QkFBeUIsd0JBQXdCLGdDQUFnQyx3QkFBd0IsUUFBUSxFQUFFLHdDQUF3QyxtQ0FBbUMsbUhBQW1ILHFEQUFxRCw0S0FBNEssRUFBRSxrQ0FBa0MsaUNBQWlDLEVBQUUseUNBQXlDLDJFQUEyRSxFQUFFLHFDQUFxQyxrQ0FBa0MsOEhBQThILEVBQUUsa0NBQWtDLDhDQUE4Qyx3QkFBd0IscUNBQXFDLEVBQUUsd0NBQXdDLDZCQUE2Qiw2REFBNkQsZ0NBQWdDLGFBQWEscUNBQXFDLE9BQU8sOEJBQThCLEVBQUUsaUNBQWlDLFdBQVcsb0NBQW9DLDRCQUE0QixLQUFLLElBQUksZ0NBQWdDLGtEQUFrRCwwTEFBMEwsRUFBRSxxQ0FBcUMsK0VBQStFLEVBQUUsaUNBQWlDLHVEQUF1RCxFQUFFLGtDQUFrQyxhQUFhLDhCQUE4QixNQUFNLFVBQVUsRUFBRSxtQ0FBbUMsWUFBWSxXQUFXLGlDQUFpQyxVQUFVLEVBQUUscUNBQXFDLGlDQUFpQyxFQUFFLGtDQUFrQyxtREFBbUQseUVBQXlFLEVBQUUsbUNBQW1DLHFCQUFxQiw4QkFBOEIsR0FBRyxFQUFFLCtCQUErQixtQ0FBbUMsVUFBVSxHQUFHLEtBQUssR0FBRyxvQkFBb0IsOERBQThELFVBQVUsbVVBQW1VLGtJQUFrSSwySkFBMkosc0JBQXNCLHlCQUF5QixZQUFZLG9CQUFvQixxQkFBcUIsdUJBQXVCLDJHQUEyRyxxQ0FBcUMsT0FBTyxVQUFVLFlBQVksc0JBQXNCLDRCQUE0QixrRkFBa0YsdUJBQXVCLHFCQUFxQix1QkFBdUIsa0RBQWtELDhCQUE4QixlQUFlLG1DQUFtQyxhQUFhLHNQQUFzUCxxQ0FBcUMsb09BQW9PLHlDQUF5QyxnSEFBZ0gscUNBQXFDLDhSQUE4Uix5Q0FBeUMsK0RBQStELHFDQUFxQyxtRUFBbUUseUNBQXlDLHdUQUF3VCxxQ0FBcUMseURBQXlELHlDQUF5Qyx5REFBeUQseUNBQXlDLDBHQUEwRyx5Q0FBeUMsK0VBQStFLHFDQUFxQyxpR0FBaUcscUNBQXFDLG1GQUFtRix5Q0FBeUMsNkdBQTZHLGdEQUFnRCwyRkFBMkYseUNBQXlDLCtGQUErRixxQ0FBcUMsMkVBQTJFLHFDQUFxQyxrRkFBa0YscUNBQXFDLG1HQUFtRyx5Q0FBeUMsdUZBQXVGLHFDQUFxQyw2SEFBNkgscUNBQXFDLDZGQUE2RixxQ0FBcUMsd0RBQXdELCtIQUErSCxhQUFhLGdFQUFnRSxhQUFhLDZqREFBNmpELHdCQUF3QiwwRUFBMEUsb2dCQUFvZ0IseUNBQXlDLHFFQUFxRSx5Q0FBeUMsb0dBQW9HLHlDQUF5QyxtRUFBbUUseUNBQXlDLGlIQUFpSCx5Q0FBeUMsc1BBQXNQLHFDQUFxQyxhQUFhLDhEQUE4RCxvQ0FBb0MsWUFBWSxLQUFLLFdBQVcsS0FBSyxVQUFVLEtBQUssZ0VBQWdFLDBCQUEwQixhQUFhLHVFQUF1RSxPQUFPLFVBQVUsV0FBVyxXQUFXLGFBQWEsWUFBWSxhQUFhLEdBQUcseUNBQXlDLFlBQVksRUFBRSxhQUFhLGFBQWEsbUVBQW1FLHFEQUFxRCwwQkFBMEIsYUFBYSxnRUFBZ0UsNkVBQTZFLGlDQUFpQyxxRkFBcUYsaUJBQWlCLDBCQUEwQixhQUFhLHNGQUFzRiw0R0FBNEcsZ0NBQWdDLHVCQUF1Qix1REFBdUQsdUNBQXVDLDJDQUEyQyxrQ0FBa0MsRUFBRSxFQUFFLFdBQVcsOEJBQThCLDBCQUEwQixhQUFhLG1FQUFtRSx3QkFBd0IsU0FBUyxhQUFhLHlFQUF5RSxnQ0FBZ0MsYUFBYSxhQUFhLDJEQUEyRCxxREFBcUQsNkxBQTZMLHlDQUF5QyxzR0FBc0csRUFBRSwwQkFBMEIsYUFBYSx1REFBdUQsbUJBQW1CLElBQUksOEJBQThCLGtEQUFrRCxhQUFhLGFBQWEsMERBQTBELDhDQUE4QyxhQUFhLDREQUE0RCx3QkFBd0Isd0ZBQXdGLGFBQWEsMERBQTBELGtIQUFrSCxRQUFRLDBCQUEwQixxREFBcUQsV0FBVyxtQkFBbUIsYUFBYSxpRUFBaUUsMkVBQTJFLHlCQUF5QiwrRUFBK0UsNkJBQTZCLG1CQUFtQixvQkFBb0IsYUFBYSwrREFBK0QsZ0ZBQWdGLHVCQUF1QiwrQkFBK0IsaUNBQWlDLFdBQVcsa0JBQWtCLGFBQWEsMkNBQTJDLHNEQUFzRCxhQUFhLDBEQUEwRCwwRkFBMEYsYUFBYSxzRkFBc0YsYUFBYSxrREFBa0Qsa0lBQWtJLGFBQWEsbURBQW1ELG9MQUFvTCxhQUFhLCtDQUErQyx1RUFBdUUsYUFBYSxzRUFBc0UsNkNBQTZDLGFBQWEsdURBQXVELFNBQVMsd0ZBQXdGLFdBQVcsc0JBQXNCLDZCQUE2QixXQUFXLE1BQU0sYUFBYSxhQUFhLDZEQUE2RCw2REFBNkQsa0NBQWtDLGFBQWEsbUVBQW1FLG1JQUFtSSxJQUFJLElBQUksUUFBUSx5Q0FBeUMsYUFBYSx5REFBeUQscURBQXFELElBQUksK0NBQStDLEVBQUUsaUNBQWlDLEVBQUUseUJBQXlCLGNBQWMscURBQXFELCtEQUErRCxnQ0FBZ0MscUJBQXFCLGlDQUFpQyw0REFBNEQsd2NBQXdjLHNDQUFzQyxZQUFZLEtBQUssZ0JBQWdCLG9EQUFvRCxvRUFBb0UsWUFBWSxFQUFFLG1CQUFtQixPQUFPLFNBQVMsK0VBQStFLHlDQUF5QyxJQUFJLGdDQUFnQyw0Q0FBNEMsK0VBQStFLDZCQUE2Qiw0QkFBNEIsSUFBSSxLQUFLLDZCQUE2QixrR0FBa0csU0FBUywwQkFBMEIsNEJBQTRCLElBQUksS0FBSyw2QkFBNkIsZ0hBQWdILFNBQVMsbUJBQW1CLHFLQUFxSyxvQkFBb0IsNkRBQTZELG9CQUFvQixxQ0FBcUMscUNBQXFDLCtCQUErQiw0QkFBNEIsK0JBQStCLG9FQUFvRSw0QkFBNEIsb0dBQW9HLDRFQUE0RSx5QkFBeUIsK0RBQStELFVBQVUsNkRBQTZELG9FQUFvRSw2REFBNkQsb0VBQW9FLEVBQUUsaUNBQWlDLDhEQUE4RCx3QkFBd0IsMENBQTBDLDBEQUEwRCxZQUFZLGdDQUFnQyxxQ0FBcUMsTUFBTSw0Q0FBNEMscUNBQXFDLFlBQVksZ0NBQWdDLHFDQUFxQyxNQUFNLDRDQUE0QyxxQ0FBcUMsWUFBWSx3QkFBd0Isc0JBQXNCLGdCQUFnQix5Q0FBeUMsdUVBQXVFLElBQUksS0FBSyxXQUFXLG1HQUFtRyxzQkFBc0IseUJBQXlCLGNBQWMsb0JBQW9CLDBCQUEwQiwyQkFBMkIsdUJBQXVCLG1CQUFtQixrQ0FBa0MsWUFBWSxLQUFLLEtBQUsscUJBQXFCLG9CQUFvQiw4QkFBOEIsT0FBTyxxRkFBcUYsK0JBQStCLGlCQUFpQix1Q0FBdUMsTUFBTSx1Q0FBdUMsTUFBTSxxREFBcUQscUNBQXFDLG1DQUFtQyxnQkFBZ0IsY0FBYyxTQUFTLGlIQUFpSCxjQUFjLCtCQUErQixrQkFBa0Isd0RBQXdELDJCQUEyQixvQkFBb0IsNkNBQTZDLElBQUkscUJBQXFCLFNBQVMsMENBQTBDLHVDQUF1QyxLQUFLLGFBQWEsbUdBQW1HLG9FQUFvRSxlQUFlLHVIQUF1SCwwQkFBMEIsNEVBQTRFLGtDQUFrQyxhQUFhLGdEQUFnRCx3RkFBd0YsYUFBYSw2Q0FBNkMsbUlBQW1JLDBDQUEwQyxhQUFhLCtDQUErQywwR0FBMEcsYUFBYSx5REFBeUQsd0NBQXdDLGtCQUFrQiwwR0FBMEcsa0RBQWtELGFBQWEsMERBQTBELDhDQUE4QyxvQkFBb0IsNEJBQTRCLGFBQWEsZ0RBQWdELHNEQUFzRCxhQUFhLHlEQUF5RCw2REFBNkQsYUFBYSw2REFBNkQsNERBQTRELGlCQUFpQixzQkFBc0IsYUFBYSx5REFBeUQsbUNBQW1DLGFBQWEsYUFBYSw4REFBOEQscUJBQXFCLEdBQUcsWUFBWSxhQUFhLGtFQUFrRSxrQ0FBa0MsR0FBRyxzQkFBc0IsYUFBYSxxRUFBcUUsb0NBQW9DLGFBQWEsOERBQThELGdDQUFnQyxhQUFhLHNEQUFzRCxzREFBc0QsYUFBYSxzRkFBc0Ysb0JBQW9CLGFBQWEsMENBQTBDLGFBQWEsZ0dBQWdHLHFCQUFxQixhQUFhLDBDQUEwQyxhQUFhLHNEQUFzRCxxSkFBcUosNkRBQTZELGFBQWEsMkNBQTJDLDBEQUEwRCxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsMENBQTBDLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxnQkFBZ0IsOERBQThELGFBQWEsMkNBQTJDLHVIQUF1SCw4QkFBOEIsZ0JBQWdCLGdFQUFnRSxHQUFHLGFBQWEsK0NBQStDLGlHQUFpRyxxQ0FBcUMsV0FBVyxlQUFlLGFBQWEsK0NBQStDLDZIQUE2SCw2Q0FBNkMsV0FBVyxlQUFlLGFBQWEsc0NBQXNDLHFGQUFxRixzQ0FBc0MsYUFBYSxhQUFhLDRDQUE0Qyw4QkFBOEIsRUFBRSx5Q0FBeUMsRUFBRSw0RUFBNEUsMkNBQTJDLFdBQVcsZUFBZSxhQUFhLGdEQUFnRCxxTkFBcU4sMEZBQTBGLGFBQWEseUNBQXlDLHNIQUFzSCxxREFBcUQsYUFBYSx3Q0FBd0MsZ0hBQWdILCtDQUErQyxhQUFhLHNDQUFzQyxrR0FBa0cseUNBQXlDLGFBQWEsdUNBQXVDLDJHQUEyRyxHQUFHLGtDQUFrQywrQkFBK0IsYUFBYSxtREFBbUQsZ0ZBQWdGLG9DQUFvQyxhQUFhLDJDQUEyQyxtTUFBbU0sbUNBQW1DLFdBQVcsZUFBZSxhQUFhLDJDQUEyQywwRkFBMEYsSUFBSSxvQ0FBb0Msc0NBQXNDLGFBQWEsd0NBQXdDLHVZQUF1WSw2QkFBNkIsYUFBYSwwQ0FBMEMsOElBQThJLHVDQUF1QyxXQUFXLGVBQWUsYUFBYSxzQ0FBc0MsK3ZCQUErdkIsNkJBQTZCLGFBQWEsNkNBQTZDLGtHQUFrRyxxQ0FBcUMsV0FBVyxlQUFlLGFBQWEsMkNBQTJDLHlEQUF5RCxFQUFFLDZCQUE2QixFQUFFLDBCQUEwQix1Q0FBdUMsb0RBQW9ELEVBQUUsV0FBVyxlQUFlLGFBQWEsNkNBQTZDLHFFQUFxRSxFQUFFLHlDQUF5QyxFQUFFLDJLQUEySywyQ0FBMkMsb0NBQW9DLDBCQUEwQixhQUFhLGFBQWEsMENBQTBDLDRIQUE0SCx3REFBd0Qsb0RBQW9ELGFBQWEsYUFBYSwyQ0FBMkMsOEZBQThGLGFBQWEsa0RBQWtELHNPQUFzTyxtQ0FBbUMsY0FBYyw0U0FBNFMsSUFBSSxHQUFHLG1IQUFtSCwyQkFBMkIsZ01BQWdNLDBCQUEwQixnQkFBZ0IseUNBQXlDLG1DQUFtQyxnQkFBZ0IsdUNBQXVDLDRDQUE0QyxrRkFBa0YsK0JBQStCLCtEQUErRCw0R0FBNEcsMEJBQTBCLGdCQUFnQix5Q0FBeUMsbUNBQW1DLGdCQUFnQix1Q0FBdUMsNENBQTRDLHNDQUFzQyx1RUFBdUUseUJBQXlCLDhDQUE4QyxzREFBc0Qsa0NBQWtDLEVBQUUsMEdBQTBHLDJCQUEyQix1TkFBdU4sNEtBQTRLLDBCQUEwQixnQkFBZ0IseUNBQXlDLG1DQUFtQyxnQkFBZ0IsdUNBQXVDLDRDQUE0QyxhQUFhLHdDQUF3QyxvQkFBb0Isb05BQW9OLG9FQUFvRSxJQUFJLDZCQUE2QixJQUFJLFdBQVcsb0NBQW9DLGFBQWEsd0NBQXdDLHdqQ0FBd2pDLGFBQWEsbURBQW1ELGlGQUFpRixhQUFhLDZEQUE2RCxnSkFBZ0osK0dBQStHLHVEQUF1RCxhQUFhLDZDQUE2Qyw0REFBNEQsc0pBQXNKLDhFQUE4RSxhQUFhLDRDQUE0Qyx1QkFBdUIsSUFBSSwwQ0FBMEMsZ0NBQWdDLGFBQWEsZ0RBQWdELDREQUE0RCxJQUFJLHdCQUF3QixFQUFFLHdCQUF3QixtQ0FBbUMsbUNBQW1DLEdBQUcsYUFBYSw0Q0FBNEMsNk5BQTZOLDJCQUEyQiwwQ0FBMEMsYUFBYSxnREFBZ0QsMktBQTJLLGlCQUFpQix5Q0FBeUMscUJBQXFCLG9EQUFvRCwyQkFBMkIsR0FBRyxhQUFhLHVDQUF1Qyw2SUFBNkksYUFBYSx1Q0FBdUMsa0xBQWtMLGFBQWEsd0NBQXdDLGtLQUFrSyxjQUFjLHFDQUFxQyxhQUFhLHNDQUFzQyxnSEFBZ0gsbUNBQW1DLDJDQUEyQyxHQUFHLGFBQWEsOENBQThDLG1GQUFtRixhQUFhLHVDQUF1QywwSUFBMEksdUNBQXVDLHVDQUF1QyxHQUFHLGFBQWEsd0NBQXdDLDRCQUE0QixFQUFFLGNBQWMsK0JBQStCLGFBQWEsb0RBQW9ELHlEQUF5RCxFQUFFLGFBQWEsRUFBRSw2Q0FBNkMsbUNBQW1DLGlEQUFpRCxhQUFhLDJDQUEyQywwSkFBMEosb0NBQW9DLEVBQUUsYUFBYSw4cEJBQThwQixxREFBcUQsU0FBUyxjQUFjLGVBQWUsYUFBYSx5REFBeUQsd0VBQXdFLE1BQU0sT0FBTyxpQkFBaUIsbUNBQW1DLFdBQVcsOEJBQThCLGdXQUFnVyxHQUFHLDJCQUEyQixXQUFXLGdDQUFnQyxHQUFHLGFBQWEsOENBQThDLDBCQUEwQiwwRUFBMEUsOEJBQThCLDZCQUE2QixhQUFhLDhEQUE4RCw0QkFBNEIsRUFBRSx3Q0FBd0MsRUFBRSx3QkFBd0IsYUFBYSx5RUFBeUUsNkNBQTZDLDhCQUE4QixhQUFhLHlEQUF5RCw2R0FBNkcsYUFBYSxnREFBZ0Qsd0pBQXdKLGFBQWEsNkNBQTZDLGlDQUFpQyxJQUFJLDRGQUE0RixpQ0FBaUMsYUFBYSx5Q0FBeUMsNENBQTRDLEtBQUssc01BQXNNLHNDQUFzQywyREFBMkQsMkJBQTJCLElBQUksc0RBQXNELGlDQUFpQyxpQkFBaUIsV0FBVyxlQUFlLFNBQVMsR0FBRyxJQUFJLEU7Ozs7Ozs7Ozs7OztBQ0R6MXJEO0FBQUE7QUFBQTtBQUEwRTtBQUMxRSxlQUFlLHdFQUFRLEVBQUUsd0JBQXdCOztBQUVqRCxhQUFhLG1CQUFPLENBQUMsbURBQVc7QUFDaEM7O0FBRUE7QUFDQSw0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDRCO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxpQjtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGFBQWE7QUFDYjtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM7QUFDVDtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQSxTQUFTO0FBQ1QsS0FBSztBQUNMO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsS0FBSztBQUNMIiwiZmlsZSI6ImNvZGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHt9O1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3NyYy9jb2RlLmpzXCIpO1xuIiwiLyoqXG4gKiBUaGlzIGxpYnJhcnkgd2FzIG1vZGlmaWVkIGJ5IEhhcnJpc29uIExpZGRpYXJkLiBUaGUgc291cmNlIGNvZGUgdG8gdGhpc1xuICogbW9kaWZpZWQgdmVyc2lvbiBjYW4gYmUgZm91bmQgYXQgaHR0cHM6Ly9naXRodWIuY29tL2xpZGRpYXJkL2dvb2dsZS1kaWZmLy5cbiAqIFRoZSBvcmlnaW5hbCBzb3VyY2UgY29kZSBjYW4gYmUgZm91bmQgYXRcbiAqIGh0dHA6Ly9jb2RlLmdvb2dsZS5jb20vcC9nb29nbGUtZGlmZi1tYXRjaC1wYXRjaC8uIFRoaXMgdW5vZmZpY2lhbCBmb3JrIGlzXG4gKiBub3QgbWFpbnRhaW5lZCBieSBvciBhZmZpbGlhdGVkIHdpdGggR29vZ2xlIEluYy4gVGhlIG9yaWdpbmFsIGF0dHJpYnV0aW9uXG4gKiBhbmQgbGljZW5zaW5nIGluZm9ybWF0aW9uIGZvbGxvd3MuXG4gKi9cblxuLyoqXG4gKiBEaWZmIE1hdGNoIGFuZCBQYXRjaFxuICpcbiAqIENvcHlyaWdodCAyMDA2IEdvb2dsZSBJbmMuXG4gKiBodHRwOi8vY29kZS5nb29nbGUuY29tL3AvZ29vZ2xlLWRpZmYtbWF0Y2gtcGF0Y2gvXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgQ29tcHV0ZXMgdGhlIGRpZmZlcmVuY2UgYmV0d2VlbiB0d28gdGV4dHMgdG8gY3JlYXRlIGEgcGF0Y2guXG4gKiBBcHBsaWVzIHRoZSBwYXRjaCBvbnRvIGFub3RoZXIgdGV4dCwgYWxsb3dpbmcgZm9yIGVycm9ycy5cbiAqIEBhdXRob3IgZnJhc2VyQGdvb2dsZS5jb20gKE5laWwgRnJhc2VyKVxuICovXG5cbi8qKlxuICogQ2xhc3MgY29udGFpbmluZyB0aGUgZGlmZi5cbiAqIEBjb25zdHJ1Y3RvclxuICovXG5mdW5jdGlvbiBkaWZmKG9wdGlvbnMpIHtcbiAgdmFyIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuXG4gIC8vIERlZmF1bHRzLlxuICAvLyBSZWRlZmluZSB0aGVzZSBpbiB5b3VyIHByb2dyYW0gdG8gb3ZlcnJpZGUgdGhlIGRlZmF1bHRzLlxuXG4gIC8vIE51bWJlciBvZiBzZWNvbmRzIHRvIG1hcCBhIGRpZmYgYmVmb3JlIGdpdmluZyB1cCAoMCBmb3IgaW5maW5pdHkpLlxuICB0aGlzLlRpbWVvdXQgPSBvcHRpb25zLnRpbWVvdXQgfHwgMS4wO1xuICAvLyBDb3N0IG9mIGFuIGVtcHR5IGVkaXQgb3BlcmF0aW9uIGluIHRlcm1zIG9mIGVkaXQgY2hhcmFjdGVycy5cbiAgdGhpcy5FZGl0Q29zdCA9IG9wdGlvbnMuZWRpdENvc3QgfHwgNDtcbn1cblxuXG4vLyAgRElGRiBGVU5DVElPTlNcblxuXG4vKipcbiAqIFRoZSBkYXRhIHN0cnVjdHVyZSByZXByZXNlbnRpbmcgYSBkaWZmIGlzIGFuIGFycmF5IG9mIHR1cGxlczpcbiAqIFtbRElGRl9ERUxFVEUsICdIZWxsbyddLCBbRElGRl9JTlNFUlQsICdHb29kYnllJ10sIFtESUZGX0VRVUFMLCAnIHdvcmxkLiddXVxuICogd2hpY2ggbWVhbnM6IGRlbGV0ZSAnSGVsbG8nLCBhZGQgJ0dvb2RieWUnIGFuZCBrZWVwICcgd29ybGQuJ1xuICovXG52YXIgRElGRl9ERUxFVEUgPSAtMTtcbnZhciBESUZGX0lOU0VSVCA9IDE7XG52YXIgRElGRl9FUVVBTCA9IDA7XG5cbi8qKiBAdHlwZWRlZiB7ezA6IG51bWJlciwgMTogc3RyaW5nfX0gKi9cbmRpZmYuRGlmZjtcblxuXG4vKipcbiAqIEZpbmQgdGhlIGRpZmZlcmVuY2VzIGJldHdlZW4gdHdvIHRleHRzLiAgU2ltcGxpZmllcyB0aGUgcHJvYmxlbSBieSBzdHJpcHBpbmdcbiAqIGFueSBjb21tb24gcHJlZml4IG9yIHN1ZmZpeCBvZmYgdGhlIHRleHRzIGJlZm9yZSBkaWZmaW5nLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQxIE9sZCBzdHJpbmcgdG8gYmUgZGlmZmVkLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQyIE5ldyBzdHJpbmcgdG8gYmUgZGlmZmVkLlxuICogQHBhcmFtIHtib29sZWFuPX0gb3B0X2NoZWNrbGluZXMgT3B0aW9uYWwgc3BlZWR1cCBmbGFnLiBJZiBwcmVzZW50IGFuZCBmYWxzZSxcbiAqICAgICB0aGVuIGRvbid0IHJ1biBhIGxpbmUtbGV2ZWwgZGlmZiBmaXJzdCB0byBpZGVudGlmeSB0aGUgY2hhbmdlZCBhcmVhcy5cbiAqICAgICBEZWZhdWx0cyB0byB0cnVlLCB3aGljaCBkb2VzIGEgZmFzdGVyLCBzbGlnaHRseSBsZXNzIG9wdGltYWwgZGlmZi5cbiAqIEBwYXJhbSB7bnVtYmVyfSBvcHRfZGVhZGxpbmUgT3B0aW9uYWwgdGltZSB3aGVuIHRoZSBkaWZmIHNob3VsZCBiZSBjb21wbGV0ZVxuICogICAgIGJ5LiAgVXNlZCBpbnRlcm5hbGx5IGZvciByZWN1cnNpdmUgY2FsbHMuICBVc2VycyBzaG91bGQgc2V0IERpZmZUaW1lb3V0XG4gKiAgICAgaW5zdGVhZC5cbiAqIEByZXR1cm4geyFBcnJheS48IWRpZmYuRGlmZj59IEFycmF5IG9mIGRpZmYgdHVwbGVzLlxuICovXG5kaWZmLnByb3RvdHlwZS5tYWluID0gZnVuY3Rpb24odGV4dDEsIHRleHQyLCBvcHRfY2hlY2tsaW5lcyxcbiAgICBvcHRfZGVhZGxpbmUpIHtcbiAgLy8gU2V0IGEgZGVhZGxpbmUgYnkgd2hpY2ggdGltZSB0aGUgZGlmZiBtdXN0IGJlIGNvbXBsZXRlLlxuICBpZiAodHlwZW9mIG9wdF9kZWFkbGluZSA9PSAndW5kZWZpbmVkJykge1xuICAgIGlmICh0aGlzLlRpbWVvdXQgPD0gMCkge1xuICAgICAgb3B0X2RlYWRsaW5lID0gTnVtYmVyLk1BWF9WQUxVRTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3B0X2RlYWRsaW5lID0gKG5ldyBEYXRlKS5nZXRUaW1lKCkgKyB0aGlzLlRpbWVvdXQgKiAxMDAwO1xuICAgIH1cbiAgfVxuICB2YXIgZGVhZGxpbmUgPSBvcHRfZGVhZGxpbmU7XG5cbiAgLy8gQ2hlY2sgZm9yIG51bGwgaW5wdXRzLlxuICBpZiAodGV4dDEgPT0gbnVsbCB8fCB0ZXh0MiA9PSBudWxsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdOdWxsIGlucHV0LiAoZGlmZl9tYWluKScpO1xuICB9XG5cbiAgLy8gQ2hlY2sgZm9yIGVxdWFsaXR5IChzcGVlZHVwKS5cbiAgaWYgKHRleHQxID09IHRleHQyKSB7XG4gICAgaWYgKHRleHQxKSB7XG4gICAgICByZXR1cm4gW1tESUZGX0VRVUFMLCB0ZXh0MV1dO1xuICAgIH1cbiAgICByZXR1cm4gW107XG4gIH1cblxuICBpZiAodHlwZW9mIG9wdF9jaGVja2xpbmVzID09ICd1bmRlZmluZWQnKSB7XG4gICAgb3B0X2NoZWNrbGluZXMgPSB0cnVlO1xuICB9XG4gIHZhciBjaGVja2xpbmVzID0gb3B0X2NoZWNrbGluZXM7XG5cbiAgLy8gVHJpbSBvZmYgY29tbW9uIHByZWZpeCAoc3BlZWR1cCkuXG4gIHZhciBjb21tb25sZW5ndGggPSB0aGlzLmNvbW1vblByZWZpeCh0ZXh0MSwgdGV4dDIpO1xuICB2YXIgY29tbW9ucHJlZml4ID0gdGV4dDEuc3Vic3RyaW5nKDAsIGNvbW1vbmxlbmd0aCk7XG4gIHRleHQxID0gdGV4dDEuc3Vic3RyaW5nKGNvbW1vbmxlbmd0aCk7XG4gIHRleHQyID0gdGV4dDIuc3Vic3RyaW5nKGNvbW1vbmxlbmd0aCk7XG5cbiAgLy8gVHJpbSBvZmYgY29tbW9uIHN1ZmZpeCAoc3BlZWR1cCkuXG4gIGNvbW1vbmxlbmd0aCA9IHRoaXMuY29tbW9uU3VmZml4KHRleHQxLCB0ZXh0Mik7XG4gIHZhciBjb21tb25zdWZmaXggPSB0ZXh0MS5zdWJzdHJpbmcodGV4dDEubGVuZ3RoIC0gY29tbW9ubGVuZ3RoKTtcbiAgdGV4dDEgPSB0ZXh0MS5zdWJzdHJpbmcoMCwgdGV4dDEubGVuZ3RoIC0gY29tbW9ubGVuZ3RoKTtcbiAgdGV4dDIgPSB0ZXh0Mi5zdWJzdHJpbmcoMCwgdGV4dDIubGVuZ3RoIC0gY29tbW9ubGVuZ3RoKTtcblxuICAvLyBDb21wdXRlIHRoZSBkaWZmIG9uIHRoZSBtaWRkbGUgYmxvY2suXG4gIHZhciBkaWZmcyA9IHRoaXMuY29tcHV0ZV8odGV4dDEsIHRleHQyLCBjaGVja2xpbmVzLCBkZWFkbGluZSk7XG5cbiAgLy8gUmVzdG9yZSB0aGUgcHJlZml4IGFuZCBzdWZmaXguXG4gIGlmIChjb21tb25wcmVmaXgpIHtcbiAgICBkaWZmcy51bnNoaWZ0KFtESUZGX0VRVUFMLCBjb21tb25wcmVmaXhdKTtcbiAgfVxuICBpZiAoY29tbW9uc3VmZml4KSB7XG4gICAgZGlmZnMucHVzaChbRElGRl9FUVVBTCwgY29tbW9uc3VmZml4XSk7XG4gIH1cbiAgdGhpcy5jbGVhbnVwTWVyZ2UoZGlmZnMpO1xuICByZXR1cm4gZGlmZnM7XG59O1xuXG5cbi8qKlxuICogRmluZCB0aGUgZGlmZmVyZW5jZXMgYmV0d2VlbiB0d28gdGV4dHMuICBBc3N1bWVzIHRoYXQgdGhlIHRleHRzIGRvIG5vdFxuICogaGF2ZSBhbnkgY29tbW9uIHByZWZpeCBvciBzdWZmaXguXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDEgT2xkIHN0cmluZyB0byBiZSBkaWZmZWQuXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDIgTmV3IHN0cmluZyB0byBiZSBkaWZmZWQuXG4gKiBAcGFyYW0ge2Jvb2xlYW59IGNoZWNrbGluZXMgU3BlZWR1cCBmbGFnLiAgSWYgZmFsc2UsIHRoZW4gZG9uJ3QgcnVuIGFcbiAqICAgICBsaW5lLWxldmVsIGRpZmYgZmlyc3QgdG8gaWRlbnRpZnkgdGhlIGNoYW5nZWQgYXJlYXMuXG4gKiAgICAgSWYgdHJ1ZSwgdGhlbiBydW4gYSBmYXN0ZXIsIHNsaWdodGx5IGxlc3Mgb3B0aW1hbCBkaWZmLlxuICogQHBhcmFtIHtudW1iZXJ9IGRlYWRsaW5lIFRpbWUgd2hlbiB0aGUgZGlmZiBzaG91bGQgYmUgY29tcGxldGUgYnkuXG4gKiBAcmV0dXJuIHshQXJyYXkuPCFkaWZmLkRpZmY+fSBBcnJheSBvZiBkaWZmIHR1cGxlcy5cbiAqIEBwcml2YXRlXG4gKi9cbmRpZmYucHJvdG90eXBlLmNvbXB1dGVfID0gZnVuY3Rpb24odGV4dDEsIHRleHQyLCBjaGVja2xpbmVzLFxuICAgIGRlYWRsaW5lKSB7XG4gIHZhciBkaWZmcztcblxuICBpZiAoIXRleHQxKSB7XG4gICAgLy8gSnVzdCBhZGQgc29tZSB0ZXh0IChzcGVlZHVwKS5cbiAgICByZXR1cm4gW1tESUZGX0lOU0VSVCwgdGV4dDJdXTtcbiAgfVxuXG4gIGlmICghdGV4dDIpIHtcbiAgICAvLyBKdXN0IGRlbGV0ZSBzb21lIHRleHQgKHNwZWVkdXApLlxuICAgIHJldHVybiBbW0RJRkZfREVMRVRFLCB0ZXh0MV1dO1xuICB9XG5cbiAgdmFyIGxvbmd0ZXh0ID0gdGV4dDEubGVuZ3RoID4gdGV4dDIubGVuZ3RoID8gdGV4dDEgOiB0ZXh0MjtcbiAgdmFyIHNob3J0dGV4dCA9IHRleHQxLmxlbmd0aCA+IHRleHQyLmxlbmd0aCA/IHRleHQyIDogdGV4dDE7XG4gIHZhciBpID0gbG9uZ3RleHQuaW5kZXhPZihzaG9ydHRleHQpO1xuICBpZiAoaSAhPSAtMSkge1xuICAgIC8vIFNob3J0ZXIgdGV4dCBpcyBpbnNpZGUgdGhlIGxvbmdlciB0ZXh0IChzcGVlZHVwKS5cbiAgICBkaWZmcyA9IFtbRElGRl9JTlNFUlQsIGxvbmd0ZXh0LnN1YnN0cmluZygwLCBpKV0sXG4gICAgICAgICAgICAgW0RJRkZfRVFVQUwsIHNob3J0dGV4dF0sXG4gICAgICAgICAgICAgW0RJRkZfSU5TRVJULCBsb25ndGV4dC5zdWJzdHJpbmcoaSArIHNob3J0dGV4dC5sZW5ndGgpXV07XG4gICAgLy8gU3dhcCBpbnNlcnRpb25zIGZvciBkZWxldGlvbnMgaWYgZGlmZiBpcyByZXZlcnNlZC5cbiAgICBpZiAodGV4dDEubGVuZ3RoID4gdGV4dDIubGVuZ3RoKSB7XG4gICAgICBkaWZmc1swXVswXSA9IGRpZmZzWzJdWzBdID0gRElGRl9ERUxFVEU7XG4gICAgfVxuICAgIHJldHVybiBkaWZmcztcbiAgfVxuXG4gIGlmIChzaG9ydHRleHQubGVuZ3RoID09IDEpIHtcbiAgICAvLyBTaW5nbGUgY2hhcmFjdGVyIHN0cmluZy5cbiAgICAvLyBBZnRlciB0aGUgcHJldmlvdXMgc3BlZWR1cCwgdGhlIGNoYXJhY3RlciBjYW4ndCBiZSBhbiBlcXVhbGl0eS5cbiAgICByZXR1cm4gW1tESUZGX0RFTEVURSwgdGV4dDFdLCBbRElGRl9JTlNFUlQsIHRleHQyXV07XG4gIH1cblxuICAvLyBDaGVjayB0byBzZWUgaWYgdGhlIHByb2JsZW0gY2FuIGJlIHNwbGl0IGluIHR3by5cbiAgdmFyIGhtID0gdGhpcy5oYWxmTWF0Y2hfKHRleHQxLCB0ZXh0Mik7XG4gIGlmIChobSkge1xuICAgIC8vIEEgaGFsZi1tYXRjaCB3YXMgZm91bmQsIHNvcnQgb3V0IHRoZSByZXR1cm4gZGF0YS5cbiAgICB2YXIgdGV4dDFfYSA9IGhtWzBdO1xuICAgIHZhciB0ZXh0MV9iID0gaG1bMV07XG4gICAgdmFyIHRleHQyX2EgPSBobVsyXTtcbiAgICB2YXIgdGV4dDJfYiA9IGhtWzNdO1xuICAgIHZhciBtaWRfY29tbW9uID0gaG1bNF07XG4gICAgLy8gU2VuZCBib3RoIHBhaXJzIG9mZiBmb3Igc2VwYXJhdGUgcHJvY2Vzc2luZy5cbiAgICB2YXIgZGlmZnNfYSA9IHRoaXMubWFpbih0ZXh0MV9hLCB0ZXh0Ml9hLCBjaGVja2xpbmVzLCBkZWFkbGluZSk7XG4gICAgdmFyIGRpZmZzX2IgPSB0aGlzLm1haW4odGV4dDFfYiwgdGV4dDJfYiwgY2hlY2tsaW5lcywgZGVhZGxpbmUpO1xuICAgIC8vIE1lcmdlIHRoZSByZXN1bHRzLlxuICAgIHJldHVybiBkaWZmc19hLmNvbmNhdChbW0RJRkZfRVFVQUwsIG1pZF9jb21tb25dXSwgZGlmZnNfYik7XG4gIH1cblxuICBpZiAoY2hlY2tsaW5lcyAmJiB0ZXh0MS5sZW5ndGggPiAxMDAgJiYgdGV4dDIubGVuZ3RoID4gMTAwKSB7XG4gICAgcmV0dXJuIHRoaXMubGluZU1vZGVfKHRleHQxLCB0ZXh0MiwgZGVhZGxpbmUpO1xuICB9XG5cbiAgcmV0dXJuIHRoaXMuYmlzZWN0Xyh0ZXh0MSwgdGV4dDIsIGRlYWRsaW5lKTtcbn07XG5cblxuLyoqXG4gKiBEbyBhIHF1aWNrIGxpbmUtbGV2ZWwgZGlmZiBvbiBib3RoIHN0cmluZ3MsIHRoZW4gcmVkaWZmIHRoZSBwYXJ0cyBmb3JcbiAqIGdyZWF0ZXIgYWNjdXJhY3kuXG4gKiBUaGlzIHNwZWVkdXAgY2FuIHByb2R1Y2Ugbm9uLW1pbmltYWwgZGlmZnMuXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDEgT2xkIHN0cmluZyB0byBiZSBkaWZmZWQuXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDIgTmV3IHN0cmluZyB0byBiZSBkaWZmZWQuXG4gKiBAcGFyYW0ge251bWJlcn0gZGVhZGxpbmUgVGltZSB3aGVuIHRoZSBkaWZmIHNob3VsZCBiZSBjb21wbGV0ZSBieS5cbiAqIEByZXR1cm4geyFBcnJheS48IWRpZmYuRGlmZj59IEFycmF5IG9mIGRpZmYgdHVwbGVzLlxuICogQHByaXZhdGVcbiAqL1xuZGlmZi5wcm90b3R5cGUubGluZU1vZGVfID0gZnVuY3Rpb24odGV4dDEsIHRleHQyLCBkZWFkbGluZSkge1xuICAvLyBTY2FuIHRoZSB0ZXh0IG9uIGEgbGluZS1ieS1saW5lIGJhc2lzIGZpcnN0LlxuICB2YXIgYSA9IHRoaXMubGluZXNUb0NoYXJzXyh0ZXh0MSwgdGV4dDIpO1xuICB0ZXh0MSA9IGEuY2hhcnMxO1xuICB0ZXh0MiA9IGEuY2hhcnMyO1xuICB2YXIgbGluZWFycmF5ID0gYS5saW5lQXJyYXk7XG5cbiAgdmFyIGRpZmZzID0gdGhpcy5tYWluKHRleHQxLCB0ZXh0MiwgZmFsc2UsIGRlYWRsaW5lKTtcblxuICAvLyBDb252ZXJ0IHRoZSBkaWZmIGJhY2sgdG8gb3JpZ2luYWwgdGV4dC5cbiAgdGhpcy5jaGFyc1RvTGluZXNfKGRpZmZzLCBsaW5lYXJyYXkpO1xuICAvLyBFbGltaW5hdGUgZnJlYWsgbWF0Y2hlcyAoZS5nLiBibGFuayBsaW5lcylcbiAgdGhpcy5jbGVhbnVwU2VtYW50aWMoZGlmZnMpO1xuXG4gIC8vIFJlZGlmZiBhbnkgcmVwbGFjZW1lbnQgYmxvY2tzLCB0aGlzIHRpbWUgY2hhcmFjdGVyLWJ5LWNoYXJhY3Rlci5cbiAgLy8gQWRkIGEgZHVtbXkgZW50cnkgYXQgdGhlIGVuZC5cbiAgZGlmZnMucHVzaChbRElGRl9FUVVBTCwgJyddKTtcbiAgdmFyIHBvaW50ZXIgPSAwO1xuICB2YXIgY291bnRfZGVsZXRlID0gMDtcbiAgdmFyIGNvdW50X2luc2VydCA9IDA7XG4gIHZhciB0ZXh0X2RlbGV0ZSA9ICcnO1xuICB2YXIgdGV4dF9pbnNlcnQgPSAnJztcbiAgd2hpbGUgKHBvaW50ZXIgPCBkaWZmcy5sZW5ndGgpIHtcbiAgICBzd2l0Y2ggKGRpZmZzW3BvaW50ZXJdWzBdKSB7XG4gICAgICBjYXNlIERJRkZfSU5TRVJUOlxuICAgICAgICBjb3VudF9pbnNlcnQrKztcbiAgICAgICAgdGV4dF9pbnNlcnQgKz0gZGlmZnNbcG9pbnRlcl1bMV07XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBESUZGX0RFTEVURTpcbiAgICAgICAgY291bnRfZGVsZXRlKys7XG4gICAgICAgIHRleHRfZGVsZXRlICs9IGRpZmZzW3BvaW50ZXJdWzFdO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgRElGRl9FUVVBTDpcbiAgICAgICAgLy8gVXBvbiByZWFjaGluZyBhbiBlcXVhbGl0eSwgY2hlY2sgZm9yIHByaW9yIHJlZHVuZGFuY2llcy5cbiAgICAgICAgaWYgKGNvdW50X2RlbGV0ZSA+PSAxICYmIGNvdW50X2luc2VydCA+PSAxKSB7XG4gICAgICAgICAgLy8gRGVsZXRlIHRoZSBvZmZlbmRpbmcgcmVjb3JkcyBhbmQgYWRkIHRoZSBtZXJnZWQgb25lcy5cbiAgICAgICAgICBkaWZmcy5zcGxpY2UocG9pbnRlciAtIGNvdW50X2RlbGV0ZSAtIGNvdW50X2luc2VydCxcbiAgICAgICAgICAgICAgICAgICAgICAgY291bnRfZGVsZXRlICsgY291bnRfaW5zZXJ0KTtcbiAgICAgICAgICBwb2ludGVyID0gcG9pbnRlciAtIGNvdW50X2RlbGV0ZSAtIGNvdW50X2luc2VydDtcbiAgICAgICAgICB2YXIgYSA9IHRoaXMubWFpbih0ZXh0X2RlbGV0ZSwgdGV4dF9pbnNlcnQsIGZhbHNlLCBkZWFkbGluZSk7XG4gICAgICAgICAgZm9yICh2YXIgaiA9IGEubGVuZ3RoIC0gMTsgaiA+PSAwOyBqLS0pIHtcbiAgICAgICAgICAgIGRpZmZzLnNwbGljZShwb2ludGVyLCAwLCBhW2pdKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcG9pbnRlciA9IHBvaW50ZXIgKyBhLmxlbmd0aDtcbiAgICAgICAgfVxuICAgICAgICBjb3VudF9pbnNlcnQgPSAwO1xuICAgICAgICBjb3VudF9kZWxldGUgPSAwO1xuICAgICAgICB0ZXh0X2RlbGV0ZSA9ICcnO1xuICAgICAgICB0ZXh0X2luc2VydCA9ICcnO1xuICAgICAgICBicmVhaztcbiAgICB9XG4gICAgcG9pbnRlcisrO1xuICB9XG4gIGRpZmZzLnBvcCgpOyAgLy8gUmVtb3ZlIHRoZSBkdW1teSBlbnRyeSBhdCB0aGUgZW5kLlxuXG4gIHJldHVybiBkaWZmcztcbn07XG5cblxuLyoqXG4gKiBGaW5kIHRoZSAnbWlkZGxlIHNuYWtlJyBvZiBhIGRpZmYsIHNwbGl0IHRoZSBwcm9ibGVtIGluIHR3b1xuICogYW5kIHJldHVybiB0aGUgcmVjdXJzaXZlbHkgY29uc3RydWN0ZWQgZGlmZi5cbiAqIFNlZSBNeWVycyAxOTg2IHBhcGVyOiBBbiBPKE5EKSBEaWZmZXJlbmNlIEFsZ29yaXRobSBhbmQgSXRzIFZhcmlhdGlvbnMuXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDEgT2xkIHN0cmluZyB0byBiZSBkaWZmZWQuXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDIgTmV3IHN0cmluZyB0byBiZSBkaWZmZWQuXG4gKiBAcGFyYW0ge251bWJlcn0gZGVhZGxpbmUgVGltZSBhdCB3aGljaCB0byBiYWlsIGlmIG5vdCB5ZXQgY29tcGxldGUuXG4gKiBAcmV0dXJuIHshQXJyYXkuPCFkaWZmLkRpZmY+fSBBcnJheSBvZiBkaWZmIHR1cGxlcy5cbiAqIEBwcml2YXRlXG4gKi9cbmRpZmYucHJvdG90eXBlLmJpc2VjdF8gPSBmdW5jdGlvbih0ZXh0MSwgdGV4dDIsIGRlYWRsaW5lKSB7XG4gIC8vIENhY2hlIHRoZSB0ZXh0IGxlbmd0aHMgdG8gcHJldmVudCBtdWx0aXBsZSBjYWxscy5cbiAgdmFyIHRleHQxX2xlbmd0aCA9IHRleHQxLmxlbmd0aDtcbiAgdmFyIHRleHQyX2xlbmd0aCA9IHRleHQyLmxlbmd0aDtcbiAgdmFyIG1heF9kID0gTWF0aC5jZWlsKCh0ZXh0MV9sZW5ndGggKyB0ZXh0Ml9sZW5ndGgpIC8gMik7XG4gIHZhciB2X29mZnNldCA9IG1heF9kO1xuICB2YXIgdl9sZW5ndGggPSAyICogbWF4X2Q7XG4gIHZhciB2MSA9IG5ldyBBcnJheSh2X2xlbmd0aCk7XG4gIHZhciB2MiA9IG5ldyBBcnJheSh2X2xlbmd0aCk7XG4gIC8vIFNldHRpbmcgYWxsIGVsZW1lbnRzIHRvIC0xIGlzIGZhc3RlciBpbiBDaHJvbWUgJiBGaXJlZm94IHRoYW4gbWl4aW5nXG4gIC8vIGludGVnZXJzIGFuZCB1bmRlZmluZWQuXG4gIGZvciAodmFyIHggPSAwOyB4IDwgdl9sZW5ndGg7IHgrKykge1xuICAgIHYxW3hdID0gLTE7XG4gICAgdjJbeF0gPSAtMTtcbiAgfVxuICB2MVt2X29mZnNldCArIDFdID0gMDtcbiAgdjJbdl9vZmZzZXQgKyAxXSA9IDA7XG4gIHZhciBkZWx0YSA9IHRleHQxX2xlbmd0aCAtIHRleHQyX2xlbmd0aDtcbiAgLy8gSWYgdGhlIHRvdGFsIG51bWJlciBvZiBjaGFyYWN0ZXJzIGlzIG9kZCwgdGhlbiB0aGUgZnJvbnQgcGF0aCB3aWxsIGNvbGxpZGVcbiAgLy8gd2l0aCB0aGUgcmV2ZXJzZSBwYXRoLlxuICB2YXIgZnJvbnQgPSAoZGVsdGEgJSAyICE9IDApO1xuICAvLyBPZmZzZXRzIGZvciBzdGFydCBhbmQgZW5kIG9mIGsgbG9vcC5cbiAgLy8gUHJldmVudHMgbWFwcGluZyBvZiBzcGFjZSBiZXlvbmQgdGhlIGdyaWQuXG4gIHZhciBrMXN0YXJ0ID0gMDtcbiAgdmFyIGsxZW5kID0gMDtcbiAgdmFyIGsyc3RhcnQgPSAwO1xuICB2YXIgazJlbmQgPSAwO1xuICBmb3IgKHZhciBkID0gMDsgZCA8IG1heF9kOyBkKyspIHtcbiAgICAvLyBCYWlsIG91dCBpZiBkZWFkbGluZSBpcyByZWFjaGVkLlxuICAgIGlmICgobmV3IERhdGUoKSkuZ2V0VGltZSgpID4gZGVhZGxpbmUpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIC8vIFdhbGsgdGhlIGZyb250IHBhdGggb25lIHN0ZXAuXG4gICAgZm9yICh2YXIgazEgPSAtZCArIGsxc3RhcnQ7IGsxIDw9IGQgLSBrMWVuZDsgazEgKz0gMikge1xuICAgICAgdmFyIGsxX29mZnNldCA9IHZfb2Zmc2V0ICsgazE7XG4gICAgICB2YXIgeDE7XG4gICAgICBpZiAoazEgPT0gLWQgfHwgKGsxICE9IGQgJiYgdjFbazFfb2Zmc2V0IC0gMV0gPCB2MVtrMV9vZmZzZXQgKyAxXSkpIHtcbiAgICAgICAgeDEgPSB2MVtrMV9vZmZzZXQgKyAxXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHgxID0gdjFbazFfb2Zmc2V0IC0gMV0gKyAxO1xuICAgICAgfVxuICAgICAgdmFyIHkxID0geDEgLSBrMTtcbiAgICAgIHdoaWxlICh4MSA8IHRleHQxX2xlbmd0aCAmJiB5MSA8IHRleHQyX2xlbmd0aCAmJlxuICAgICAgICAgICAgIHRleHQxLmNoYXJBdCh4MSkgPT0gdGV4dDIuY2hhckF0KHkxKSkge1xuICAgICAgICB4MSsrO1xuICAgICAgICB5MSsrO1xuICAgICAgfVxuICAgICAgdjFbazFfb2Zmc2V0XSA9IHgxO1xuICAgICAgaWYgKHgxID4gdGV4dDFfbGVuZ3RoKSB7XG4gICAgICAgIC8vIFJhbiBvZmYgdGhlIHJpZ2h0IG9mIHRoZSBncmFwaC5cbiAgICAgICAgazFlbmQgKz0gMjtcbiAgICAgIH0gZWxzZSBpZiAoeTEgPiB0ZXh0Ml9sZW5ndGgpIHtcbiAgICAgICAgLy8gUmFuIG9mZiB0aGUgYm90dG9tIG9mIHRoZSBncmFwaC5cbiAgICAgICAgazFzdGFydCArPSAyO1xuICAgICAgfSBlbHNlIGlmIChmcm9udCkge1xuICAgICAgICB2YXIgazJfb2Zmc2V0ID0gdl9vZmZzZXQgKyBkZWx0YSAtIGsxO1xuICAgICAgICBpZiAoazJfb2Zmc2V0ID49IDAgJiYgazJfb2Zmc2V0IDwgdl9sZW5ndGggJiYgdjJbazJfb2Zmc2V0XSAhPSAtMSkge1xuICAgICAgICAgIC8vIE1pcnJvciB4MiBvbnRvIHRvcC1sZWZ0IGNvb3JkaW5hdGUgc3lzdGVtLlxuICAgICAgICAgIHZhciB4MiA9IHRleHQxX2xlbmd0aCAtIHYyW2syX29mZnNldF07XG4gICAgICAgICAgaWYgKHgxID49IHgyKSB7XG4gICAgICAgICAgICAvLyBPdmVybGFwIGRldGVjdGVkLlxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuYmlzZWN0U3BsaXRfKHRleHQxLCB0ZXh0MiwgeDEsIHkxLCBkZWFkbGluZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gV2FsayB0aGUgcmV2ZXJzZSBwYXRoIG9uZSBzdGVwLlxuICAgIGZvciAodmFyIGsyID0gLWQgKyBrMnN0YXJ0OyBrMiA8PSBkIC0gazJlbmQ7IGsyICs9IDIpIHtcbiAgICAgIHZhciBrMl9vZmZzZXQgPSB2X29mZnNldCArIGsyO1xuICAgICAgdmFyIHgyO1xuICAgICAgaWYgKGsyID09IC1kIHx8IChrMiAhPSBkICYmIHYyW2syX29mZnNldCAtIDFdIDwgdjJbazJfb2Zmc2V0ICsgMV0pKSB7XG4gICAgICAgIHgyID0gdjJbazJfb2Zmc2V0ICsgMV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB4MiA9IHYyW2syX29mZnNldCAtIDFdICsgMTtcbiAgICAgIH1cbiAgICAgIHZhciB5MiA9IHgyIC0gazI7XG4gICAgICB3aGlsZSAoeDIgPCB0ZXh0MV9sZW5ndGggJiYgeTIgPCB0ZXh0Ml9sZW5ndGggJiZcbiAgICAgICAgICAgICB0ZXh0MS5jaGFyQXQodGV4dDFfbGVuZ3RoIC0geDIgLSAxKSA9PVxuICAgICAgICAgICAgIHRleHQyLmNoYXJBdCh0ZXh0Ml9sZW5ndGggLSB5MiAtIDEpKSB7XG4gICAgICAgIHgyKys7XG4gICAgICAgIHkyKys7XG4gICAgICB9XG4gICAgICB2MltrMl9vZmZzZXRdID0geDI7XG4gICAgICBpZiAoeDIgPiB0ZXh0MV9sZW5ndGgpIHtcbiAgICAgICAgLy8gUmFuIG9mZiB0aGUgbGVmdCBvZiB0aGUgZ3JhcGguXG4gICAgICAgIGsyZW5kICs9IDI7XG4gICAgICB9IGVsc2UgaWYgKHkyID4gdGV4dDJfbGVuZ3RoKSB7XG4gICAgICAgIC8vIFJhbiBvZmYgdGhlIHRvcCBvZiB0aGUgZ3JhcGguXG4gICAgICAgIGsyc3RhcnQgKz0gMjtcbiAgICAgIH0gZWxzZSBpZiAoIWZyb250KSB7XG4gICAgICAgIHZhciBrMV9vZmZzZXQgPSB2X29mZnNldCArIGRlbHRhIC0gazI7XG4gICAgICAgIGlmIChrMV9vZmZzZXQgPj0gMCAmJiBrMV9vZmZzZXQgPCB2X2xlbmd0aCAmJiB2MVtrMV9vZmZzZXRdICE9IC0xKSB7XG4gICAgICAgICAgdmFyIHgxID0gdjFbazFfb2Zmc2V0XTtcbiAgICAgICAgICB2YXIgeTEgPSB2X29mZnNldCArIHgxIC0gazFfb2Zmc2V0O1xuICAgICAgICAgIC8vIE1pcnJvciB4MiBvbnRvIHRvcC1sZWZ0IGNvb3JkaW5hdGUgc3lzdGVtLlxuICAgICAgICAgIHgyID0gdGV4dDFfbGVuZ3RoIC0geDI7XG4gICAgICAgICAgaWYgKHgxID49IHgyKSB7XG4gICAgICAgICAgICAvLyBPdmVybGFwIGRldGVjdGVkLlxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuYmlzZWN0U3BsaXRfKHRleHQxLCB0ZXh0MiwgeDEsIHkxLCBkZWFkbGluZSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIC8vIERpZmYgdG9vayB0b28gbG9uZyBhbmQgaGl0IHRoZSBkZWFkbGluZSBvclxuICAvLyBudW1iZXIgb2YgZGlmZnMgZXF1YWxzIG51bWJlciBvZiBjaGFyYWN0ZXJzLCBubyBjb21tb25hbGl0eSBhdCBhbGwuXG4gIHJldHVybiBbW0RJRkZfREVMRVRFLCB0ZXh0MV0sIFtESUZGX0lOU0VSVCwgdGV4dDJdXTtcbn07XG5cblxuLyoqXG4gKiBHaXZlbiB0aGUgbG9jYXRpb24gb2YgdGhlICdtaWRkbGUgc25ha2UnLCBzcGxpdCB0aGUgZGlmZiBpbiB0d28gcGFydHNcbiAqIGFuZCByZWN1cnNlLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQxIE9sZCBzdHJpbmcgdG8gYmUgZGlmZmVkLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQyIE5ldyBzdHJpbmcgdG8gYmUgZGlmZmVkLlxuICogQHBhcmFtIHtudW1iZXJ9IHggSW5kZXggb2Ygc3BsaXQgcG9pbnQgaW4gdGV4dDEuXG4gKiBAcGFyYW0ge251bWJlcn0geSBJbmRleCBvZiBzcGxpdCBwb2ludCBpbiB0ZXh0Mi5cbiAqIEBwYXJhbSB7bnVtYmVyfSBkZWFkbGluZSBUaW1lIGF0IHdoaWNoIHRvIGJhaWwgaWYgbm90IHlldCBjb21wbGV0ZS5cbiAqIEByZXR1cm4geyFBcnJheS48IWRpZmYuRGlmZj59IEFycmF5IG9mIGRpZmYgdHVwbGVzLlxuICogQHByaXZhdGVcbiAqL1xuZGlmZi5wcm90b3R5cGUuYmlzZWN0U3BsaXRfID0gZnVuY3Rpb24odGV4dDEsIHRleHQyLCB4LCB5LFxuICAgIGRlYWRsaW5lKSB7XG4gIHZhciB0ZXh0MWEgPSB0ZXh0MS5zdWJzdHJpbmcoMCwgeCk7XG4gIHZhciB0ZXh0MmEgPSB0ZXh0Mi5zdWJzdHJpbmcoMCwgeSk7XG4gIHZhciB0ZXh0MWIgPSB0ZXh0MS5zdWJzdHJpbmcoeCk7XG4gIHZhciB0ZXh0MmIgPSB0ZXh0Mi5zdWJzdHJpbmcoeSk7XG5cbiAgLy8gQ29tcHV0ZSBib3RoIGRpZmZzIHNlcmlhbGx5LlxuICB2YXIgZGlmZnMgPSB0aGlzLm1haW4odGV4dDFhLCB0ZXh0MmEsIGZhbHNlLCBkZWFkbGluZSk7XG4gIHZhciBkaWZmc2IgPSB0aGlzLm1haW4odGV4dDFiLCB0ZXh0MmIsIGZhbHNlLCBkZWFkbGluZSk7XG5cbiAgcmV0dXJuIGRpZmZzLmNvbmNhdChkaWZmc2IpO1xufTtcblxuXG4vKipcbiAqIFNwbGl0IHR3byB0ZXh0cyBpbnRvIGFuIGFycmF5IG9mIHN0cmluZ3MuICBSZWR1Y2UgdGhlIHRleHRzIHRvIGEgc3RyaW5nIG9mXG4gKiBoYXNoZXMgd2hlcmUgZWFjaCBVbmljb2RlIGNoYXJhY3RlciByZXByZXNlbnRzIG9uZSBsaW5lLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQxIEZpcnN0IHN0cmluZy5cbiAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0MiBTZWNvbmQgc3RyaW5nLlxuICogQHJldHVybiB7e2NoYXJzMTogc3RyaW5nLCBjaGFyczI6IHN0cmluZywgbGluZUFycmF5OiAhQXJyYXkuPHN0cmluZz59fVxuICogICAgIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSBlbmNvZGVkIHRleHQxLCB0aGUgZW5jb2RlZCB0ZXh0MiBhbmRcbiAqICAgICB0aGUgYXJyYXkgb2YgdW5pcXVlIHN0cmluZ3MuXG4gKiAgICAgVGhlIHplcm90aCBlbGVtZW50IG9mIHRoZSBhcnJheSBvZiB1bmlxdWUgc3RyaW5ncyBpcyBpbnRlbnRpb25hbGx5IGJsYW5rLlxuICogQHByaXZhdGVcbiAqL1xuZGlmZi5wcm90b3R5cGUubGluZXNUb0NoYXJzXyA9IGZ1bmN0aW9uKHRleHQxLCB0ZXh0Mikge1xuICB2YXIgbGluZUFycmF5ID0gW107ICAvLyBlLmcuIGxpbmVBcnJheVs0XSA9PSAnSGVsbG9cXG4nXG4gIHZhciBsaW5lSGFzaCA9IHt9OyAgIC8vIGUuZy4gbGluZUhhc2hbJ0hlbGxvXFxuJ10gPT0gNFxuXG4gIC8vICdcXHgwMCcgaXMgYSB2YWxpZCBjaGFyYWN0ZXIsIGJ1dCB2YXJpb3VzIGRlYnVnZ2VycyBkb24ndCBsaWtlIGl0LlxuICAvLyBTbyB3ZSdsbCBpbnNlcnQgYSBqdW5rIGVudHJ5IHRvIGF2b2lkIGdlbmVyYXRpbmcgYSBudWxsIGNoYXJhY3Rlci5cbiAgbGluZUFycmF5WzBdID0gJyc7XG5cbiAgLyoqXG4gICAqIFNwbGl0IGEgdGV4dCBpbnRvIGFuIGFycmF5IG9mIHN0cmluZ3MuICBSZWR1Y2UgdGhlIHRleHRzIHRvIGEgc3RyaW5nIG9mXG4gICAqIGhhc2hlcyB3aGVyZSBlYWNoIFVuaWNvZGUgY2hhcmFjdGVyIHJlcHJlc2VudHMgb25lIGxpbmUuXG4gICAqIE1vZGlmaWVzIGxpbmVhcnJheSBhbmQgbGluZWhhc2ggdGhyb3VnaCBiZWluZyBhIGNsb3N1cmUuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0IFN0cmluZyB0byBlbmNvZGUuXG4gICAqIEByZXR1cm4ge3N0cmluZ30gRW5jb2RlZCBzdHJpbmcuXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBmdW5jdGlvbiBkaWZmX2xpbmVzVG9DaGFyc011bmdlXyh0ZXh0KSB7XG4gICAgdmFyIGNoYXJzID0gJyc7XG4gICAgLy8gV2FsayB0aGUgdGV4dCwgcHVsbGluZyBvdXQgYSBzdWJzdHJpbmcgZm9yIGVhY2ggbGluZS5cbiAgICAvLyB0ZXh0LnNwbGl0KCdcXG4nKSB3b3VsZCB3b3VsZCB0ZW1wb3JhcmlseSBkb3VibGUgb3VyIG1lbW9yeSBmb290cHJpbnQuXG4gICAgLy8gTW9kaWZ5aW5nIHRleHQgd291bGQgY3JlYXRlIG1hbnkgbGFyZ2Ugc3RyaW5ncyB0byBnYXJiYWdlIGNvbGxlY3QuXG4gICAgdmFyIGxpbmVTdGFydCA9IDA7XG4gICAgdmFyIGxpbmVFbmQgPSAtMTtcbiAgICAvLyBLZWVwaW5nIG91ciBvd24gbGVuZ3RoIHZhcmlhYmxlIGlzIGZhc3RlciB0aGFuIGxvb2tpbmcgaXQgdXAuXG4gICAgdmFyIGxpbmVBcnJheUxlbmd0aCA9IGxpbmVBcnJheS5sZW5ndGg7XG4gICAgd2hpbGUgKGxpbmVFbmQgPCB0ZXh0Lmxlbmd0aCAtIDEpIHtcbiAgICAgIGxpbmVFbmQgPSB0ZXh0LmluZGV4T2YoJ1xcbicsIGxpbmVTdGFydCk7XG4gICAgICBpZiAobGluZUVuZCA9PSAtMSkge1xuICAgICAgICBsaW5lRW5kID0gdGV4dC5sZW5ndGggLSAxO1xuICAgICAgfVxuICAgICAgdmFyIGxpbmUgPSB0ZXh0LnN1YnN0cmluZyhsaW5lU3RhcnQsIGxpbmVFbmQgKyAxKTtcbiAgICAgIGxpbmVTdGFydCA9IGxpbmVFbmQgKyAxO1xuXG4gICAgICBpZiAobGluZUhhc2guaGFzT3duUHJvcGVydHkgPyBsaW5lSGFzaC5oYXNPd25Qcm9wZXJ0eShsaW5lKSA6XG4gICAgICAgICAgKGxpbmVIYXNoW2xpbmVdICE9PSB1bmRlZmluZWQpKSB7XG4gICAgICAgIGNoYXJzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUobGluZUhhc2hbbGluZV0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2hhcnMgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShsaW5lQXJyYXlMZW5ndGgpO1xuICAgICAgICBsaW5lSGFzaFtsaW5lXSA9IGxpbmVBcnJheUxlbmd0aDtcbiAgICAgICAgbGluZUFycmF5W2xpbmVBcnJheUxlbmd0aCsrXSA9IGxpbmU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjaGFycztcbiAgfVxuXG4gIHZhciBjaGFyczEgPSBkaWZmX2xpbmVzVG9DaGFyc011bmdlXyh0ZXh0MSk7XG4gIHZhciBjaGFyczIgPSBkaWZmX2xpbmVzVG9DaGFyc011bmdlXyh0ZXh0Mik7XG4gIHJldHVybiB7Y2hhcnMxOiBjaGFyczEsIGNoYXJzMjogY2hhcnMyLCBsaW5lQXJyYXk6IGxpbmVBcnJheX07XG59O1xuXG5cbi8qKlxuICogUmVoeWRyYXRlIHRoZSB0ZXh0IGluIGEgZGlmZiBmcm9tIGEgc3RyaW5nIG9mIGxpbmUgaGFzaGVzIHRvIHJlYWwgbGluZXMgb2ZcbiAqIHRleHQuXG4gKiBAcGFyYW0geyFBcnJheS48IWRpZmYuRGlmZj59IGRpZmZzIEFycmF5IG9mIGRpZmYgdHVwbGVzLlxuICogQHBhcmFtIHshQXJyYXkuPHN0cmluZz59IGxpbmVBcnJheSBBcnJheSBvZiB1bmlxdWUgc3RyaW5ncy5cbiAqIEBwcml2YXRlXG4gKi9cbmRpZmYucHJvdG90eXBlLmNoYXJzVG9MaW5lc18gPSBmdW5jdGlvbihkaWZmcywgbGluZUFycmF5KSB7XG4gIGZvciAodmFyIHggPSAwOyB4IDwgZGlmZnMubGVuZ3RoOyB4KyspIHtcbiAgICB2YXIgY2hhcnMgPSBkaWZmc1t4XVsxXTtcbiAgICB2YXIgdGV4dCA9IFtdO1xuICAgIGZvciAodmFyIHkgPSAwOyB5IDwgY2hhcnMubGVuZ3RoOyB5KyspIHtcbiAgICAgIHRleHRbeV0gPSBsaW5lQXJyYXlbY2hhcnMuY2hhckNvZGVBdCh5KV07XG4gICAgfVxuICAgIGRpZmZzW3hdWzFdID0gdGV4dC5qb2luKCcnKTtcbiAgfVxufTtcblxuXG4vKipcbiAqIERldGVybWluZSB0aGUgY29tbW9uIHByZWZpeCBvZiB0d28gc3RyaW5ncy5cbiAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0MSBGaXJzdCBzdHJpbmcuXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDIgU2Vjb25kIHN0cmluZy5cbiAqIEByZXR1cm4ge251bWJlcn0gVGhlIG51bWJlciBvZiBjaGFyYWN0ZXJzIGNvbW1vbiB0byB0aGUgc3RhcnQgb2YgZWFjaFxuICogICAgIHN0cmluZy5cbiAqL1xuZGlmZi5wcm90b3R5cGUuY29tbW9uUHJlZml4ID0gZnVuY3Rpb24odGV4dDEsIHRleHQyKSB7XG4gIC8vIFF1aWNrIGNoZWNrIGZvciBjb21tb24gbnVsbCBjYXNlcy5cbiAgaWYgKCF0ZXh0MSB8fCAhdGV4dDIgfHwgdGV4dDEuY2hhckF0KDApICE9IHRleHQyLmNoYXJBdCgwKSkge1xuICAgIHJldHVybiAwO1xuICB9XG4gIC8vIEJpbmFyeSBzZWFyY2guXG4gIC8vIFBlcmZvcm1hbmNlIGFuYWx5c2lzOiBodHRwOi8vbmVpbC5mcmFzZXIubmFtZS9uZXdzLzIwMDcvMTAvMDkvXG4gIHZhciBwb2ludGVybWluID0gMDtcbiAgdmFyIHBvaW50ZXJtYXggPSBNYXRoLm1pbih0ZXh0MS5sZW5ndGgsIHRleHQyLmxlbmd0aCk7XG4gIHZhciBwb2ludGVybWlkID0gcG9pbnRlcm1heDtcbiAgdmFyIHBvaW50ZXJzdGFydCA9IDA7XG4gIHdoaWxlIChwb2ludGVybWluIDwgcG9pbnRlcm1pZCkge1xuICAgIGlmICh0ZXh0MS5zdWJzdHJpbmcocG9pbnRlcnN0YXJ0LCBwb2ludGVybWlkKSA9PVxuICAgICAgICB0ZXh0Mi5zdWJzdHJpbmcocG9pbnRlcnN0YXJ0LCBwb2ludGVybWlkKSkge1xuICAgICAgcG9pbnRlcm1pbiA9IHBvaW50ZXJtaWQ7XG4gICAgICBwb2ludGVyc3RhcnQgPSBwb2ludGVybWluO1xuICAgIH0gZWxzZSB7XG4gICAgICBwb2ludGVybWF4ID0gcG9pbnRlcm1pZDtcbiAgICB9XG4gICAgcG9pbnRlcm1pZCA9IE1hdGguZmxvb3IoKHBvaW50ZXJtYXggLSBwb2ludGVybWluKSAvIDIgKyBwb2ludGVybWluKTtcbiAgfVxuICByZXR1cm4gcG9pbnRlcm1pZDtcbn07XG5cblxuLyoqXG4gKiBEZXRlcm1pbmUgdGhlIGNvbW1vbiBzdWZmaXggb2YgdHdvIHN0cmluZ3MuXG4gKiBAcGFyYW0ge3N0cmluZ30gdGV4dDEgRmlyc3Qgc3RyaW5nLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQyIFNlY29uZCBzdHJpbmcuXG4gKiBAcmV0dXJuIHtudW1iZXJ9IFRoZSBudW1iZXIgb2YgY2hhcmFjdGVycyBjb21tb24gdG8gdGhlIGVuZCBvZiBlYWNoIHN0cmluZy5cbiAqL1xuZGlmZi5wcm90b3R5cGUuY29tbW9uU3VmZml4ID0gZnVuY3Rpb24odGV4dDEsIHRleHQyKSB7XG4gIC8vIFF1aWNrIGNoZWNrIGZvciBjb21tb24gbnVsbCBjYXNlcy5cbiAgaWYgKCF0ZXh0MSB8fCAhdGV4dDIgfHxcbiAgICAgIHRleHQxLmNoYXJBdCh0ZXh0MS5sZW5ndGggLSAxKSAhPSB0ZXh0Mi5jaGFyQXQodGV4dDIubGVuZ3RoIC0gMSkpIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICAvLyBCaW5hcnkgc2VhcmNoLlxuICAvLyBQZXJmb3JtYW5jZSBhbmFseXNpczogaHR0cDovL25laWwuZnJhc2VyLm5hbWUvbmV3cy8yMDA3LzEwLzA5L1xuICB2YXIgcG9pbnRlcm1pbiA9IDA7XG4gIHZhciBwb2ludGVybWF4ID0gTWF0aC5taW4odGV4dDEubGVuZ3RoLCB0ZXh0Mi5sZW5ndGgpO1xuICB2YXIgcG9pbnRlcm1pZCA9IHBvaW50ZXJtYXg7XG4gIHZhciBwb2ludGVyZW5kID0gMDtcbiAgd2hpbGUgKHBvaW50ZXJtaW4gPCBwb2ludGVybWlkKSB7XG4gICAgaWYgKHRleHQxLnN1YnN0cmluZyh0ZXh0MS5sZW5ndGggLSBwb2ludGVybWlkLCB0ZXh0MS5sZW5ndGggLSBwb2ludGVyZW5kKSA9PVxuICAgICAgICB0ZXh0Mi5zdWJzdHJpbmcodGV4dDIubGVuZ3RoIC0gcG9pbnRlcm1pZCwgdGV4dDIubGVuZ3RoIC0gcG9pbnRlcmVuZCkpIHtcbiAgICAgIHBvaW50ZXJtaW4gPSBwb2ludGVybWlkO1xuICAgICAgcG9pbnRlcmVuZCA9IHBvaW50ZXJtaW47XG4gICAgfSBlbHNlIHtcbiAgICAgIHBvaW50ZXJtYXggPSBwb2ludGVybWlkO1xuICAgIH1cbiAgICBwb2ludGVybWlkID0gTWF0aC5mbG9vcigocG9pbnRlcm1heCAtIHBvaW50ZXJtaW4pIC8gMiArIHBvaW50ZXJtaW4pO1xuICB9XG4gIHJldHVybiBwb2ludGVybWlkO1xufTtcblxuXG4vKipcbiAqIERldGVybWluZSBpZiB0aGUgc3VmZml4IG9mIG9uZSBzdHJpbmcgaXMgdGhlIHByZWZpeCBvZiBhbm90aGVyLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQxIEZpcnN0IHN0cmluZy5cbiAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0MiBTZWNvbmQgc3RyaW5nLlxuICogQHJldHVybiB7bnVtYmVyfSBUaGUgbnVtYmVyIG9mIGNoYXJhY3RlcnMgY29tbW9uIHRvIHRoZSBlbmQgb2YgdGhlIGZpcnN0XG4gKiAgICAgc3RyaW5nIGFuZCB0aGUgc3RhcnQgb2YgdGhlIHNlY29uZCBzdHJpbmcuXG4gKiBAcHJpdmF0ZVxuICovXG5kaWZmLnByb3RvdHlwZS5jb21tb25PdmVybGFwXyA9IGZ1bmN0aW9uKHRleHQxLCB0ZXh0Mikge1xuICAvLyBDYWNoZSB0aGUgdGV4dCBsZW5ndGhzIHRvIHByZXZlbnQgbXVsdGlwbGUgY2FsbHMuXG4gIHZhciB0ZXh0MV9sZW5ndGggPSB0ZXh0MS5sZW5ndGg7XG4gIHZhciB0ZXh0Ml9sZW5ndGggPSB0ZXh0Mi5sZW5ndGg7XG4gIC8vIEVsaW1pbmF0ZSB0aGUgbnVsbCBjYXNlLlxuICBpZiAodGV4dDFfbGVuZ3RoID09IDAgfHwgdGV4dDJfbGVuZ3RoID09IDApIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICAvLyBUcnVuY2F0ZSB0aGUgbG9uZ2VyIHN0cmluZy5cbiAgaWYgKHRleHQxX2xlbmd0aCA+IHRleHQyX2xlbmd0aCkge1xuICAgIHRleHQxID0gdGV4dDEuc3Vic3RyaW5nKHRleHQxX2xlbmd0aCAtIHRleHQyX2xlbmd0aCk7XG4gIH0gZWxzZSBpZiAodGV4dDFfbGVuZ3RoIDwgdGV4dDJfbGVuZ3RoKSB7XG4gICAgdGV4dDIgPSB0ZXh0Mi5zdWJzdHJpbmcoMCwgdGV4dDFfbGVuZ3RoKTtcbiAgfVxuICB2YXIgdGV4dF9sZW5ndGggPSBNYXRoLm1pbih0ZXh0MV9sZW5ndGgsIHRleHQyX2xlbmd0aCk7XG4gIC8vIFF1aWNrIGNoZWNrIGZvciB0aGUgd29yc3QgY2FzZS5cbiAgaWYgKHRleHQxID09IHRleHQyKSB7XG4gICAgcmV0dXJuIHRleHRfbGVuZ3RoO1xuICB9XG5cbiAgLy8gU3RhcnQgYnkgbG9va2luZyBmb3IgYSBzaW5nbGUgY2hhcmFjdGVyIG1hdGNoXG4gIC8vIGFuZCBpbmNyZWFzZSBsZW5ndGggdW50aWwgbm8gbWF0Y2ggaXMgZm91bmQuXG4gIC8vIFBlcmZvcm1hbmNlIGFuYWx5c2lzOiBodHRwOi8vbmVpbC5mcmFzZXIubmFtZS9uZXdzLzIwMTAvMTEvMDQvXG4gIHZhciBiZXN0ID0gMDtcbiAgdmFyIGxlbmd0aCA9IDE7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgdmFyIHBhdHRlcm4gPSB0ZXh0MS5zdWJzdHJpbmcodGV4dF9sZW5ndGggLSBsZW5ndGgpO1xuICAgIHZhciBmb3VuZCA9IHRleHQyLmluZGV4T2YocGF0dGVybik7XG4gICAgaWYgKGZvdW5kID09IC0xKSB7XG4gICAgICByZXR1cm4gYmVzdDtcbiAgICB9XG4gICAgbGVuZ3RoICs9IGZvdW5kO1xuICAgIGlmIChmb3VuZCA9PSAwIHx8IHRleHQxLnN1YnN0cmluZyh0ZXh0X2xlbmd0aCAtIGxlbmd0aCkgPT1cbiAgICAgICAgdGV4dDIuc3Vic3RyaW5nKDAsIGxlbmd0aCkpIHtcbiAgICAgIGJlc3QgPSBsZW5ndGg7XG4gICAgICBsZW5ndGgrKztcbiAgICB9XG4gIH1cbn07XG5cblxuLyoqXG4gKiBEbyB0aGUgdHdvIHRleHRzIHNoYXJlIGEgc3Vic3RyaW5nIHdoaWNoIGlzIGF0IGxlYXN0IGhhbGYgdGhlIGxlbmd0aCBvZiB0aGVcbiAqIGxvbmdlciB0ZXh0P1xuICogVGhpcyBzcGVlZHVwIGNhbiBwcm9kdWNlIG5vbi1taW5pbWFsIGRpZmZzLlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQxIEZpcnN0IHN0cmluZy5cbiAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0MiBTZWNvbmQgc3RyaW5nLlxuICogQHJldHVybiB7QXJyYXkuPHN0cmluZz59IEZpdmUgZWxlbWVudCBBcnJheSwgY29udGFpbmluZyB0aGUgcHJlZml4IG9mXG4gKiAgICAgdGV4dDEsIHRoZSBzdWZmaXggb2YgdGV4dDEsIHRoZSBwcmVmaXggb2YgdGV4dDIsIHRoZSBzdWZmaXggb2ZcbiAqICAgICB0ZXh0MiBhbmQgdGhlIGNvbW1vbiBtaWRkbGUuICBPciBudWxsIGlmIHRoZXJlIHdhcyBubyBtYXRjaC5cbiAqIEBwcml2YXRlXG4gKi9cbmRpZmYucHJvdG90eXBlLmhhbGZNYXRjaF8gPSBmdW5jdGlvbih0ZXh0MSwgdGV4dDIpIHtcbiAgaWYgKHRoaXMuVGltZW91dCA8PSAwKSB7XG4gICAgLy8gRG9uJ3QgcmlzayByZXR1cm5pbmcgYSBub24tb3B0aW1hbCBkaWZmIGlmIHdlIGhhdmUgdW5saW1pdGVkIHRpbWUuXG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgdmFyIGxvbmd0ZXh0ID0gdGV4dDEubGVuZ3RoID4gdGV4dDIubGVuZ3RoID8gdGV4dDEgOiB0ZXh0MjtcbiAgdmFyIHNob3J0dGV4dCA9IHRleHQxLmxlbmd0aCA+IHRleHQyLmxlbmd0aCA/IHRleHQyIDogdGV4dDE7XG4gIGlmIChsb25ndGV4dC5sZW5ndGggPCA0IHx8IHNob3J0dGV4dC5sZW5ndGggKiAyIDwgbG9uZ3RleHQubGVuZ3RoKSB7XG4gICAgcmV0dXJuIG51bGw7ICAvLyBQb2ludGxlc3MuXG4gIH1cbiAgdmFyIGRtcCA9IHRoaXM7ICAvLyAndGhpcycgYmVjb21lcyAnd2luZG93JyBpbiBhIGNsb3N1cmUuXG5cbiAgLyoqXG4gICAqIERvZXMgYSBzdWJzdHJpbmcgb2Ygc2hvcnR0ZXh0IGV4aXN0IHdpdGhpbiBsb25ndGV4dCBzdWNoIHRoYXQgdGhlIHN1YnN0cmluZ1xuICAgKiBpcyBhdCBsZWFzdCBoYWxmIHRoZSBsZW5ndGggb2YgbG9uZ3RleHQ/XG4gICAqIENsb3N1cmUsIGJ1dCBkb2VzIG5vdCByZWZlcmVuY2UgYW55IGV4dGVybmFsIHZhcmlhYmxlcy5cbiAgICogQHBhcmFtIHtzdHJpbmd9IGxvbmd0ZXh0IExvbmdlciBzdHJpbmcuXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBzaG9ydHRleHQgU2hvcnRlciBzdHJpbmcuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBpIFN0YXJ0IGluZGV4IG9mIHF1YXJ0ZXIgbGVuZ3RoIHN1YnN0cmluZyB3aXRoaW4gbG9uZ3RleHQuXG4gICAqIEByZXR1cm4ge0FycmF5LjxzdHJpbmc+fSBGaXZlIGVsZW1lbnQgQXJyYXksIGNvbnRhaW5pbmcgdGhlIHByZWZpeCBvZlxuICAgKiAgICAgbG9uZ3RleHQsIHRoZSBzdWZmaXggb2YgbG9uZ3RleHQsIHRoZSBwcmVmaXggb2Ygc2hvcnR0ZXh0LCB0aGUgc3VmZml4XG4gICAqICAgICBvZiBzaG9ydHRleHQgYW5kIHRoZSBjb21tb24gbWlkZGxlLiAgT3IgbnVsbCBpZiB0aGVyZSB3YXMgbm8gbWF0Y2guXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBmdW5jdGlvbiBkaWZmX2hhbGZNYXRjaElfKGxvbmd0ZXh0LCBzaG9ydHRleHQsIGkpIHtcbiAgICAvLyBTdGFydCB3aXRoIGEgMS80IGxlbmd0aCBzdWJzdHJpbmcgYXQgcG9zaXRpb24gaSBhcyBhIHNlZWQuXG4gICAgdmFyIHNlZWQgPSBsb25ndGV4dC5zdWJzdHJpbmcoaSwgaSArIE1hdGguZmxvb3IobG9uZ3RleHQubGVuZ3RoIC8gNCkpO1xuICAgIHZhciBqID0gLTE7XG4gICAgdmFyIGJlc3RfY29tbW9uID0gJyc7XG4gICAgdmFyIGJlc3RfbG9uZ3RleHRfYSwgYmVzdF9sb25ndGV4dF9iLCBiZXN0X3Nob3J0dGV4dF9hLCBiZXN0X3Nob3J0dGV4dF9iO1xuICAgIHdoaWxlICgoaiA9IHNob3J0dGV4dC5pbmRleE9mKHNlZWQsIGogKyAxKSkgIT0gLTEpIHtcbiAgICAgIHZhciBwcmVmaXhMZW5ndGggPSBkbXAuY29tbW9uUHJlZml4KGxvbmd0ZXh0LnN1YnN0cmluZyhpKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3J0dGV4dC5zdWJzdHJpbmcoaikpO1xuICAgICAgdmFyIHN1ZmZpeExlbmd0aCA9IGRtcC5jb21tb25TdWZmaXgobG9uZ3RleHQuc3Vic3RyaW5nKDAsIGkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvcnR0ZXh0LnN1YnN0cmluZygwLCBqKSk7XG4gICAgICBpZiAoYmVzdF9jb21tb24ubGVuZ3RoIDwgc3VmZml4TGVuZ3RoICsgcHJlZml4TGVuZ3RoKSB7XG4gICAgICAgIGJlc3RfY29tbW9uID0gc2hvcnR0ZXh0LnN1YnN0cmluZyhqIC0gc3VmZml4TGVuZ3RoLCBqKSArXG4gICAgICAgICAgICBzaG9ydHRleHQuc3Vic3RyaW5nKGosIGogKyBwcmVmaXhMZW5ndGgpO1xuICAgICAgICBiZXN0X2xvbmd0ZXh0X2EgPSBsb25ndGV4dC5zdWJzdHJpbmcoMCwgaSAtIHN1ZmZpeExlbmd0aCk7XG4gICAgICAgIGJlc3RfbG9uZ3RleHRfYiA9IGxvbmd0ZXh0LnN1YnN0cmluZyhpICsgcHJlZml4TGVuZ3RoKTtcbiAgICAgICAgYmVzdF9zaG9ydHRleHRfYSA9IHNob3J0dGV4dC5zdWJzdHJpbmcoMCwgaiAtIHN1ZmZpeExlbmd0aCk7XG4gICAgICAgIGJlc3Rfc2hvcnR0ZXh0X2IgPSBzaG9ydHRleHQuc3Vic3RyaW5nKGogKyBwcmVmaXhMZW5ndGgpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoYmVzdF9jb21tb24ubGVuZ3RoICogMiA+PSBsb25ndGV4dC5sZW5ndGgpIHtcbiAgICAgIHJldHVybiBbYmVzdF9sb25ndGV4dF9hLCBiZXN0X2xvbmd0ZXh0X2IsXG4gICAgICAgICAgICAgIGJlc3Rfc2hvcnR0ZXh0X2EsIGJlc3Rfc2hvcnR0ZXh0X2IsIGJlc3RfY29tbW9uXTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9XG5cbiAgLy8gRmlyc3QgY2hlY2sgaWYgdGhlIHNlY29uZCBxdWFydGVyIGlzIHRoZSBzZWVkIGZvciBhIGhhbGYtbWF0Y2guXG4gIHZhciBobTEgPSBkaWZmX2hhbGZNYXRjaElfKGxvbmd0ZXh0LCBzaG9ydHRleHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIE1hdGguY2VpbChsb25ndGV4dC5sZW5ndGggLyA0KSk7XG4gIC8vIENoZWNrIGFnYWluIGJhc2VkIG9uIHRoZSB0aGlyZCBxdWFydGVyLlxuICB2YXIgaG0yID0gZGlmZl9oYWxmTWF0Y2hJXyhsb25ndGV4dCwgc2hvcnR0ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICBNYXRoLmNlaWwobG9uZ3RleHQubGVuZ3RoIC8gMikpO1xuICB2YXIgaG07XG4gIGlmICghaG0xICYmICFobTIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfSBlbHNlIGlmICghaG0yKSB7XG4gICAgaG0gPSBobTE7XG4gIH0gZWxzZSBpZiAoIWhtMSkge1xuICAgIGhtID0gaG0yO1xuICB9IGVsc2Uge1xuICAgIC8vIEJvdGggbWF0Y2hlZC4gIFNlbGVjdCB0aGUgbG9uZ2VzdC5cbiAgICBobSA9IGhtMVs0XS5sZW5ndGggPiBobTJbNF0ubGVuZ3RoID8gaG0xIDogaG0yO1xuICB9XG5cbiAgLy8gQSBoYWxmLW1hdGNoIHdhcyBmb3VuZCwgc29ydCBvdXQgdGhlIHJldHVybiBkYXRhLlxuICB2YXIgdGV4dDFfYSwgdGV4dDFfYiwgdGV4dDJfYSwgdGV4dDJfYjtcbiAgaWYgKHRleHQxLmxlbmd0aCA+IHRleHQyLmxlbmd0aCkge1xuICAgIHRleHQxX2EgPSBobVswXTtcbiAgICB0ZXh0MV9iID0gaG1bMV07XG4gICAgdGV4dDJfYSA9IGhtWzJdO1xuICAgIHRleHQyX2IgPSBobVszXTtcbiAgfSBlbHNlIHtcbiAgICB0ZXh0Ml9hID0gaG1bMF07XG4gICAgdGV4dDJfYiA9IGhtWzFdO1xuICAgIHRleHQxX2EgPSBobVsyXTtcbiAgICB0ZXh0MV9iID0gaG1bM107XG4gIH1cbiAgdmFyIG1pZF9jb21tb24gPSBobVs0XTtcbiAgcmV0dXJuIFt0ZXh0MV9hLCB0ZXh0MV9iLCB0ZXh0Ml9hLCB0ZXh0Ml9iLCBtaWRfY29tbW9uXTtcbn07XG5cblxuLyoqXG4gKiBSZWR1Y2UgdGhlIG51bWJlciBvZiBlZGl0cyBieSBlbGltaW5hdGluZyBzZW1hbnRpY2FsbHkgdHJpdmlhbCBlcXVhbGl0aWVzLlxuICogQHBhcmFtIHshQXJyYXkuPCFkaWZmLkRpZmY+fSBkaWZmcyBBcnJheSBvZiBkaWZmIHR1cGxlcy5cbiAqL1xuZGlmZi5wcm90b3R5cGUuY2xlYW51cFNlbWFudGljID0gZnVuY3Rpb24oZGlmZnMpIHtcbiAgdmFyIGNoYW5nZXMgPSBmYWxzZTtcbiAgdmFyIGVxdWFsaXRpZXMgPSBbXTsgIC8vIFN0YWNrIG9mIGluZGljZXMgd2hlcmUgZXF1YWxpdGllcyBhcmUgZm91bmQuXG4gIHZhciBlcXVhbGl0aWVzTGVuZ3RoID0gMDsgIC8vIEtlZXBpbmcgb3VyIG93biBsZW5ndGggdmFyIGlzIGZhc3RlciBpbiBKUy5cbiAgLyoqIEB0eXBlIHs/c3RyaW5nfSAqL1xuICB2YXIgbGFzdGVxdWFsaXR5ID0gbnVsbDtcbiAgLy8gQWx3YXlzIGVxdWFsIHRvIGRpZmZzW2VxdWFsaXRpZXNbZXF1YWxpdGllc0xlbmd0aCAtIDFdXVsxXVxuICB2YXIgcG9pbnRlciA9IDA7ICAvLyBJbmRleCBvZiBjdXJyZW50IHBvc2l0aW9uLlxuICAvLyBOdW1iZXIgb2YgY2hhcmFjdGVycyB0aGF0IGNoYW5nZWQgcHJpb3IgdG8gdGhlIGVxdWFsaXR5LlxuICB2YXIgbGVuZ3RoX2luc2VydGlvbnMxID0gMDtcbiAgdmFyIGxlbmd0aF9kZWxldGlvbnMxID0gMDtcbiAgLy8gTnVtYmVyIG9mIGNoYXJhY3RlcnMgdGhhdCBjaGFuZ2VkIGFmdGVyIHRoZSBlcXVhbGl0eS5cbiAgdmFyIGxlbmd0aF9pbnNlcnRpb25zMiA9IDA7XG4gIHZhciBsZW5ndGhfZGVsZXRpb25zMiA9IDA7XG4gIHdoaWxlIChwb2ludGVyIDwgZGlmZnMubGVuZ3RoKSB7XG4gICAgaWYgKGRpZmZzW3BvaW50ZXJdWzBdID09IERJRkZfRVFVQUwpIHsgIC8vIEVxdWFsaXR5IGZvdW5kLlxuICAgICAgZXF1YWxpdGllc1tlcXVhbGl0aWVzTGVuZ3RoKytdID0gcG9pbnRlcjtcbiAgICAgIGxlbmd0aF9pbnNlcnRpb25zMSA9IGxlbmd0aF9pbnNlcnRpb25zMjtcbiAgICAgIGxlbmd0aF9kZWxldGlvbnMxID0gbGVuZ3RoX2RlbGV0aW9uczI7XG4gICAgICBsZW5ndGhfaW5zZXJ0aW9uczIgPSAwO1xuICAgICAgbGVuZ3RoX2RlbGV0aW9uczIgPSAwO1xuICAgICAgbGFzdGVxdWFsaXR5ID0gZGlmZnNbcG9pbnRlcl1bMV07XG4gICAgfSBlbHNlIHsgIC8vIEFuIGluc2VydGlvbiBvciBkZWxldGlvbi5cbiAgICAgIGlmIChkaWZmc1twb2ludGVyXVswXSA9PSBESUZGX0lOU0VSVCkge1xuICAgICAgICBsZW5ndGhfaW5zZXJ0aW9uczIgKz0gZGlmZnNbcG9pbnRlcl1bMV0ubGVuZ3RoO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbGVuZ3RoX2RlbGV0aW9uczIgKz0gZGlmZnNbcG9pbnRlcl1bMV0ubGVuZ3RoO1xuICAgICAgfVxuICAgICAgLy8gRWxpbWluYXRlIGFuIGVxdWFsaXR5IHRoYXQgaXMgc21hbGxlciBvciBlcXVhbCB0byB0aGUgZWRpdHMgb24gYm90aFxuICAgICAgLy8gc2lkZXMgb2YgaXQuXG4gICAgICBpZiAobGFzdGVxdWFsaXR5ICYmIChsYXN0ZXF1YWxpdHkubGVuZ3RoIDw9XG4gICAgICAgICAgTWF0aC5tYXgobGVuZ3RoX2luc2VydGlvbnMxLCBsZW5ndGhfZGVsZXRpb25zMSkpICYmXG4gICAgICAgICAgKGxhc3RlcXVhbGl0eS5sZW5ndGggPD0gTWF0aC5tYXgobGVuZ3RoX2luc2VydGlvbnMyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlbmd0aF9kZWxldGlvbnMyKSkpIHtcbiAgICAgICAgLy8gRHVwbGljYXRlIHJlY29yZC5cbiAgICAgICAgZGlmZnMuc3BsaWNlKGVxdWFsaXRpZXNbZXF1YWxpdGllc0xlbmd0aCAtIDFdLCAwLFxuICAgICAgICAgICAgICAgICAgICAgW0RJRkZfREVMRVRFLCBsYXN0ZXF1YWxpdHldKTtcbiAgICAgICAgLy8gQ2hhbmdlIHNlY29uZCBjb3B5IHRvIGluc2VydC5cbiAgICAgICAgZGlmZnNbZXF1YWxpdGllc1tlcXVhbGl0aWVzTGVuZ3RoIC0gMV0gKyAxXVswXSA9IERJRkZfSU5TRVJUO1xuICAgICAgICAvLyBUaHJvdyBhd2F5IHRoZSBlcXVhbGl0eSB3ZSBqdXN0IGRlbGV0ZWQuXG4gICAgICAgIGVxdWFsaXRpZXNMZW5ndGgtLTtcbiAgICAgICAgLy8gVGhyb3cgYXdheSB0aGUgcHJldmlvdXMgZXF1YWxpdHkgKGl0IG5lZWRzIHRvIGJlIHJlZXZhbHVhdGVkKS5cbiAgICAgICAgZXF1YWxpdGllc0xlbmd0aC0tO1xuICAgICAgICBwb2ludGVyID0gZXF1YWxpdGllc0xlbmd0aCA+IDAgPyBlcXVhbGl0aWVzW2VxdWFsaXRpZXNMZW5ndGggLSAxXSA6IC0xO1xuICAgICAgICBsZW5ndGhfaW5zZXJ0aW9uczEgPSAwOyAgLy8gUmVzZXQgdGhlIGNvdW50ZXJzLlxuICAgICAgICBsZW5ndGhfZGVsZXRpb25zMSA9IDA7XG4gICAgICAgIGxlbmd0aF9pbnNlcnRpb25zMiA9IDA7XG4gICAgICAgIGxlbmd0aF9kZWxldGlvbnMyID0gMDtcbiAgICAgICAgbGFzdGVxdWFsaXR5ID0gbnVsbDtcbiAgICAgICAgY2hhbmdlcyA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHBvaW50ZXIrKztcbiAgfVxuXG4gIC8vIE5vcm1hbGl6ZSB0aGUgZGlmZi5cbiAgaWYgKGNoYW5nZXMpIHtcbiAgICB0aGlzLmNsZWFudXBNZXJnZShkaWZmcyk7XG4gIH1cbiAgdGhpcy5jbGVhbnVwU2VtYW50aWNMb3NzbGVzcyhkaWZmcyk7XG5cbiAgLy8gRmluZCBhbnkgb3ZlcmxhcHMgYmV0d2VlbiBkZWxldGlvbnMgYW5kIGluc2VydGlvbnMuXG4gIC8vIGUuZzogPGRlbD5hYmN4eHg8L2RlbD48aW5zPnh4eGRlZjwvaW5zPlxuICAvLyAgIC0+IDxkZWw+YWJjPC9kZWw+eHh4PGlucz5kZWY8L2lucz5cbiAgLy8gZS5nOiA8ZGVsPnh4eGFiYzwvZGVsPjxpbnM+ZGVmeHh4PC9pbnM+XG4gIC8vICAgLT4gPGlucz5kZWY8L2lucz54eHg8ZGVsPmFiYzwvZGVsPlxuICAvLyBPbmx5IGV4dHJhY3QgYW4gb3ZlcmxhcCBpZiBpdCBpcyBhcyBiaWcgYXMgdGhlIGVkaXQgYWhlYWQgb3IgYmVoaW5kIGl0LlxuICBwb2ludGVyID0gMTtcbiAgd2hpbGUgKHBvaW50ZXIgPCBkaWZmcy5sZW5ndGgpIHtcbiAgICBpZiAoZGlmZnNbcG9pbnRlciAtIDFdWzBdID09IERJRkZfREVMRVRFICYmXG4gICAgICAgIGRpZmZzW3BvaW50ZXJdWzBdID09IERJRkZfSU5TRVJUKSB7XG4gICAgICB2YXIgZGVsZXRpb24gPSBkaWZmc1twb2ludGVyIC0gMV1bMV07XG4gICAgICB2YXIgaW5zZXJ0aW9uID0gZGlmZnNbcG9pbnRlcl1bMV07XG4gICAgICB2YXIgb3ZlcmxhcF9sZW5ndGgxID0gdGhpcy5jb21tb25PdmVybGFwXyhkZWxldGlvbiwgaW5zZXJ0aW9uKTtcbiAgICAgIHZhciBvdmVybGFwX2xlbmd0aDIgPSB0aGlzLmNvbW1vbk92ZXJsYXBfKGluc2VydGlvbiwgZGVsZXRpb24pO1xuICAgICAgaWYgKG92ZXJsYXBfbGVuZ3RoMSA+PSBvdmVybGFwX2xlbmd0aDIpIHtcbiAgICAgICAgaWYgKG92ZXJsYXBfbGVuZ3RoMSA+PSBkZWxldGlvbi5sZW5ndGggLyAyIHx8XG4gICAgICAgICAgICBvdmVybGFwX2xlbmd0aDEgPj0gaW5zZXJ0aW9uLmxlbmd0aCAvIDIpIHtcbiAgICAgICAgICAvLyBPdmVybGFwIGZvdW5kLiAgSW5zZXJ0IGFuIGVxdWFsaXR5IGFuZCB0cmltIHRoZSBzdXJyb3VuZGluZyBlZGl0cy5cbiAgICAgICAgICBkaWZmcy5zcGxpY2UocG9pbnRlciwgMCxcbiAgICAgICAgICAgICAgW0RJRkZfRVFVQUwsIGluc2VydGlvbi5zdWJzdHJpbmcoMCwgb3ZlcmxhcF9sZW5ndGgxKV0pO1xuICAgICAgICAgIGRpZmZzW3BvaW50ZXIgLSAxXVsxXSA9XG4gICAgICAgICAgICAgIGRlbGV0aW9uLnN1YnN0cmluZygwLCBkZWxldGlvbi5sZW5ndGggLSBvdmVybGFwX2xlbmd0aDEpO1xuICAgICAgICAgIGRpZmZzW3BvaW50ZXIgKyAxXVsxXSA9IGluc2VydGlvbi5zdWJzdHJpbmcob3ZlcmxhcF9sZW5ndGgxKTtcbiAgICAgICAgICBwb2ludGVyKys7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChvdmVybGFwX2xlbmd0aDIgPj0gZGVsZXRpb24ubGVuZ3RoIC8gMiB8fFxuICAgICAgICAgICAgb3ZlcmxhcF9sZW5ndGgyID49IGluc2VydGlvbi5sZW5ndGggLyAyKSB7XG4gICAgICAgICAgLy8gUmV2ZXJzZSBvdmVybGFwIGZvdW5kLlxuICAgICAgICAgIC8vIEluc2VydCBhbiBlcXVhbGl0eSBhbmQgc3dhcCBhbmQgdHJpbSB0aGUgc3Vycm91bmRpbmcgZWRpdHMuXG4gICAgICAgICAgZGlmZnMuc3BsaWNlKHBvaW50ZXIsIDAsXG4gICAgICAgICAgICAgIFtESUZGX0VRVUFMLCBkZWxldGlvbi5zdWJzdHJpbmcoMCwgb3ZlcmxhcF9sZW5ndGgyKV0pO1xuICAgICAgICAgIGRpZmZzW3BvaW50ZXIgLSAxXVswXSA9IERJRkZfSU5TRVJUO1xuICAgICAgICAgIGRpZmZzW3BvaW50ZXIgLSAxXVsxXSA9XG4gICAgICAgICAgICAgIGluc2VydGlvbi5zdWJzdHJpbmcoMCwgaW5zZXJ0aW9uLmxlbmd0aCAtIG92ZXJsYXBfbGVuZ3RoMik7XG4gICAgICAgICAgZGlmZnNbcG9pbnRlciArIDFdWzBdID0gRElGRl9ERUxFVEU7XG4gICAgICAgICAgZGlmZnNbcG9pbnRlciArIDFdWzFdID1cbiAgICAgICAgICAgICAgZGVsZXRpb24uc3Vic3RyaW5nKG92ZXJsYXBfbGVuZ3RoMik7XG4gICAgICAgICAgcG9pbnRlcisrO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBwb2ludGVyKys7XG4gICAgfVxuICAgIHBvaW50ZXIrKztcbiAgfVxufTtcblxuXG4vKipcbiAqIExvb2sgZm9yIHNpbmdsZSBlZGl0cyBzdXJyb3VuZGVkIG9uIGJvdGggc2lkZXMgYnkgZXF1YWxpdGllc1xuICogd2hpY2ggY2FuIGJlIHNoaWZ0ZWQgc2lkZXdheXMgdG8gYWxpZ24gdGhlIGVkaXQgdG8gYSB3b3JkIGJvdW5kYXJ5LlxuICogZS5nOiBUaGUgYzxpbnM+YXQgYzwvaW5zPmFtZS4gLT4gVGhlIDxpbnM+Y2F0IDwvaW5zPmNhbWUuXG4gKiBAcGFyYW0geyFBcnJheS48IWRpZmYuRGlmZj59IGRpZmZzIEFycmF5IG9mIGRpZmYgdHVwbGVzLlxuICovXG5kaWZmLnByb3RvdHlwZS5jbGVhbnVwU2VtYW50aWNMb3NzbGVzcyA9IGZ1bmN0aW9uKGRpZmZzKSB7XG4gIC8qKlxuICAgKiBHaXZlbiB0d28gc3RyaW5ncywgY29tcHV0ZSBhIHNjb3JlIHJlcHJlc2VudGluZyB3aGV0aGVyIHRoZSBpbnRlcm5hbFxuICAgKiBib3VuZGFyeSBmYWxscyBvbiBsb2dpY2FsIGJvdW5kYXJpZXMuXG4gICAqIFNjb3JlcyByYW5nZSBmcm9tIDYgKGJlc3QpIHRvIDAgKHdvcnN0KS5cbiAgICogQ2xvc3VyZSwgYnV0IGRvZXMgbm90IHJlZmVyZW5jZSBhbnkgZXh0ZXJuYWwgdmFyaWFibGVzLlxuICAgKiBAcGFyYW0ge3N0cmluZ30gb25lIEZpcnN0IHN0cmluZy5cbiAgICogQHBhcmFtIHtzdHJpbmd9IHR3byBTZWNvbmQgc3RyaW5nLlxuICAgKiBAcmV0dXJuIHtudW1iZXJ9IFRoZSBzY29yZS5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIGZ1bmN0aW9uIGRpZmZfY2xlYW51cFNlbWFudGljU2NvcmVfKG9uZSwgdHdvKSB7XG4gICAgaWYgKCFvbmUgfHwgIXR3bykge1xuICAgICAgLy8gRWRnZXMgYXJlIHRoZSBiZXN0LlxuICAgICAgcmV0dXJuIDY7XG4gICAgfVxuXG4gICAgLy8gRWFjaCBwb3J0IG9mIHRoaXMgZnVuY3Rpb24gYmVoYXZlcyBzbGlnaHRseSBkaWZmZXJlbnRseSBkdWUgdG9cbiAgICAvLyBzdWJ0bGUgZGlmZmVyZW5jZXMgaW4gZWFjaCBsYW5ndWFnZSdzIGRlZmluaXRpb24gb2YgdGhpbmdzIGxpa2VcbiAgICAvLyAnd2hpdGVzcGFjZScuICBTaW5jZSB0aGlzIGZ1bmN0aW9uJ3MgcHVycG9zZSBpcyBsYXJnZWx5IGNvc21ldGljLFxuICAgIC8vIHRoZSBjaG9pY2UgaGFzIGJlZW4gbWFkZSB0byB1c2UgZWFjaCBsYW5ndWFnZSdzIG5hdGl2ZSBmZWF0dXJlc1xuICAgIC8vIHJhdGhlciB0aGFuIGZvcmNlIHRvdGFsIGNvbmZvcm1pdHkuXG4gICAgdmFyIGNoYXIxID0gb25lLmNoYXJBdChvbmUubGVuZ3RoIC0gMSk7XG4gICAgdmFyIGNoYXIyID0gdHdvLmNoYXJBdCgwKTtcbiAgICB2YXIgbm9uQWxwaGFOdW1lcmljMSA9IGNoYXIxLm1hdGNoKGRpZmYubm9uQWxwaGFOdW1lcmljUmVnZXhfKTtcbiAgICB2YXIgbm9uQWxwaGFOdW1lcmljMiA9IGNoYXIyLm1hdGNoKGRpZmYubm9uQWxwaGFOdW1lcmljUmVnZXhfKTtcbiAgICB2YXIgd2hpdGVzcGFjZTEgPSBub25BbHBoYU51bWVyaWMxICYmXG4gICAgICAgIGNoYXIxLm1hdGNoKGRpZmYud2hpdGVzcGFjZVJlZ2V4Xyk7XG4gICAgdmFyIHdoaXRlc3BhY2UyID0gbm9uQWxwaGFOdW1lcmljMiAmJlxuICAgICAgICBjaGFyMi5tYXRjaChkaWZmLndoaXRlc3BhY2VSZWdleF8pO1xuICAgIHZhciBsaW5lQnJlYWsxID0gd2hpdGVzcGFjZTEgJiZcbiAgICAgICAgY2hhcjEubWF0Y2goZGlmZi5saW5lYnJlYWtSZWdleF8pO1xuICAgIHZhciBsaW5lQnJlYWsyID0gd2hpdGVzcGFjZTIgJiZcbiAgICAgICAgY2hhcjIubWF0Y2goZGlmZi5saW5lYnJlYWtSZWdleF8pO1xuICAgIHZhciBibGFua0xpbmUxID0gbGluZUJyZWFrMSAmJlxuICAgICAgICBvbmUubWF0Y2goZGlmZi5ibGFua2xpbmVFbmRSZWdleF8pO1xuICAgIHZhciBibGFua0xpbmUyID0gbGluZUJyZWFrMiAmJlxuICAgICAgICB0d28ubWF0Y2goZGlmZi5ibGFua2xpbmVTdGFydFJlZ2V4Xyk7XG5cbiAgICBpZiAoYmxhbmtMaW5lMSB8fCBibGFua0xpbmUyKSB7XG4gICAgICAvLyBGaXZlIHBvaW50cyBmb3IgYmxhbmsgbGluZXMuXG4gICAgICByZXR1cm4gNTtcbiAgICB9IGVsc2UgaWYgKGxpbmVCcmVhazEgfHwgbGluZUJyZWFrMikge1xuICAgICAgLy8gRm91ciBwb2ludHMgZm9yIGxpbmUgYnJlYWtzLlxuICAgICAgcmV0dXJuIDQ7XG4gICAgfSBlbHNlIGlmIChub25BbHBoYU51bWVyaWMxICYmICF3aGl0ZXNwYWNlMSAmJiB3aGl0ZXNwYWNlMikge1xuICAgICAgLy8gVGhyZWUgcG9pbnRzIGZvciBlbmQgb2Ygc2VudGVuY2VzLlxuICAgICAgcmV0dXJuIDM7XG4gICAgfSBlbHNlIGlmICh3aGl0ZXNwYWNlMSB8fCB3aGl0ZXNwYWNlMikge1xuICAgICAgLy8gVHdvIHBvaW50cyBmb3Igd2hpdGVzcGFjZS5cbiAgICAgIHJldHVybiAyO1xuICAgIH0gZWxzZSBpZiAobm9uQWxwaGFOdW1lcmljMSB8fCBub25BbHBoYU51bWVyaWMyKSB7XG4gICAgICAvLyBPbmUgcG9pbnQgZm9yIG5vbi1hbHBoYW51bWVyaWMuXG4gICAgICByZXR1cm4gMTtcbiAgICB9XG4gICAgcmV0dXJuIDA7XG4gIH1cblxuICB2YXIgcG9pbnRlciA9IDE7XG4gIC8vIEludGVudGlvbmFsbHkgaWdub3JlIHRoZSBmaXJzdCBhbmQgbGFzdCBlbGVtZW50IChkb24ndCBuZWVkIGNoZWNraW5nKS5cbiAgd2hpbGUgKHBvaW50ZXIgPCBkaWZmcy5sZW5ndGggLSAxKSB7XG4gICAgaWYgKGRpZmZzW3BvaW50ZXIgLSAxXVswXSA9PSBESUZGX0VRVUFMICYmXG4gICAgICAgIGRpZmZzW3BvaW50ZXIgKyAxXVswXSA9PSBESUZGX0VRVUFMKSB7XG4gICAgICAvLyBUaGlzIGlzIGEgc2luZ2xlIGVkaXQgc3Vycm91bmRlZCBieSBlcXVhbGl0aWVzLlxuICAgICAgdmFyIGVxdWFsaXR5MSA9IGRpZmZzW3BvaW50ZXIgLSAxXVsxXTtcbiAgICAgIHZhciBlZGl0ID0gZGlmZnNbcG9pbnRlcl1bMV07XG4gICAgICB2YXIgZXF1YWxpdHkyID0gZGlmZnNbcG9pbnRlciArIDFdWzFdO1xuXG4gICAgICAvLyBGaXJzdCwgc2hpZnQgdGhlIGVkaXQgYXMgZmFyIGxlZnQgYXMgcG9zc2libGUuXG4gICAgICB2YXIgY29tbW9uT2Zmc2V0ID0gdGhpcy5jb21tb25TdWZmaXgoZXF1YWxpdHkxLCBlZGl0KTtcbiAgICAgIGlmIChjb21tb25PZmZzZXQpIHtcbiAgICAgICAgdmFyIGNvbW1vblN0cmluZyA9IGVkaXQuc3Vic3RyaW5nKGVkaXQubGVuZ3RoIC0gY29tbW9uT2Zmc2V0KTtcbiAgICAgICAgZXF1YWxpdHkxID0gZXF1YWxpdHkxLnN1YnN0cmluZygwLCBlcXVhbGl0eTEubGVuZ3RoIC0gY29tbW9uT2Zmc2V0KTtcbiAgICAgICAgZWRpdCA9IGNvbW1vblN0cmluZyArIGVkaXQuc3Vic3RyaW5nKDAsIGVkaXQubGVuZ3RoIC0gY29tbW9uT2Zmc2V0KTtcbiAgICAgICAgZXF1YWxpdHkyID0gY29tbW9uU3RyaW5nICsgZXF1YWxpdHkyO1xuICAgICAgfVxuXG4gICAgICAvLyBTZWNvbmQsIHN0ZXAgY2hhcmFjdGVyIGJ5IGNoYXJhY3RlciByaWdodCwgbG9va2luZyBmb3IgdGhlIGJlc3QgZml0LlxuICAgICAgdmFyIGJlc3RFcXVhbGl0eTEgPSBlcXVhbGl0eTE7XG4gICAgICB2YXIgYmVzdEVkaXQgPSBlZGl0O1xuICAgICAgdmFyIGJlc3RFcXVhbGl0eTIgPSBlcXVhbGl0eTI7XG4gICAgICB2YXIgYmVzdFNjb3JlID0gZGlmZl9jbGVhbnVwU2VtYW50aWNTY29yZV8oZXF1YWxpdHkxLCBlZGl0KSArXG4gICAgICAgICAgZGlmZl9jbGVhbnVwU2VtYW50aWNTY29yZV8oZWRpdCwgZXF1YWxpdHkyKTtcbiAgICAgIHdoaWxlIChlZGl0LmNoYXJBdCgwKSA9PT0gZXF1YWxpdHkyLmNoYXJBdCgwKSkge1xuICAgICAgICBlcXVhbGl0eTEgKz0gZWRpdC5jaGFyQXQoMCk7XG4gICAgICAgIGVkaXQgPSBlZGl0LnN1YnN0cmluZygxKSArIGVxdWFsaXR5Mi5jaGFyQXQoMCk7XG4gICAgICAgIGVxdWFsaXR5MiA9IGVxdWFsaXR5Mi5zdWJzdHJpbmcoMSk7XG4gICAgICAgIHZhciBzY29yZSA9IGRpZmZfY2xlYW51cFNlbWFudGljU2NvcmVfKGVxdWFsaXR5MSwgZWRpdCkgK1xuICAgICAgICAgICAgZGlmZl9jbGVhbnVwU2VtYW50aWNTY29yZV8oZWRpdCwgZXF1YWxpdHkyKTtcbiAgICAgICAgLy8gVGhlID49IGVuY291cmFnZXMgdHJhaWxpbmcgcmF0aGVyIHRoYW4gbGVhZGluZyB3aGl0ZXNwYWNlIG9uIGVkaXRzLlxuICAgICAgICBpZiAoc2NvcmUgPj0gYmVzdFNjb3JlKSB7XG4gICAgICAgICAgYmVzdFNjb3JlID0gc2NvcmU7XG4gICAgICAgICAgYmVzdEVxdWFsaXR5MSA9IGVxdWFsaXR5MTtcbiAgICAgICAgICBiZXN0RWRpdCA9IGVkaXQ7XG4gICAgICAgICAgYmVzdEVxdWFsaXR5MiA9IGVxdWFsaXR5MjtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoZGlmZnNbcG9pbnRlciAtIDFdWzFdICE9IGJlc3RFcXVhbGl0eTEpIHtcbiAgICAgICAgLy8gV2UgaGF2ZSBhbiBpbXByb3ZlbWVudCwgc2F2ZSBpdCBiYWNrIHRvIHRoZSBkaWZmLlxuICAgICAgICBpZiAoYmVzdEVxdWFsaXR5MSkge1xuICAgICAgICAgIGRpZmZzW3BvaW50ZXIgLSAxXVsxXSA9IGJlc3RFcXVhbGl0eTE7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGlmZnMuc3BsaWNlKHBvaW50ZXIgLSAxLCAxKTtcbiAgICAgICAgICBwb2ludGVyLS07XG4gICAgICAgIH1cbiAgICAgICAgZGlmZnNbcG9pbnRlcl1bMV0gPSBiZXN0RWRpdDtcbiAgICAgICAgaWYgKGJlc3RFcXVhbGl0eTIpIHtcbiAgICAgICAgICBkaWZmc1twb2ludGVyICsgMV1bMV0gPSBiZXN0RXF1YWxpdHkyO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGRpZmZzLnNwbGljZShwb2ludGVyICsgMSwgMSk7XG4gICAgICAgICAgcG9pbnRlci0tO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHBvaW50ZXIrKztcbiAgfVxufTtcblxuLy8gRGVmaW5lIHNvbWUgcmVnZXggcGF0dGVybnMgZm9yIG1hdGNoaW5nIGJvdW5kYXJpZXMuXG5kaWZmLm5vbkFscGhhTnVtZXJpY1JlZ2V4XyA9IC9bXmEtekEtWjAtOV0vO1xuZGlmZi53aGl0ZXNwYWNlUmVnZXhfID0gL1xccy87XG5kaWZmLmxpbmVicmVha1JlZ2V4XyA9IC9bXFxyXFxuXS87XG5kaWZmLmJsYW5rbGluZUVuZFJlZ2V4XyA9IC9cXG5cXHI/XFxuJC87XG5kaWZmLmJsYW5rbGluZVN0YXJ0UmVnZXhfID0gL15cXHI/XFxuXFxyP1xcbi87XG5cbi8qKlxuICogUmVkdWNlIHRoZSBudW1iZXIgb2YgZWRpdHMgYnkgZWxpbWluYXRpbmcgb3BlcmF0aW9uYWxseSB0cml2aWFsIGVxdWFsaXRpZXMuXG4gKiBAcGFyYW0geyFBcnJheS48IWRpZmYuRGlmZj59IGRpZmZzIEFycmF5IG9mIGRpZmYgdHVwbGVzLlxuICovXG5kaWZmLnByb3RvdHlwZS5jbGVhbnVwRWZmaWNpZW5jeSA9IGZ1bmN0aW9uKGRpZmZzKSB7XG4gIHZhciBjaGFuZ2VzID0gZmFsc2U7XG4gIHZhciBlcXVhbGl0aWVzID0gW107ICAvLyBTdGFjayBvZiBpbmRpY2VzIHdoZXJlIGVxdWFsaXRpZXMgYXJlIGZvdW5kLlxuICB2YXIgZXF1YWxpdGllc0xlbmd0aCA9IDA7ICAvLyBLZWVwaW5nIG91ciBvd24gbGVuZ3RoIHZhciBpcyBmYXN0ZXIgaW4gSlMuXG4gIC8qKiBAdHlwZSB7P3N0cmluZ30gKi9cbiAgdmFyIGxhc3RlcXVhbGl0eSA9IG51bGw7XG4gIC8vIEFsd2F5cyBlcXVhbCB0byBkaWZmc1tlcXVhbGl0aWVzW2VxdWFsaXRpZXNMZW5ndGggLSAxXV1bMV1cbiAgdmFyIHBvaW50ZXIgPSAwOyAgLy8gSW5kZXggb2YgY3VycmVudCBwb3NpdGlvbi5cbiAgLy8gSXMgdGhlcmUgYW4gaW5zZXJ0aW9uIG9wZXJhdGlvbiBiZWZvcmUgdGhlIGxhc3QgZXF1YWxpdHkuXG4gIHZhciBwcmVfaW5zID0gZmFsc2U7XG4gIC8vIElzIHRoZXJlIGEgZGVsZXRpb24gb3BlcmF0aW9uIGJlZm9yZSB0aGUgbGFzdCBlcXVhbGl0eS5cbiAgdmFyIHByZV9kZWwgPSBmYWxzZTtcbiAgLy8gSXMgdGhlcmUgYW4gaW5zZXJ0aW9uIG9wZXJhdGlvbiBhZnRlciB0aGUgbGFzdCBlcXVhbGl0eS5cbiAgdmFyIHBvc3RfaW5zID0gZmFsc2U7XG4gIC8vIElzIHRoZXJlIGEgZGVsZXRpb24gb3BlcmF0aW9uIGFmdGVyIHRoZSBsYXN0IGVxdWFsaXR5LlxuICB2YXIgcG9zdF9kZWwgPSBmYWxzZTtcbiAgd2hpbGUgKHBvaW50ZXIgPCBkaWZmcy5sZW5ndGgpIHtcbiAgICBpZiAoZGlmZnNbcG9pbnRlcl1bMF0gPT0gRElGRl9FUVVBTCkgeyAgLy8gRXF1YWxpdHkgZm91bmQuXG4gICAgICBpZiAoZGlmZnNbcG9pbnRlcl1bMV0ubGVuZ3RoIDwgdGhpcy5FZGl0Q29zdCAmJlxuICAgICAgICAgIChwb3N0X2lucyB8fCBwb3N0X2RlbCkpIHtcbiAgICAgICAgLy8gQ2FuZGlkYXRlIGZvdW5kLlxuICAgICAgICBlcXVhbGl0aWVzW2VxdWFsaXRpZXNMZW5ndGgrK10gPSBwb2ludGVyO1xuICAgICAgICBwcmVfaW5zID0gcG9zdF9pbnM7XG4gICAgICAgIHByZV9kZWwgPSBwb3N0X2RlbDtcbiAgICAgICAgbGFzdGVxdWFsaXR5ID0gZGlmZnNbcG9pbnRlcl1bMV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBOb3QgYSBjYW5kaWRhdGUsIGFuZCBjYW4gbmV2ZXIgYmVjb21lIG9uZS5cbiAgICAgICAgZXF1YWxpdGllc0xlbmd0aCA9IDA7XG4gICAgICAgIGxhc3RlcXVhbGl0eSA9IG51bGw7XG4gICAgICB9XG4gICAgICBwb3N0X2lucyA9IHBvc3RfZGVsID0gZmFsc2U7XG4gICAgfSBlbHNlIHsgIC8vIEFuIGluc2VydGlvbiBvciBkZWxldGlvbi5cbiAgICAgIGlmIChkaWZmc1twb2ludGVyXVswXSA9PSBESUZGX0RFTEVURSkge1xuICAgICAgICBwb3N0X2RlbCA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwb3N0X2lucyA9IHRydWU7XG4gICAgICB9XG4gICAgICAvKlxuICAgICAgICogRml2ZSB0eXBlcyB0byBiZSBzcGxpdDpcbiAgICAgICAqIDxpbnM+QTwvaW5zPjxkZWw+QjwvZGVsPlhZPGlucz5DPC9pbnM+PGRlbD5EPC9kZWw+XG4gICAgICAgKiA8aW5zPkE8L2lucz5YPGlucz5DPC9pbnM+PGRlbD5EPC9kZWw+XG4gICAgICAgKiA8aW5zPkE8L2lucz48ZGVsPkI8L2RlbD5YPGlucz5DPC9pbnM+XG4gICAgICAgKiA8aW5zPkE8L2RlbD5YPGlucz5DPC9pbnM+PGRlbD5EPC9kZWw+XG4gICAgICAgKiA8aW5zPkE8L2lucz48ZGVsPkI8L2RlbD5YPGRlbD5DPC9kZWw+XG4gICAgICAgKi9cbiAgICAgIGlmIChsYXN0ZXF1YWxpdHkgJiYgKChwcmVfaW5zICYmIHByZV9kZWwgJiYgcG9zdF9pbnMgJiYgcG9zdF9kZWwpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAoKGxhc3RlcXVhbGl0eS5sZW5ndGggPCB0aGlzLkVkaXRDb3N0IC8gMikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAocHJlX2lucyArIHByZV9kZWwgKyBwb3N0X2lucyArIHBvc3RfZGVsKSA9PSAzKSkpIHtcbiAgICAgICAgLy8gRHVwbGljYXRlIHJlY29yZC5cbiAgICAgICAgZGlmZnMuc3BsaWNlKGVxdWFsaXRpZXNbZXF1YWxpdGllc0xlbmd0aCAtIDFdLCAwLFxuICAgICAgICAgICAgICAgICAgICAgW0RJRkZfREVMRVRFLCBsYXN0ZXF1YWxpdHldKTtcbiAgICAgICAgLy8gQ2hhbmdlIHNlY29uZCBjb3B5IHRvIGluc2VydC5cbiAgICAgICAgZGlmZnNbZXF1YWxpdGllc1tlcXVhbGl0aWVzTGVuZ3RoIC0gMV0gKyAxXVswXSA9IERJRkZfSU5TRVJUO1xuICAgICAgICBlcXVhbGl0aWVzTGVuZ3RoLS07ICAvLyBUaHJvdyBhd2F5IHRoZSBlcXVhbGl0eSB3ZSBqdXN0IGRlbGV0ZWQ7XG4gICAgICAgIGxhc3RlcXVhbGl0eSA9IG51bGw7XG4gICAgICAgIGlmIChwcmVfaW5zICYmIHByZV9kZWwpIHtcbiAgICAgICAgICAvLyBObyBjaGFuZ2VzIG1hZGUgd2hpY2ggY291bGQgYWZmZWN0IHByZXZpb3VzIGVudHJ5LCBrZWVwIGdvaW5nLlxuICAgICAgICAgIHBvc3RfaW5zID0gcG9zdF9kZWwgPSB0cnVlO1xuICAgICAgICAgIGVxdWFsaXRpZXNMZW5ndGggPSAwO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGVxdWFsaXRpZXNMZW5ndGgtLTsgIC8vIFRocm93IGF3YXkgdGhlIHByZXZpb3VzIGVxdWFsaXR5LlxuICAgICAgICAgIHBvaW50ZXIgPSBlcXVhbGl0aWVzTGVuZ3RoID4gMCA/XG4gICAgICAgICAgICAgIGVxdWFsaXRpZXNbZXF1YWxpdGllc0xlbmd0aCAtIDFdIDogLTE7XG4gICAgICAgICAgcG9zdF9pbnMgPSBwb3N0X2RlbCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNoYW5nZXMgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBwb2ludGVyKys7XG4gIH1cblxuICBpZiAoY2hhbmdlcykge1xuICAgIHRoaXMuY2xlYW51cE1lcmdlKGRpZmZzKTtcbiAgfVxufTtcblxuXG4vKipcbiAqIFJlb3JkZXIgYW5kIG1lcmdlIGxpa2UgZWRpdCBzZWN0aW9ucy4gIE1lcmdlIGVxdWFsaXRpZXMuXG4gKiBBbnkgZWRpdCBzZWN0aW9uIGNhbiBtb3ZlIGFzIGxvbmcgYXMgaXQgZG9lc24ndCBjcm9zcyBhbiBlcXVhbGl0eS5cbiAqIEBwYXJhbSB7IUFycmF5LjwhZGlmZi5EaWZmPn0gZGlmZnMgQXJyYXkgb2YgZGlmZiB0dXBsZXMuXG4gKi9cbmRpZmYucHJvdG90eXBlLmNsZWFudXBNZXJnZSA9IGZ1bmN0aW9uKGRpZmZzKSB7XG4gIGRpZmZzLnB1c2goW0RJRkZfRVFVQUwsICcnXSk7ICAvLyBBZGQgYSBkdW1teSBlbnRyeSBhdCB0aGUgZW5kLlxuICB2YXIgcG9pbnRlciA9IDA7XG4gIHZhciBjb3VudF9kZWxldGUgPSAwO1xuICB2YXIgY291bnRfaW5zZXJ0ID0gMDtcbiAgdmFyIHRleHRfZGVsZXRlID0gJyc7XG4gIHZhciB0ZXh0X2luc2VydCA9ICcnO1xuICB2YXIgY29tbW9ubGVuZ3RoO1xuICB3aGlsZSAocG9pbnRlciA8IGRpZmZzLmxlbmd0aCkge1xuICAgIHN3aXRjaCAoZGlmZnNbcG9pbnRlcl1bMF0pIHtcbiAgICAgIGNhc2UgRElGRl9JTlNFUlQ6XG4gICAgICAgIGNvdW50X2luc2VydCsrO1xuICAgICAgICB0ZXh0X2luc2VydCArPSBkaWZmc1twb2ludGVyXVsxXTtcbiAgICAgICAgcG9pbnRlcisrO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgRElGRl9ERUxFVEU6XG4gICAgICAgIGNvdW50X2RlbGV0ZSsrO1xuICAgICAgICB0ZXh0X2RlbGV0ZSArPSBkaWZmc1twb2ludGVyXVsxXTtcbiAgICAgICAgcG9pbnRlcisrO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgRElGRl9FUVVBTDpcbiAgICAgICAgLy8gVXBvbiByZWFjaGluZyBhbiBlcXVhbGl0eSwgY2hlY2sgZm9yIHByaW9yIHJlZHVuZGFuY2llcy5cbiAgICAgICAgaWYgKGNvdW50X2RlbGV0ZSArIGNvdW50X2luc2VydCA+IDEpIHtcbiAgICAgICAgICBpZiAoY291bnRfZGVsZXRlICE9PSAwICYmIGNvdW50X2luc2VydCAhPT0gMCkge1xuICAgICAgICAgICAgLy8gRmFjdG9yIG91dCBhbnkgY29tbW9uIHByZWZpeGllcy5cbiAgICAgICAgICAgIGNvbW1vbmxlbmd0aCA9IHRoaXMuY29tbW9uUHJlZml4KHRleHRfaW5zZXJ0LCB0ZXh0X2RlbGV0ZSk7XG4gICAgICAgICAgICBpZiAoY29tbW9ubGVuZ3RoICE9PSAwKSB7XG4gICAgICAgICAgICAgIGlmICgocG9pbnRlciAtIGNvdW50X2RlbGV0ZSAtIGNvdW50X2luc2VydCkgPiAwICYmXG4gICAgICAgICAgICAgICAgICBkaWZmc1twb2ludGVyIC0gY291bnRfZGVsZXRlIC0gY291bnRfaW5zZXJ0IC0gMV1bMF0gPT1cbiAgICAgICAgICAgICAgICAgIERJRkZfRVFVQUwpIHtcbiAgICAgICAgICAgICAgICBkaWZmc1twb2ludGVyIC0gY291bnRfZGVsZXRlIC0gY291bnRfaW5zZXJ0IC0gMV1bMV0gKz1cbiAgICAgICAgICAgICAgICAgICAgdGV4dF9pbnNlcnQuc3Vic3RyaW5nKDAsIGNvbW1vbmxlbmd0aCk7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZGlmZnMuc3BsaWNlKDAsIDAsIFtESUZGX0VRVUFMLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dF9pbnNlcnQuc3Vic3RyaW5nKDAsIGNvbW1vbmxlbmd0aCldKTtcbiAgICAgICAgICAgICAgICBwb2ludGVyKys7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgdGV4dF9pbnNlcnQgPSB0ZXh0X2luc2VydC5zdWJzdHJpbmcoY29tbW9ubGVuZ3RoKTtcbiAgICAgICAgICAgICAgdGV4dF9kZWxldGUgPSB0ZXh0X2RlbGV0ZS5zdWJzdHJpbmcoY29tbW9ubGVuZ3RoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIEZhY3RvciBvdXQgYW55IGNvbW1vbiBzdWZmaXhpZXMuXG4gICAgICAgICAgICBjb21tb25sZW5ndGggPSB0aGlzLmNvbW1vblN1ZmZpeCh0ZXh0X2luc2VydCwgdGV4dF9kZWxldGUpO1xuICAgICAgICAgICAgaWYgKGNvbW1vbmxlbmd0aCAhPT0gMCkge1xuICAgICAgICAgICAgICBkaWZmc1twb2ludGVyXVsxXSA9IHRleHRfaW5zZXJ0LnN1YnN0cmluZyh0ZXh0X2luc2VydC5sZW5ndGggLVxuICAgICAgICAgICAgICAgICAgY29tbW9ubGVuZ3RoKSArIGRpZmZzW3BvaW50ZXJdWzFdO1xuICAgICAgICAgICAgICB0ZXh0X2luc2VydCA9IHRleHRfaW5zZXJ0LnN1YnN0cmluZygwLCB0ZXh0X2luc2VydC5sZW5ndGggLVxuICAgICAgICAgICAgICAgICAgY29tbW9ubGVuZ3RoKTtcbiAgICAgICAgICAgICAgdGV4dF9kZWxldGUgPSB0ZXh0X2RlbGV0ZS5zdWJzdHJpbmcoMCwgdGV4dF9kZWxldGUubGVuZ3RoIC1cbiAgICAgICAgICAgICAgICAgIGNvbW1vbmxlbmd0aCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIC8vIERlbGV0ZSB0aGUgb2ZmZW5kaW5nIHJlY29yZHMgYW5kIGFkZCB0aGUgbWVyZ2VkIG9uZXMuXG4gICAgICAgICAgaWYgKGNvdW50X2RlbGV0ZSA9PT0gMCkge1xuICAgICAgICAgICAgZGlmZnMuc3BsaWNlKHBvaW50ZXIgLSBjb3VudF9pbnNlcnQsXG4gICAgICAgICAgICAgICAgY291bnRfZGVsZXRlICsgY291bnRfaW5zZXJ0LCBbRElGRl9JTlNFUlQsIHRleHRfaW5zZXJ0XSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChjb3VudF9pbnNlcnQgPT09IDApIHtcbiAgICAgICAgICAgIGRpZmZzLnNwbGljZShwb2ludGVyIC0gY291bnRfZGVsZXRlLFxuICAgICAgICAgICAgICAgIGNvdW50X2RlbGV0ZSArIGNvdW50X2luc2VydCwgW0RJRkZfREVMRVRFLCB0ZXh0X2RlbGV0ZV0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkaWZmcy5zcGxpY2UocG9pbnRlciAtIGNvdW50X2RlbGV0ZSAtIGNvdW50X2luc2VydCxcbiAgICAgICAgICAgICAgICBjb3VudF9kZWxldGUgKyBjb3VudF9pbnNlcnQsIFtESUZGX0RFTEVURSwgdGV4dF9kZWxldGVdLFxuICAgICAgICAgICAgICAgIFtESUZGX0lOU0VSVCwgdGV4dF9pbnNlcnRdKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcG9pbnRlciA9IHBvaW50ZXIgLSBjb3VudF9kZWxldGUgLSBjb3VudF9pbnNlcnQgK1xuICAgICAgICAgICAgICAgICAgICAoY291bnRfZGVsZXRlID8gMSA6IDApICsgKGNvdW50X2luc2VydCA/IDEgOiAwKSArIDE7XG4gICAgICAgIH0gZWxzZSBpZiAocG9pbnRlciAhPT0gMCAmJiBkaWZmc1twb2ludGVyIC0gMV1bMF0gPT0gRElGRl9FUVVBTCkge1xuICAgICAgICAgIC8vIE1lcmdlIHRoaXMgZXF1YWxpdHkgd2l0aCB0aGUgcHJldmlvdXMgb25lLlxuICAgICAgICAgIGRpZmZzW3BvaW50ZXIgLSAxXVsxXSArPSBkaWZmc1twb2ludGVyXVsxXTtcbiAgICAgICAgICBkaWZmcy5zcGxpY2UocG9pbnRlciwgMSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcG9pbnRlcisrO1xuICAgICAgICB9XG4gICAgICAgIGNvdW50X2luc2VydCA9IDA7XG4gICAgICAgIGNvdW50X2RlbGV0ZSA9IDA7XG4gICAgICAgIHRleHRfZGVsZXRlID0gJyc7XG4gICAgICAgIHRleHRfaW5zZXJ0ID0gJyc7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICBpZiAoZGlmZnNbZGlmZnMubGVuZ3RoIC0gMV1bMV0gPT09ICcnKSB7XG4gICAgZGlmZnMucG9wKCk7ICAvLyBSZW1vdmUgdGhlIGR1bW15IGVudHJ5IGF0IHRoZSBlbmQuXG4gIH1cblxuICAvLyBTZWNvbmQgcGFzczogbG9vayBmb3Igc2luZ2xlIGVkaXRzIHN1cnJvdW5kZWQgb24gYm90aCBzaWRlcyBieSBlcXVhbGl0aWVzXG4gIC8vIHdoaWNoIGNhbiBiZSBzaGlmdGVkIHNpZGV3YXlzIHRvIGVsaW1pbmF0ZSBhbiBlcXVhbGl0eS5cbiAgLy8gZS5nOiBBPGlucz5CQTwvaW5zPkMgLT4gPGlucz5BQjwvaW5zPkFDXG4gIHZhciBjaGFuZ2VzID0gZmFsc2U7XG4gIHBvaW50ZXIgPSAxO1xuICAvLyBJbnRlbnRpb25hbGx5IGlnbm9yZSB0aGUgZmlyc3QgYW5kIGxhc3QgZWxlbWVudCAoZG9uJ3QgbmVlZCBjaGVja2luZykuXG4gIHdoaWxlIChwb2ludGVyIDwgZGlmZnMubGVuZ3RoIC0gMSkge1xuICAgIGlmIChkaWZmc1twb2ludGVyIC0gMV1bMF0gPT0gRElGRl9FUVVBTCAmJlxuICAgICAgICBkaWZmc1twb2ludGVyICsgMV1bMF0gPT0gRElGRl9FUVVBTCkge1xuICAgICAgLy8gVGhpcyBpcyBhIHNpbmdsZSBlZGl0IHN1cnJvdW5kZWQgYnkgZXF1YWxpdGllcy5cbiAgICAgIGlmIChkaWZmc1twb2ludGVyXVsxXS5zdWJzdHJpbmcoZGlmZnNbcG9pbnRlcl1bMV0ubGVuZ3RoIC1cbiAgICAgICAgICBkaWZmc1twb2ludGVyIC0gMV1bMV0ubGVuZ3RoKSA9PSBkaWZmc1twb2ludGVyIC0gMV1bMV0pIHtcbiAgICAgICAgLy8gU2hpZnQgdGhlIGVkaXQgb3ZlciB0aGUgcHJldmlvdXMgZXF1YWxpdHkuXG4gICAgICAgIGRpZmZzW3BvaW50ZXJdWzFdID0gZGlmZnNbcG9pbnRlciAtIDFdWzFdICtcbiAgICAgICAgICAgIGRpZmZzW3BvaW50ZXJdWzFdLnN1YnN0cmluZygwLCBkaWZmc1twb2ludGVyXVsxXS5sZW5ndGggLVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpZmZzW3BvaW50ZXIgLSAxXVsxXS5sZW5ndGgpO1xuICAgICAgICBkaWZmc1twb2ludGVyICsgMV1bMV0gPSBkaWZmc1twb2ludGVyIC0gMV1bMV0gKyBkaWZmc1twb2ludGVyICsgMV1bMV07XG4gICAgICAgIGRpZmZzLnNwbGljZShwb2ludGVyIC0gMSwgMSk7XG4gICAgICAgIGNoYW5nZXMgPSB0cnVlO1xuICAgICAgfSBlbHNlIGlmIChkaWZmc1twb2ludGVyXVsxXS5zdWJzdHJpbmcoMCwgZGlmZnNbcG9pbnRlciArIDFdWzFdLmxlbmd0aCkgPT1cbiAgICAgICAgICBkaWZmc1twb2ludGVyICsgMV1bMV0pIHtcbiAgICAgICAgLy8gU2hpZnQgdGhlIGVkaXQgb3ZlciB0aGUgbmV4dCBlcXVhbGl0eS5cbiAgICAgICAgZGlmZnNbcG9pbnRlciAtIDFdWzFdICs9IGRpZmZzW3BvaW50ZXIgKyAxXVsxXTtcbiAgICAgICAgZGlmZnNbcG9pbnRlcl1bMV0gPVxuICAgICAgICAgICAgZGlmZnNbcG9pbnRlcl1bMV0uc3Vic3RyaW5nKGRpZmZzW3BvaW50ZXIgKyAxXVsxXS5sZW5ndGgpICtcbiAgICAgICAgICAgIGRpZmZzW3BvaW50ZXIgKyAxXVsxXTtcbiAgICAgICAgZGlmZnMuc3BsaWNlKHBvaW50ZXIgKyAxLCAxKTtcbiAgICAgICAgY2hhbmdlcyA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHBvaW50ZXIrKztcbiAgfVxuICAvLyBJZiBzaGlmdHMgd2VyZSBtYWRlLCB0aGUgZGlmZiBuZWVkcyByZW9yZGVyaW5nIGFuZCBhbm90aGVyIHNoaWZ0IHN3ZWVwLlxuICBpZiAoY2hhbmdlcykge1xuICAgIHRoaXMuY2xlYW51cE1lcmdlKGRpZmZzKTtcbiAgfVxufTtcblxuXG4vKipcbiAqIGxvYyBpcyBhIGxvY2F0aW9uIGluIHRleHQxLCBjb21wdXRlIGFuZCByZXR1cm4gdGhlIGVxdWl2YWxlbnQgbG9jYXRpb24gaW5cbiAqIHRleHQyLlxuICogZS5nLiAnVGhlIGNhdCcgdnMgJ1RoZSBiaWcgY2F0JywgMS0+MSwgNS0+OFxuICogQHBhcmFtIHshQXJyYXkuPCFkaWZmLkRpZmY+fSBkaWZmcyBBcnJheSBvZiBkaWZmIHR1cGxlcy5cbiAqIEBwYXJhbSB7bnVtYmVyfSBsb2MgTG9jYXRpb24gd2l0aGluIHRleHQxLlxuICogQHJldHVybiB7bnVtYmVyfSBMb2NhdGlvbiB3aXRoaW4gdGV4dDIuXG4gKi9cbmRpZmYucHJvdG90eXBlLnhJbmRleCA9IGZ1bmN0aW9uKGRpZmZzLCBsb2MpIHtcbiAgdmFyIGNoYXJzMSA9IDA7XG4gIHZhciBjaGFyczIgPSAwO1xuICB2YXIgbGFzdF9jaGFyczEgPSAwO1xuICB2YXIgbGFzdF9jaGFyczIgPSAwO1xuICB2YXIgeDtcbiAgZm9yICh4ID0gMDsgeCA8IGRpZmZzLmxlbmd0aDsgeCsrKSB7XG4gICAgaWYgKGRpZmZzW3hdWzBdICE9PSBESUZGX0lOU0VSVCkgeyAgLy8gRXF1YWxpdHkgb3IgZGVsZXRpb24uXG4gICAgICBjaGFyczEgKz0gZGlmZnNbeF1bMV0ubGVuZ3RoO1xuICAgIH1cbiAgICBpZiAoZGlmZnNbeF1bMF0gIT09IERJRkZfREVMRVRFKSB7ICAvLyBFcXVhbGl0eSBvciBpbnNlcnRpb24uXG4gICAgICBjaGFyczIgKz0gZGlmZnNbeF1bMV0ubGVuZ3RoO1xuICAgIH1cbiAgICBpZiAoY2hhcnMxID4gbG9jKSB7ICAvLyBPdmVyc2hvdCB0aGUgbG9jYXRpb24uXG4gICAgICBicmVhaztcbiAgICB9XG4gICAgbGFzdF9jaGFyczEgPSBjaGFyczE7XG4gICAgbGFzdF9jaGFyczIgPSBjaGFyczI7XG4gIH1cbiAgLy8gV2FzIHRoZSBsb2NhdGlvbiB3YXMgZGVsZXRlZD9cbiAgaWYgKGRpZmZzLmxlbmd0aCAhPSB4ICYmIGRpZmZzW3hdWzBdID09PSBESUZGX0RFTEVURSkge1xuICAgIHJldHVybiBsYXN0X2NoYXJzMjtcbiAgfVxuICAvLyBBZGQgdGhlIHJlbWFpbmluZyBjaGFyYWN0ZXIgbGVuZ3RoLlxuICByZXR1cm4gbGFzdF9jaGFyczIgKyAobG9jIC0gbGFzdF9jaGFyczEpO1xufTtcblxuXG4vKipcbiAqIENvbnZlcnQgYSBkaWZmIGFycmF5IGludG8gYSBwcmV0dHkgSFRNTCByZXBvcnQuXG4gKiBAcGFyYW0geyFBcnJheS48IWRpZmYuRGlmZj59IGRpZmZzIEFycmF5IG9mIGRpZmYgdHVwbGVzLlxuICogQHJldHVybiB7c3RyaW5nfSBIVE1MIHJlcHJlc2VudGF0aW9uLlxuICovXG5kaWZmLnByb3RvdHlwZS5wcmV0dHlIdG1sID0gZnVuY3Rpb24oZGlmZnMpIHtcbiAgdmFyIGh0bWwgPSBbXTtcbiAgdmFyIHBhdHRlcm5fYW1wID0gLyYvZztcbiAgdmFyIHBhdHRlcm5fbHQgPSAvPC9nO1xuICB2YXIgcGF0dGVybl9ndCA9IC8+L2c7XG4gIHZhciBwYXR0ZXJuX2JyID0gL1xcbi9nO1xuICBmb3IgKHZhciB4ID0gMDsgeCA8IGRpZmZzLmxlbmd0aDsgeCsrKSB7XG4gICAgdmFyIG9wID0gZGlmZnNbeF1bMF07ICAgIC8vIE9wZXJhdGlvbiAoaW5zZXJ0LCBkZWxldGUsIGVxdWFsKVxuICAgIHZhciBkYXRhID0gZGlmZnNbeF1bMV07ICAvLyBUZXh0IG9mIGNoYW5nZS5cbiAgICB2YXIgdGV4dCA9IGRhdGEucmVwbGFjZShwYXR0ZXJuX2FtcCwgJyZhbXA7JykucmVwbGFjZShwYXR0ZXJuX2x0LCAnJmx0OycpXG4gICAgICAgIC5yZXBsYWNlKHBhdHRlcm5fZ3QsICcmZ3Q7JykucmVwbGFjZShwYXR0ZXJuX2JyLCAnPGJyLz4nKTtcbiAgICBzd2l0Y2ggKG9wKSB7XG4gICAgICBjYXNlIERJRkZfSU5TRVJUOlxuICAgICAgICBodG1sW3hdID0gJzxpbnM+JyArIHRleHQgKyAnPC9pbnM+JztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIERJRkZfREVMRVRFOlxuICAgICAgICBodG1sW3hdID0gJzxkZWw+JyArIHRleHQgKyAnPC9kZWw+JztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIERJRkZfRVFVQUw6XG4gICAgICAgIGh0bWxbeF0gPSAnPHNwYW4+JyArIHRleHQgKyAnPC9zcGFuPic7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICByZXR1cm4gaHRtbC5qb2luKCcnKTtcbn07XG5cblxuLyoqXG4gKiBDb21wdXRlIGFuZCByZXR1cm4gdGhlIHNvdXJjZSB0ZXh0IChhbGwgZXF1YWxpdGllcyBhbmQgZGVsZXRpb25zKS5cbiAqIEBwYXJhbSB7IUFycmF5LjwhZGlmZi5EaWZmPn0gZGlmZnMgQXJyYXkgb2YgZGlmZiB0dXBsZXMuXG4gKiBAcmV0dXJuIHtzdHJpbmd9IFNvdXJjZSB0ZXh0LlxuICovXG5kaWZmLnByb3RvdHlwZS50ZXh0MSA9IGZ1bmN0aW9uKGRpZmZzKSB7XG4gIHZhciB0ZXh0ID0gW107XG4gIGZvciAodmFyIHggPSAwOyB4IDwgZGlmZnMubGVuZ3RoOyB4KyspIHtcbiAgICBpZiAoZGlmZnNbeF1bMF0gIT09IERJRkZfSU5TRVJUKSB7XG4gICAgICB0ZXh0W3hdID0gZGlmZnNbeF1bMV07XG4gICAgfVxuICB9XG4gIHJldHVybiB0ZXh0LmpvaW4oJycpO1xufTtcblxuXG4vKipcbiAqIENvbXB1dGUgYW5kIHJldHVybiB0aGUgZGVzdGluYXRpb24gdGV4dCAoYWxsIGVxdWFsaXRpZXMgYW5kIGluc2VydGlvbnMpLlxuICogQHBhcmFtIHshQXJyYXkuPCFkaWZmLkRpZmY+fSBkaWZmcyBBcnJheSBvZiBkaWZmIHR1cGxlcy5cbiAqIEByZXR1cm4ge3N0cmluZ30gRGVzdGluYXRpb24gdGV4dC5cbiAqL1xuZGlmZi5wcm90b3R5cGUudGV4dDIgPSBmdW5jdGlvbihkaWZmcykge1xuICB2YXIgdGV4dCA9IFtdO1xuICBmb3IgKHZhciB4ID0gMDsgeCA8IGRpZmZzLmxlbmd0aDsgeCsrKSB7XG4gICAgaWYgKGRpZmZzW3hdWzBdICE9PSBESUZGX0RFTEVURSkge1xuICAgICAgdGV4dFt4XSA9IGRpZmZzW3hdWzFdO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdGV4dC5qb2luKCcnKTtcbn07XG5cblxuLyoqXG4gKiBDb21wdXRlIHRoZSBMZXZlbnNodGVpbiBkaXN0YW5jZTsgdGhlIG51bWJlciBvZiBpbnNlcnRlZCwgZGVsZXRlZCBvclxuICogc3Vic3RpdHV0ZWQgY2hhcmFjdGVycy5cbiAqIEBwYXJhbSB7IUFycmF5LjwhZGlmZi5EaWZmPn0gZGlmZnMgQXJyYXkgb2YgZGlmZiB0dXBsZXMuXG4gKiBAcmV0dXJuIHtudW1iZXJ9IE51bWJlciBvZiBjaGFuZ2VzLlxuICovXG5kaWZmLnByb3RvdHlwZS5sZXZlbnNodGVpbiA9IGZ1bmN0aW9uKGRpZmZzKSB7XG4gIHZhciBsZXZlbnNodGVpbiA9IDA7XG4gIHZhciBpbnNlcnRpb25zID0gMDtcbiAgdmFyIGRlbGV0aW9ucyA9IDA7XG4gIGZvciAodmFyIHggPSAwOyB4IDwgZGlmZnMubGVuZ3RoOyB4KyspIHtcbiAgICB2YXIgb3AgPSBkaWZmc1t4XVswXTtcbiAgICB2YXIgZGF0YSA9IGRpZmZzW3hdWzFdO1xuICAgIHN3aXRjaCAob3ApIHtcbiAgICAgIGNhc2UgRElGRl9JTlNFUlQ6XG4gICAgICAgIGluc2VydGlvbnMgKz0gZGF0YS5sZW5ndGg7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBESUZGX0RFTEVURTpcbiAgICAgICAgZGVsZXRpb25zICs9IGRhdGEubGVuZ3RoO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgRElGRl9FUVVBTDpcbiAgICAgICAgLy8gQSBkZWxldGlvbiBhbmQgYW4gaW5zZXJ0aW9uIGlzIG9uZSBzdWJzdGl0dXRpb24uXG4gICAgICAgIGxldmVuc2h0ZWluICs9IE1hdGgubWF4KGluc2VydGlvbnMsIGRlbGV0aW9ucyk7XG4gICAgICAgIGluc2VydGlvbnMgPSAwO1xuICAgICAgICBkZWxldGlvbnMgPSAwO1xuICAgICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgbGV2ZW5zaHRlaW4gKz0gTWF0aC5tYXgoaW5zZXJ0aW9ucywgZGVsZXRpb25zKTtcbiAgcmV0dXJuIGxldmVuc2h0ZWluO1xufTtcblxuXG4vKipcbiAqIENydXNoIHRoZSBkaWZmIGludG8gYW4gZW5jb2RlZCBzdHJpbmcgd2hpY2ggZGVzY3JpYmVzIHRoZSBvcGVyYXRpb25zXG4gKiByZXF1aXJlZCB0byB0cmFuc2Zvcm0gdGV4dDEgaW50byB0ZXh0Mi5cbiAqIEUuZy4gPTNcXHQtMlxcdCtpbmcgIC0+IEtlZXAgMyBjaGFycywgZGVsZXRlIDIgY2hhcnMsIGluc2VydCAnaW5nJy5cbiAqIE9wZXJhdGlvbnMgYXJlIHRhYi1zZXBhcmF0ZWQuICBJbnNlcnRlZCB0ZXh0IGlzIGVzY2FwZWQgdXNpbmcgJXh4IG5vdGF0aW9uLlxuICogQHBhcmFtIHshQXJyYXkuPCFkaWZmLkRpZmY+fSBkaWZmcyBBcnJheSBvZiBkaWZmIHR1cGxlcy5cbiAqIEByZXR1cm4ge3N0cmluZ30gRGVsdGEgdGV4dC5cbiAqL1xuZGlmZi5wcm90b3R5cGUudG9EZWx0YSA9IGZ1bmN0aW9uKGRpZmZzKSB7XG4gIHZhciB0ZXh0ID0gW107XG4gIGZvciAodmFyIHggPSAwOyB4IDwgZGlmZnMubGVuZ3RoOyB4KyspIHtcbiAgICBzd2l0Y2ggKGRpZmZzW3hdWzBdKSB7XG4gICAgICBjYXNlIERJRkZfSU5TRVJUOlxuICAgICAgICB0ZXh0W3hdID0gJysnICsgZW5jb2RlVVJJKGRpZmZzW3hdWzFdKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIERJRkZfREVMRVRFOlxuICAgICAgICB0ZXh0W3hdID0gJy0nICsgZGlmZnNbeF1bMV0ubGVuZ3RoO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgRElGRl9FUVVBTDpcbiAgICAgICAgdGV4dFt4XSA9ICc9JyArIGRpZmZzW3hdWzFdLmxlbmd0aDtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIHJldHVybiB0ZXh0LmpvaW4oJ1xcdCcpLnJlcGxhY2UoLyUyMC9nLCAnICcpO1xufTtcblxuXG4vKipcbiAqIEdpdmVuIHRoZSBvcmlnaW5hbCB0ZXh0MSwgYW5kIGFuIGVuY29kZWQgc3RyaW5nIHdoaWNoIGRlc2NyaWJlcyB0aGVcbiAqIG9wZXJhdGlvbnMgcmVxdWlyZWQgdG8gdHJhbnNmb3JtIHRleHQxIGludG8gdGV4dDIsIGNvbXB1dGUgdGhlIGZ1bGwgZGlmZi5cbiAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0MSBTb3VyY2Ugc3RyaW5nIGZvciB0aGUgZGlmZi5cbiAqIEBwYXJhbSB7c3RyaW5nfSBkZWx0YSBEZWx0YSB0ZXh0LlxuICogQHJldHVybiB7IUFycmF5LjwhZGlmZi5EaWZmPn0gQXJyYXkgb2YgZGlmZiB0dXBsZXMuXG4gKiBAdGhyb3dzIHshRXJyb3J9IElmIGludmFsaWQgaW5wdXQuXG4gKi9cbmRpZmYucHJvdG90eXBlLmZyb21EZWx0YSA9IGZ1bmN0aW9uKHRleHQxLCBkZWx0YSkge1xuICB2YXIgZGlmZnMgPSBbXTtcbiAgdmFyIGRpZmZzTGVuZ3RoID0gMDsgIC8vIEtlZXBpbmcgb3VyIG93biBsZW5ndGggdmFyIGlzIGZhc3RlciBpbiBKUy5cbiAgdmFyIHBvaW50ZXIgPSAwOyAgLy8gQ3Vyc29yIGluIHRleHQxXG4gIHZhciB0b2tlbnMgPSBkZWx0YS5zcGxpdCgvXFx0L2cpO1xuICBmb3IgKHZhciB4ID0gMDsgeCA8IHRva2Vucy5sZW5ndGg7IHgrKykge1xuICAgIC8vIEVhY2ggdG9rZW4gYmVnaW5zIHdpdGggYSBvbmUgY2hhcmFjdGVyIHBhcmFtZXRlciB3aGljaCBzcGVjaWZpZXMgdGhlXG4gICAgLy8gb3BlcmF0aW9uIG9mIHRoaXMgdG9rZW4gKGRlbGV0ZSwgaW5zZXJ0LCBlcXVhbGl0eSkuXG4gICAgdmFyIHBhcmFtID0gdG9rZW5zW3hdLnN1YnN0cmluZygxKTtcbiAgICBzd2l0Y2ggKHRva2Vuc1t4XS5jaGFyQXQoMCkpIHtcbiAgICAgIGNhc2UgJysnOlxuICAgICAgICB0cnkge1xuICAgICAgICAgIGRpZmZzW2RpZmZzTGVuZ3RoKytdID0gW0RJRkZfSU5TRVJULCBkZWNvZGVVUkkocGFyYW0pXTtcbiAgICAgICAgfSBjYXRjaCAoZXgpIHtcbiAgICAgICAgICAvLyBNYWxmb3JtZWQgVVJJIHNlcXVlbmNlLlxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSWxsZWdhbCBlc2NhcGUgaW4gZGlmZl9mcm9tRGVsdGE6ICcgKyBwYXJhbSk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICctJzpcbiAgICAgICAgLy8gRmFsbCB0aHJvdWdoLlxuICAgICAgY2FzZSAnPSc6XG4gICAgICAgIHZhciBuID0gcGFyc2VJbnQocGFyYW0sIDEwKTtcbiAgICAgICAgaWYgKGlzTmFOKG4pIHx8IG4gPCAwKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIG51bWJlciBpbiBkaWZmX2Zyb21EZWx0YTogJyArIHBhcmFtKTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgdGV4dCA9IHRleHQxLnN1YnN0cmluZyhwb2ludGVyLCBwb2ludGVyICs9IG4pO1xuICAgICAgICBpZiAodG9rZW5zW3hdLmNoYXJBdCgwKSA9PSAnPScpIHtcbiAgICAgICAgICBkaWZmc1tkaWZmc0xlbmd0aCsrXSA9IFtESUZGX0VRVUFMLCB0ZXh0XTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBkaWZmc1tkaWZmc0xlbmd0aCsrXSA9IFtESUZGX0RFTEVURSwgdGV4dF07XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICAvLyBCbGFuayB0b2tlbnMgYXJlIG9rIChmcm9tIGEgdHJhaWxpbmcgXFx0KS5cbiAgICAgICAgLy8gQW55dGhpbmcgZWxzZSBpcyBhbiBlcnJvci5cbiAgICAgICAgaWYgKHRva2Vuc1t4XSkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBkaWZmIG9wZXJhdGlvbiBpbiBkaWZmX2Zyb21EZWx0YTogJyArXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRva2Vuc1t4XSk7XG4gICAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKHBvaW50ZXIgIT0gdGV4dDEubGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdEZWx0YSBsZW5ndGggKCcgKyBwb2ludGVyICtcbiAgICAgICAgJykgZG9lcyBub3QgZXF1YWwgc291cmNlIHRleHQgbGVuZ3RoICgnICsgdGV4dDEubGVuZ3RoICsgJykuJyk7XG4gIH1cbiAgcmV0dXJuIGRpZmZzO1xufTtcblxuXG4vLyBFeHBvcnQgdGhlc2UgZ2xvYmFsIHZhcmlhYmxlcyBzbyB0aGF0IHRoZXkgc3Vydml2ZSBHb29nbGUncyBKUyBjb21waWxlci5cbi8vIEluIGEgYnJvd3NlciwgJ3RoaXMnIHdpbGwgYmUgJ3dpbmRvdycuXG4vLyBVc2VycyBvZiBub2RlLmpzIHNob3VsZCAncmVxdWlyZScgdGhlIHVuY29tcHJlc3NlZCB2ZXJzaW9uIHNpbmNlIEdvb2dsZSdzXG4vLyBKUyBjb21waWxlciBtYXkgYnJlYWsgdGhlIGZvbGxvd2luZyBleHBvcnRzIGZvciBub24tYnJvd3NlciBlbnZpcm9ubWVudHMuXG50aGlzWydkaWZmJ10gPSBkaWZmO1xudGhpc1snRElGRl9ERUxFVEUnXSA9IERJRkZfREVMRVRFO1xudGhpc1snRElGRl9JTlNFUlQnXSA9IERJRkZfSU5TRVJUO1xudGhpc1snRElGRl9FUVVBTCddID0gRElGRl9FUVVBTDtcblxubW9kdWxlLmV4cG9ydHMgPSBkaWZmO1xuIiwiLyohIHR5cG9ncmFmIHwgwqkgMjAxOSBEZW5pcyBTZWxlem5ldiB8IE1JVCAgTGljZW5zZSB8IGh0dHBzOi8vZ2l0aHViLmNvbS90eXBvZ3JhZi90eXBvZ3JhZiAqL1xuIWZ1bmN0aW9uKGUsdCl7XCJvYmplY3RcIj09dHlwZW9mIGV4cG9ydHMmJlwidW5kZWZpbmVkXCIhPXR5cGVvZiBtb2R1bGU/bW9kdWxlLmV4cG9ydHM9dCgpOlwiZnVuY3Rpb25cIj09dHlwZW9mIGRlZmluZSYmZGVmaW5lLmFtZD9kZWZpbmUodCk6ZS5UeXBvZ3JhZj10KCl9KHRoaXMsZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjtmdW5jdGlvbiByKGUpe3JldHVybihyPVwiZnVuY3Rpb25cIj09dHlwZW9mIFN5bWJvbCYmXCJzeW1ib2xcIj09dHlwZW9mIFN5bWJvbC5pdGVyYXRvcj9mdW5jdGlvbihlKXtyZXR1cm4gdHlwZW9mIGV9OmZ1bmN0aW9uKGUpe3JldHVybiBlJiZcImZ1bmN0aW9uXCI9PXR5cGVvZiBTeW1ib2wmJmUuY29uc3RydWN0b3I9PT1TeW1ib2wmJmUhPT1TeW1ib2wucHJvdG90eXBlP1wic3ltYm9sXCI6dHlwZW9mIGV9KShlKX1mdW5jdGlvbiBhKGUsdCl7aWYoIShlIGluc3RhbmNlb2YgdCkpdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKX1mdW5jdGlvbiBuKGUsdCl7Zm9yKHZhciBhPTA7YTx0Lmxlbmd0aDthKyspe3ZhciBuPXRbYV07bi5lbnVtZXJhYmxlPW4uZW51bWVyYWJsZXx8ITEsbi5jb25maWd1cmFibGU9ITAsXCJ2YWx1ZVwiaW4gbiYmKG4ud3JpdGFibGU9ITApLE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLG4ua2V5LG4pfX1mdW5jdGlvbiB0KGUsdCxhKXtyZXR1cm4gdCYmbihlLnByb3RvdHlwZSx0KSxhJiZuKGUsYSksZX1mdW5jdGlvbiBpKGUsdCl7cmV0dXJuIGZ1bmN0aW9uKGUpe2lmKEFycmF5LmlzQXJyYXkoZSkpcmV0dXJuIGV9KGUpfHxmdW5jdGlvbihlLHQpe3ZhciBhPVtdLG49ITAscj0hMSxzPXZvaWQgMDt0cnl7Zm9yKHZhciBpLHU9ZVtTeW1ib2wuaXRlcmF0b3JdKCk7IShuPShpPXUubmV4dCgpKS5kb25lKSYmKGEucHVzaChpLnZhbHVlKSwhdHx8YS5sZW5ndGghPT10KTtuPSEwKTt9Y2F0Y2goZSl7cj0hMCxzPWV9ZmluYWxseXt0cnl7bnx8bnVsbD09dS5yZXR1cm58fHUucmV0dXJuKCl9ZmluYWxseXtpZihyKXRocm93IHN9fXJldHVybiBhfShlLHQpfHxmdW5jdGlvbigpe3Rocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gZGVzdHJ1Y3R1cmUgbm9uLWl0ZXJhYmxlIGluc3RhbmNlXCIpfSgpfXZhciBzPVtcImFcIixcImFiYnJcIixcImFjcm9ueW1cIixcImJcIixcImJkb1wiLFwiYmlnXCIsXCJiclwiLFwiYnV0dG9uXCIsXCJjaXRlXCIsXCJjb2RlXCIsXCJkZm5cIixcImVtXCIsXCJpXCIsXCJpbWdcIixcImlucHV0XCIsXCJrYmRcIixcImxhYmVsXCIsXCJtYXBcIixcIm9iamVjdFwiLFwicVwiLFwic2FtcFwiLFwic2NyaXB0XCIsXCJzZWxlY3RcIixcInNtYWxsXCIsXCJzcGFuXCIsXCJzdHJvbmdcIixcInN1YlwiLFwic3VwXCIsXCJ0ZXh0YXJlYVwiLFwidGltZVwiLFwidHRcIixcInZhclwiXSx1PVtbXCJpZXhjbFwiLDE2MV0sW1wiY2VudFwiLDE2Ml0sW1wicG91bmRcIiwxNjNdLFtcImN1cnJlblwiLDE2NF0sW1wieWVuXCIsMTY1XSxbXCJicnZiYXJcIiwxNjZdLFtcInNlY3RcIiwxNjddLFtcInVtbFwiLDE2OF0sW1wiY29weVwiLDE2OV0sW1wib3JkZlwiLDE3MF0sW1wibGFxdW9cIiwxNzFdLFtcIm5vdFwiLDE3Ml0sW1wicmVnXCIsMTc0XSxbXCJtYWNyXCIsMTc1XSxbXCJkZWdcIiwxNzZdLFtcInBsdXNtblwiLDE3N10sW1wic3VwMlwiLDE3OF0sW1wic3VwM1wiLDE3OV0sW1wiYWN1dGVcIiwxODBdLFtcIm1pY3JvXCIsMTgxXSxbXCJwYXJhXCIsMTgyXSxbXCJtaWRkb3RcIiwxODNdLFtcImNlZGlsXCIsMTg0XSxbXCJzdXAxXCIsMTg1XSxbXCJvcmRtXCIsMTg2XSxbXCJyYXF1b1wiLDE4N10sW1wiZnJhYzE0XCIsMTg4XSxbXCJmcmFjMTJcIiwxODldLFtcImZyYWMzNFwiLDE5MF0sW1wiaXF1ZXN0XCIsMTkxXSxbXCJBZ3JhdmVcIiwxOTJdLFtcIkFhY3V0ZVwiLDE5M10sW1wiQWNpcmNcIiwxOTRdLFtcIkF0aWxkZVwiLDE5NV0sW1wiQXVtbFwiLDE5Nl0sW1wiQXJpbmdcIiwxOTddLFtcIkFFbGlnXCIsMTk4XSxbXCJDY2VkaWxcIiwxOTldLFtcIkVncmF2ZVwiLDIwMF0sW1wiRWFjdXRlXCIsMjAxXSxbXCJFY2lyY1wiLDIwMl0sW1wiRXVtbFwiLDIwM10sW1wiSWdyYXZlXCIsMjA0XSxbXCJJYWN1dGVcIiwyMDVdLFtcIkljaXJjXCIsMjA2XSxbXCJJdW1sXCIsMjA3XSxbXCJFVEhcIiwyMDhdLFtcIk50aWxkZVwiLDIwOV0sW1wiT2dyYXZlXCIsMjEwXSxbXCJPYWN1dGVcIiwyMTFdLFtcIk9jaXJjXCIsMjEyXSxbXCJPdGlsZGVcIiwyMTNdLFtcIk91bWxcIiwyMTRdLFtcInRpbWVzXCIsMjE1XSxbXCJPc2xhc2hcIiwyMTZdLFtcIlVncmF2ZVwiLDIxN10sW1wiVWFjdXRlXCIsMjE4XSxbXCJVY2lyY1wiLDIxOV0sW1wiVXVtbFwiLDIyMF0sW1wiWWFjdXRlXCIsMjIxXSxbXCJUSE9STlwiLDIyMl0sW1wic3psaWdcIiwyMjNdLFtcImFncmF2ZVwiLDIyNF0sW1wiYWFjdXRlXCIsMjI1XSxbXCJhY2lyY1wiLDIyNl0sW1wiYXRpbGRlXCIsMjI3XSxbXCJhdW1sXCIsMjI4XSxbXCJhcmluZ1wiLDIyOV0sW1wiYWVsaWdcIiwyMzBdLFtcImNjZWRpbFwiLDIzMV0sW1wiZWdyYXZlXCIsMjMyXSxbXCJlYWN1dGVcIiwyMzNdLFtcImVjaXJjXCIsMjM0XSxbXCJldW1sXCIsMjM1XSxbXCJpZ3JhdmVcIiwyMzZdLFtcImlhY3V0ZVwiLDIzN10sW1wiaWNpcmNcIiwyMzhdLFtcIml1bWxcIiwyMzldLFtcImV0aFwiLDI0MF0sW1wibnRpbGRlXCIsMjQxXSxbXCJvZ3JhdmVcIiwyNDJdLFtcIm9hY3V0ZVwiLDI0M10sW1wib2NpcmNcIiwyNDRdLFtcIm90aWxkZVwiLDI0NV0sW1wib3VtbFwiLDI0Nl0sW1wiZGl2aWRlXCIsMjQ3XSxbXCJvc2xhc2hcIiwyNDhdLFtcInVncmF2ZVwiLDI0OV0sW1widWFjdXRlXCIsMjUwXSxbXCJ1Y2lyY1wiLDI1MV0sW1widXVtbFwiLDI1Ml0sW1wieWFjdXRlXCIsMjUzXSxbXCJ0aG9yblwiLDI1NF0sW1wieXVtbFwiLDI1NV0sW1wiZm5vZlwiLDQwMl0sW1wiQWxwaGFcIiw5MTNdLFtcIkJldGFcIiw5MTRdLFtcIkdhbW1hXCIsOTE1XSxbXCJEZWx0YVwiLDkxNl0sW1wiRXBzaWxvblwiLDkxN10sW1wiWmV0YVwiLDkxOF0sW1wiRXRhXCIsOTE5XSxbXCJUaGV0YVwiLDkyMF0sW1wiSW90YVwiLDkyMV0sW1wiS2FwcGFcIiw5MjJdLFtcIkxhbWJkYVwiLDkyM10sW1wiTXVcIiw5MjRdLFtcIk51XCIsOTI1XSxbXCJYaVwiLDkyNl0sW1wiT21pY3JvblwiLDkyN10sW1wiUGlcIiw5MjhdLFtcIlJob1wiLDkyOV0sW1wiU2lnbWFcIiw5MzFdLFtcIlRhdVwiLDkzMl0sW1wiVXBzaWxvblwiLDkzM10sW1wiUGhpXCIsOTM0XSxbXCJDaGlcIiw5MzVdLFtcIlBzaVwiLDkzNl0sW1wiT21lZ2FcIiw5MzddLFtcImFscGhhXCIsOTQ1XSxbXCJiZXRhXCIsOTQ2XSxbXCJnYW1tYVwiLDk0N10sW1wiZGVsdGFcIiw5NDhdLFtcImVwc2lsb25cIiw5NDldLFtcInpldGFcIiw5NTBdLFtcImV0YVwiLDk1MV0sW1widGhldGFcIiw5NTJdLFtcImlvdGFcIiw5NTNdLFtcImthcHBhXCIsOTU0XSxbXCJsYW1iZGFcIiw5NTVdLFtcIm11XCIsOTU2XSxbXCJudVwiLDk1N10sW1wieGlcIiw5NThdLFtcIm9taWNyb25cIiw5NTldLFtcInBpXCIsOTYwXSxbXCJyaG9cIiw5NjFdLFtcInNpZ21hZlwiLDk2Ml0sW1wic2lnbWFcIiw5NjNdLFtcInRhdVwiLDk2NF0sW1widXBzaWxvblwiLDk2NV0sW1wicGhpXCIsOTY2XSxbXCJjaGlcIiw5NjddLFtcInBzaVwiLDk2OF0sW1wib21lZ2FcIiw5NjldLFtcInRoZXRhc3ltXCIsOTc3XSxbXCJ1cHNpaFwiLDk3OF0sW1wicGl2XCIsOTgyXSxbXCJidWxsXCIsODIyNl0sW1wiaGVsbGlwXCIsODIzMF0sW1wicHJpbWVcIiw4MjQyXSxbXCJQcmltZVwiLDgyNDNdLFtcIm9saW5lXCIsODI1NF0sW1wiZnJhc2xcIiw4MjYwXSxbXCJ3ZWllcnBcIiw4NDcyXSxbXCJpbWFnZVwiLDg0NjVdLFtcInJlYWxcIiw4NDc2XSxbXCJ0cmFkZVwiLDg0ODJdLFtcImFsZWZzeW1cIiw4NTAxXSxbXCJsYXJyXCIsODU5Ml0sW1widWFyclwiLDg1OTNdLFtcInJhcnJcIiw4NTk0XSxbXCJkYXJyXCIsODU5NV0sW1wiaGFyclwiLDg1OTZdLFtcImNyYXJyXCIsODYyOV0sW1wibEFyclwiLDg2NTZdLFtcInVBcnJcIiw4NjU3XSxbXCJyQXJyXCIsODY1OF0sW1wiZEFyclwiLDg2NTldLFtcImhBcnJcIiw4NjYwXSxbXCJmb3JhbGxcIiw4NzA0XSxbXCJwYXJ0XCIsODcwNl0sW1wiZXhpc3RcIiw4NzA3XSxbXCJlbXB0eVwiLDg3MDldLFtcIm5hYmxhXCIsODcxMV0sW1wiaXNpblwiLDg3MTJdLFtcIm5vdGluXCIsODcxM10sW1wibmlcIiw4NzE1XSxbXCJwcm9kXCIsODcxOV0sW1wic3VtXCIsODcyMV0sW1wibWludXNcIiw4NzIyXSxbXCJsb3dhc3RcIiw4NzI3XSxbXCJyYWRpY1wiLDg3MzBdLFtcInByb3BcIiw4NzMzXSxbXCJpbmZpblwiLDg3MzRdLFtcImFuZ1wiLDg3MzZdLFtcImFuZFwiLDg3NDNdLFtcIm9yXCIsODc0NF0sW1wiY2FwXCIsODc0NV0sW1wiY3VwXCIsODc0Nl0sW1wiaW50XCIsODc0N10sW1widGhlcmU0XCIsODc1Nl0sW1wic2ltXCIsODc2NF0sW1wiY29uZ1wiLDg3NzNdLFtcImFzeW1wXCIsODc3Nl0sW1wibmVcIiw4ODAwXSxbXCJlcXVpdlwiLDg4MDFdLFtcImxlXCIsODgwNF0sW1wiZ2VcIiw4ODA1XSxbXCJzdWJcIiw4ODM0XSxbXCJzdXBcIiw4ODM1XSxbXCJuc3ViXCIsODgzNl0sW1wic3ViZVwiLDg4MzhdLFtcInN1cGVcIiw4ODM5XSxbXCJvcGx1c1wiLDg4NTNdLFtcIm90aW1lc1wiLDg4NTVdLFtcInBlcnBcIiw4ODY5XSxbXCJzZG90XCIsODkwMV0sW1wibGNlaWxcIiw4OTY4XSxbXCJyY2VpbFwiLDg5NjldLFtcImxmbG9vclwiLDg5NzBdLFtcInJmbG9vclwiLDg5NzFdLFtcImxhbmdcIiw5MDAxXSxbXCJyYW5nXCIsOTAwMl0sW1wic3BhZGVzXCIsOTgyNF0sW1wiY2x1YnNcIiw5ODI3XSxbXCJoZWFydHNcIiw5ODI5XSxbXCJkaWFtc1wiLDk4MzBdLFtcImxvelwiLDk2NzRdLFtcIk9FbGlnXCIsMzM4XSxbXCJvZWxpZ1wiLDMzOV0sW1wiU2Nhcm9uXCIsMzUyXSxbXCJzY2Fyb25cIiwzNTNdLFtcIll1bWxcIiwzNzZdLFtcImNpcmNcIiw3MTBdLFtcInRpbGRlXCIsNzMyXSxbXCJuZGFzaFwiLDgyMTFdLFtcIm1kYXNoXCIsODIxMl0sW1wibHNxdW9cIiw4MjE2XSxbXCJyc3F1b1wiLDgyMTddLFtcInNicXVvXCIsODIxOF0sW1wibGRxdW9cIiw4MjIwXSxbXCJyZHF1b1wiLDgyMjFdLFtcImJkcXVvXCIsODIyMl0sW1wiZGFnZ2VyXCIsODIyNF0sW1wiRGFnZ2VyXCIsODIyNV0sW1wicGVybWlsXCIsODI0MF0sW1wibHNhcXVvXCIsODI0OV0sW1wicnNhcXVvXCIsODI1MF0sW1wiZXVyb1wiLDgzNjRdLFtcIk5lc3RlZEdyZWF0ZXJHcmVhdGVyXCIsODgxMV0sW1wiTmVzdGVkTGVzc0xlc3NcIiw4ODEwXV0sbD1bW1wibmJzcFwiLDE2MF0sW1widGhpbnNwXCIsODIwMV0sW1wiZW5zcFwiLDgxOTRdLFtcImVtc3BcIiw4MTk1XSxbXCJzaHlcIiwxNzNdLFtcInp3bmpcIiw4MjA0XSxbXCJ6d2pcIiw4MjA1XSxbXCJscm1cIiw4MjA2XSxbXCJybG1cIiw4MjA3XV0sZT1uZXcoZnVuY3Rpb24oKXtmdW5jdGlvbiBlKCl7YSh0aGlzLGUpLHRoaXMuX2VudGl0aWVzPXRoaXMuX3ByZXBhcmVFbnRpdGllcyhbXS5jb25jYXQodSxsKSksdGhpcy5fZW50aXRpZXNCeU5hbWU9e30sdGhpcy5fZW50aXRpZXNCeU5hbWVFbnRpdHk9e30sdGhpcy5fZW50aXRpZXNCeURpZ2l0RW50aXR5PXt9LHRoaXMuX2VudGl0aWVzQnlVdGY9e30sdGhpcy5fZW50aXRpZXMuZm9yRWFjaChmdW5jdGlvbihlKXt0aGlzLl9lbnRpdGllc0J5TmFtZVtlLm5hbWVdPWUsdGhpcy5fZW50aXRpZXNCeU5hbWVFbnRpdHlbZS5uYW1lRW50aXR5XT1lLHRoaXMuX2VudGl0aWVzQnlEaWdpdEVudGl0eVtlLmRpZ2l0RW50aXR5XT1lLHRoaXMuX2VudGl0aWVzQnlVdGZbZS51dGZdPWV9LHRoaXMpLHRoaXMuX2ludmlzaWJsZUVudGl0aWVzPXRoaXMuX3ByZXBhcmVFbnRpdGllcyhsKX1yZXR1cm4gdChlLFt7a2V5OlwidG9VdGZcIix2YWx1ZTpmdW5jdGlvbihlKXt2YXIgYT10aGlzOy0xIT09ZS50ZXh0LnNlYXJjaCgvJiMvKSYmKGUudGV4dD10aGlzLmRlY0hleFRvVXRmKGUudGV4dCkpLC0xIT09ZS50ZXh0LnNlYXJjaCgvJlthLXpdL2kpJiYoZS50ZXh0PWUudGV4dC5yZXBsYWNlKC8mW2EtelxcZF17MiwzMX07L2dpLGZ1bmN0aW9uKGUpe3ZhciB0PWEuX2VudGl0aWVzQnlOYW1lRW50aXR5W2VdO3JldHVybiB0P3QudXRmOmV9KSl9fSx7a2V5OlwiZGVjSGV4VG9VdGZcIix2YWx1ZTpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8mIyhcXGR7MSw2fSk7L2dpLGZ1bmN0aW9uKGUsdCl7cmV0dXJuIFN0cmluZy5mcm9tQ2hhckNvZGUocGFyc2VJbnQodCwxMCkpfSkucmVwbGFjZSgvJiN4KFtcXGRhLWZdezEsNn0pOy9naSxmdW5jdGlvbihlLHQpe3JldHVybiBTdHJpbmcuZnJvbUNoYXJDb2RlKHBhcnNlSW50KHQsMTYpKX0pfX0se2tleTpcInJlc3RvcmVcIix2YWx1ZTpmdW5jdGlvbihlKXt2YXIgdD1lLnByZWZzLmh0bWxFbnRpdHksYT10LnR5cGUsbj10aGlzLl9lbnRpdGllcztcIm5hbWVcIiE9PWEmJlwiZGlnaXRcIiE9PWF8fCgodC5vbmx5SW52aXNpYmxlfHx0Lmxpc3QpJiYobj1bXSx0Lm9ubHlJbnZpc2libGUmJihuPW4uY29uY2F0KHRoaXMuX2ludmlzaWJsZUVudGl0aWVzKSksdC5saXN0JiYobj1uLmNvbmNhdCh0aGlzLl9wcmVwYXJlTGlzdFBhcmFtKHQubGlzdCkpKSksZS50ZXh0PXRoaXMuX3Jlc3RvcmVFbnRpdGllc0J5SW5kZXgoZS50ZXh0LGErXCJFbnRpdHlcIixuKSl9fSx7a2V5OlwiZ2V0QnlVdGZcIix2YWx1ZTpmdW5jdGlvbihlLHQpe3ZhciBhPVwiXCI7c3dpdGNoKHQpe2Nhc2VcImRpZ2l0XCI6YT10aGlzLl9lbnRpdGllc0J5RGlnaXRFbnRpdHlbZV07YnJlYWs7Y2FzZVwibmFtZVwiOmE9dGhpcy5fZW50aXRpZXNCeU5hbWVFbnRpdHlbZV07YnJlYWs7ZGVmYXVsdDphPWV9cmV0dXJuIGF9fSx7a2V5OlwiX3ByZXBhcmVFbnRpdGllc1wiLHZhbHVlOmZ1bmN0aW9uKGUpe3ZhciBzPVtdO3JldHVybiBlLmZvckVhY2goZnVuY3Rpb24oZSl7dmFyIHQ9aShlLDIpLGE9dFswXSxuPXRbMV0scj1TdHJpbmcuZnJvbUNoYXJDb2RlKG4pO3MucHVzaCh7bmFtZTphLG5hbWVFbnRpdHk6XCImXCIrYStcIjtcIixkaWdpdEVudGl0eTpcIiYjXCIrbitcIjtcIix1dGY6cixyZU5hbWU6bmV3IFJlZ0V4cChcIiZcIithK1wiO1wiLFwiZ1wiKSxyZVV0ZjpuZXcgUmVnRXhwKHIsXCJnXCIpfSl9LHRoaXMpLHN9fSx7a2V5OlwiX3ByZXBhcmVMaXN0UGFyYW1cIix2YWx1ZTpmdW5jdGlvbihlKXt2YXIgYT1bXTtyZXR1cm4gZS5mb3JFYWNoKGZ1bmN0aW9uKGUpe3ZhciB0PXRoaXMuX2VudGl0aWVzQnlOYW1lW2VdO3QmJmEucHVzaCh0KX0sdGhpcyksYX19LHtrZXk6XCJfcmVzdG9yZUVudGl0aWVzQnlJbmRleFwiLHZhbHVlOmZ1bmN0aW9uKHQsYSxlKXtyZXR1cm4gZS5mb3JFYWNoKGZ1bmN0aW9uKGUpe3Q9dC5yZXBsYWNlKGUucmVVdGYsZVthXSl9KSx0fX1dKSxlfSgpKSxvPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZSgpe2EodGhpcyxlKTt2YXIgdD1bW1wiXFx4M2MhLS1cIixcIi0tXFx4M2VcIl0sW1wiPCFFTlRJVFlcIixcIj5cIl0sW1wiPCFET0NUWVBFXCIsXCI+XCJdLFtcIjxcXFxcP3htbFwiLFwiXFxcXD8+XCJdLFtcIjwhXFxcXFtDREFUQVxcXFxbXCIsXCJcXFxcXVxcXFxdPlwiXV07W1wiY29kZVwiLFwia2JkXCIsXCJvYmplY3RcIixcInByZVwiLFwic2FtcFwiLFwic2NyaXB0XCIsXCJzdHlsZVwiLFwidmFyXCJdLmZvckVhY2goZnVuY3Rpb24oZSl7dC5wdXNoKFtcIjxcIitlK1wiKFxcXFxzW14+XSo/KT8+XCIsXCI8L1wiK2UrXCI+XCJdKX0sdGhpcyksdGhpcy5fdGFncz17b3duOltdLGh0bWw6dC5tYXAodGhpcy5fcHJlcGFyZVJlZ0V4cCksdXJsOltmLl9yZVVybF19LHRoaXMuX2dyb3Vwcz1bXCJvd25cIixcImh0bWxcIixcInVybFwiXX1yZXR1cm4gdChlLFt7a2V5OlwiYWRkXCIsdmFsdWU6ZnVuY3Rpb24oZSl7dGhpcy5fdGFncy5vd24ucHVzaCh0aGlzLl9wcmVwYXJlUmVnRXhwKGUpKX19LHtrZXk6XCJzaG93XCIsdmFsdWU6ZnVuY3Rpb24odCxhKXtmb3IodmFyIGU9Zi5fcHJpdmF0ZUxhYmVsLG49bmV3IFJlZ0V4cChlK1widGZcXFxcZCtcIitlLFwiZ1wiKSxyPW5ldyBSZWdFeHAoZStcInRmXFxcXGRcIikscz1mdW5jdGlvbihlKXtyZXR1cm4gdC5zYWZlVGFncy5oaWRkZW5bYV1bZV18fGV9LGk9MCx1PXRoaXMuX3RhZ3NbYV0ubGVuZ3RoO2k8dSYmKHQudGV4dD10LnRleHQucmVwbGFjZShuLHMpLC0xIT09dC50ZXh0LnNlYXJjaChyKSk7aSsrKTt9fSx7a2V5OlwiaGlkZVwiLHZhbHVlOmZ1bmN0aW9uKHQsZSl7dC5zYWZlVGFncz10LnNhZmVUYWdzfHx7aGlkZGVuOnt9LGk6MH0sdC5zYWZlVGFncy5oaWRkZW5bZV09e307dmFyIGE9dGhpcy5fcGFzdGVMYWJlbC5iaW5kKHRoaXMsdCxlKTt0aGlzLl90YWdzW2VdLmZvckVhY2goZnVuY3Rpb24oZSl7dC50ZXh0PXQudGV4dC5yZXBsYWNlKHRoaXMuX3ByZXBhcmVSZWdFeHAoZSksYSl9LHRoaXMpfX0se2tleTpcImhpZGVIVE1MVGFnc1wiLHZhbHVlOmZ1bmN0aW9uKGUpe2lmKGUuaXNIVE1MKXt2YXIgdD10aGlzLl9wYXN0ZUxhYmVsLmJpbmQodGhpcyxlLFwiaHRtbFwiKTtlLnRleHQ9ZS50ZXh0LnJlcGxhY2UoLzxcXC8/W2Etel1bXl0qPz4vZ2ksdCkucmVwbGFjZSgvJmx0O1xcLz9bYS16XVteXSo/Jmd0Oy9naSx0KS5yZXBsYWNlKC8mW2dsXXQ7L2dpLHQpfX19LHtrZXk6XCJnZXRQcmV2TGFiZWxcIix2YWx1ZTpmdW5jdGlvbihlLHQpe2Zvcih2YXIgYT10LTE7MDw9YTthLS0paWYoZVthXT09PWYuX3ByaXZhdGVMYWJlbClyZXR1cm4gZS5zbGljZShhLHQrMSk7cmV0dXJuITF9fSx7a2V5OlwiZ2V0TmV4dExhYmVsXCIsdmFsdWU6ZnVuY3Rpb24oZSx0KXtmb3IodmFyIGE9dCsxO2E8ZS5sZW5ndGg7YSsrKWlmKGVbYV09PT1mLl9wcml2YXRlTGFiZWwpcmV0dXJuIGUuc2xpY2UodCxhKzEpO3JldHVybiExfX0se2tleTpcImdldFRhZ0J5TGFiZWxcIix2YWx1ZTpmdW5jdGlvbihhLG4pe3ZhciByPSExO3JldHVybiB0aGlzLl9ncm91cHMuc29tZShmdW5jdGlvbihlKXt2YXIgdD1hLnNhZmVUYWdzLmhpZGRlbltlXVtuXTtyZXR1cm4gdm9pZCAwIT09dCYmKHI9e2dyb3VwOmUsdmFsdWU6dH0pLHJ9KSxyfX0se2tleTpcImdldFRhZ0luZm9cIix2YWx1ZTpmdW5jdGlvbihlKXtpZihlKXt2YXIgdD17Z3JvdXA6ZS5ncm91cH07c3dpdGNoKGUuZ3JvdXApe2Nhc2VcImh0bWxcIjp0Lm5hbWU9ZS52YWx1ZS5zcGxpdCgvWzxcXHM+XS8pWzFdLHQuaXNJbmxpbmU9LTE8cy5pbmRleE9mKHQubmFtZSksdC5pc0Nsb3Npbmc9LTE8ZS52YWx1ZS5zZWFyY2goL148XFwvLyk7YnJlYWs7Y2FzZVwidXJsXCI6dC5pc0lubGluZT0hMDticmVhaztjYXNlXCJvd25cIjp0LmlzSW5saW5lPSExfXJldHVybiB0fX19LHtrZXk6XCJfcGFzdGVMYWJlbFwiLHZhbHVlOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1lLnNhZmVUYWdzLHI9Zi5fcHJpdmF0ZUxhYmVsK1widGZcIituLmkrZi5fcHJpdmF0ZUxhYmVsO3JldHVybiBuLmhpZGRlblt0XVtyXT1hLG4uaSsrLHJ9fSx7a2V5OlwiX3ByZXBhcmVSZWdFeHBcIix2YWx1ZTpmdW5jdGlvbihlKXt2YXIgdDtpZihlIGluc3RhbmNlb2YgUmVnRXhwKXQ9ZTtlbHNle3ZhciBhPWkoZSwzKSxuPWFbMF0scj1hWzFdLHM9YVsyXTt2b2lkIDA9PT1zJiYocz1cIlteXSo/XCIpLHQ9bmV3IFJlZ0V4cChuK3MrcixcImdpXCIpfXJldHVybiB0fX1dKSxlfSgpLGY9ZnVuY3Rpb24oKXtmdW5jdGlvbiBsKGUpe2EodGhpcyxsKSx0aGlzLl9wcmVmcz1cIm9iamVjdFwiPT09cihlKT9lOnt9LHRoaXMuX3ByZWZzLmxvY2FsZT1sLl9wcmVwYXJlTG9jYWxlKHRoaXMuX3ByZWZzLmxvY2FsZSksdGhpcy5fcHJlZnMubGl2ZT10aGlzLl9wcmVmcy5saXZlfHwhMSx0aGlzLl9zYWZlVGFncz1uZXcgbyx0aGlzLl9zZXR0aW5ncz17fSx0aGlzLl9lbmFibGVkUnVsZXM9e30sdGhpcy5faW5uZXJSdWxlc0J5UXVldWVzPXt9LHRoaXMuX2lubmVyUnVsZXM9W10uY29uY2F0KHRoaXMuX2lubmVyUnVsZXMpLHRoaXMuX2lubmVyUnVsZXMuZm9yRWFjaChmdW5jdGlvbihlKXt2YXIgdD1lLnF1ZXVlfHxcImRlZmF1bHRcIjt0aGlzLl9pbm5lclJ1bGVzQnlRdWV1ZXNbdF09dGhpcy5faW5uZXJSdWxlc0J5UXVldWVzW3RdfHxbXSx0aGlzLl9pbm5lclJ1bGVzQnlRdWV1ZXNbdF0ucHVzaChlKX0sdGhpcyksdGhpcy5fcnVsZXNCeVF1ZXVlcz17fSx0aGlzLl9ydWxlcz1bXS5jb25jYXQodGhpcy5fcnVsZXMpLHRoaXMuX3J1bGVzLmZvckVhY2goZnVuY3Rpb24oZSl7dmFyIHQ9ZS5xdWV1ZXx8XCJkZWZhdWx0XCI7dGhpcy5fcHJlcGFyZVJ1bGUoZSksdGhpcy5fcnVsZXNCeVF1ZXVlc1t0XT10aGlzLl9ydWxlc0J5UXVldWVzW3RdfHxbXSx0aGlzLl9ydWxlc0J5UXVldWVzW3RdLnB1c2goZSl9LHRoaXMpLHRoaXMuX3ByZWZzLmRpc2FibGVSdWxlJiZ0aGlzLmRpc2FibGVSdWxlKHRoaXMuX3ByZWZzLmRpc2FibGVSdWxlKSx0aGlzLl9wcmVmcy5lbmFibGVSdWxlJiZ0aGlzLmVuYWJsZVJ1bGUodGhpcy5fcHJlZnMuZW5hYmxlUnVsZSksdGhpcy5fc2VwYXJhdGVQYXJ0c1RhZ3M9W1widGl0bGVcIixcInBcIixcImhbMS02XVwiLFwic2VsZWN0XCIsXCJsZWdlbmRcIl19cmV0dXJuIHQobCxbe2tleTpcImV4ZWN1dGVcIix2YWx1ZTpmdW5jdGlvbihlLHQpe2lmKCEoZT1cIlwiK2UpKXJldHVyblwiXCI7dmFyIGE9dGhpcy5fcHJlcGFyZUNvbnRleHQoZSk7cmV0dXJuIHRoaXMuX3ByZXBhcmVQcmVmcyhhLHQpLHRoaXMuX3Byb2Nlc3MoYSl9fSx7a2V5OlwiX3ByZXBhcmVDb250ZXh0XCIsdmFsdWU6ZnVuY3Rpb24oZSl7cmV0dXJue3RleHQ6ZSxpc0hUTUw6dGhpcy5faXNIVE1MKGUpLHByZWZzOmwuZGVlcENvcHkodGhpcy5fcHJlZnMpLGdldERhdGE6ZnVuY3Rpb24odCl7cmV0dXJuXCJjaGFyXCI9PT10P3RoaXMucHJlZnMubG9jYWxlLm1hcChmdW5jdGlvbihlKXtyZXR1cm4gbC5nZXREYXRhKGUrXCIvXCIrdCl9KS5qb2luKFwiXCIpOmwuZ2V0RGF0YSh0aGlzLnByZWZzLmxvY2FsZVswXStcIi9cIit0KX19fX0se2tleTpcIl9wcmVwYXJlUHJlZnNcIix2YWx1ZTpmdW5jdGlvbihlLHQpe3Q9dHx8e307Zm9yKHZhciBhPWUucHJlZnMsbj0wLHI9W1wiaHRtbEVudGl0eVwiLFwibGluZUVuZGluZ1wiLFwicHJvY2Vzc2luZ1NlcGFyYXRlUGFydHNcIixcInJ1bGVGaWx0ZXJcIl07bjxyLmxlbmd0aDtuKyspe3ZhciBzPXJbbl07cyBpbiB0P2Fbc109dFtzXTpzIGluIHRoaXMuX3ByZWZzJiYoYVtzXT10aGlzLl9wcmVmc1tzXSl9YS5odG1sRW50aXR5PWEuaHRtbEVudGl0eXx8e30sYS5sb2NhbGU9bC5fcHJlcGFyZUxvY2FsZSh0LmxvY2FsZSx0aGlzLl9wcmVmcy5sb2NhbGUpO3ZhciBpPWEubG9jYWxlLHU9aVswXTtpZighaS5sZW5ndGh8fCF1KXRocm93IEVycm9yKCdOb3QgZGVmaW5lZCB0aGUgcHJvcGVydHkgXCJsb2NhbGVcIi4nKTtpZighbC5oYXNMb2NhbGUodSkpdGhyb3cgRXJyb3IoJ1wiJyt1KydcIiBpcyBub3Qgc3VwcG9ydGVkIGxvY2FsZS4nKX19LHtrZXk6XCJfaXNIVE1MXCIsdmFsdWU6ZnVuY3Rpb24oZSl7cmV0dXJuLTEhPT1lLnNlYXJjaCgvKDxcXC8/W2Etel18PCF8JltsZ110OykvaSl9fSx7a2V5OlwiX3NwbGl0QnlTZXBhcmF0ZVBhcnRzXCIsdmFsdWU6ZnVuY3Rpb24ocil7aWYoIXIuaXNIVE1MfHwhMT09PXIucHJlZnMucHJvY2Vzc2luZ1NlcGFyYXRlUGFydHMpcmV0dXJuW3IudGV4dF07dmFyIHM9W10saT1sLl9wcml2YXRlU2VwYXJhdGVMYWJlbCxlPW5ldyBSZWdFeHAoXCI8KFwiK3RoaXMuX3NlcGFyYXRlUGFydHNUYWdzLmpvaW4oXCJ8XCIpK1wiKShcXFxcc1tePl0qPyk/PlteXSo/PC9cXFxcMT5cIixcImdpXCIpLHU9MDtyZXR1cm4gci50ZXh0LnJlcGxhY2UoZSxmdW5jdGlvbihlLHQsYSxuKXtyZXR1cm4gdSE9PW4mJnMucHVzaCgodT9pOlwiXCIpK3IudGV4dC5zbGljZSh1LG4pK2kpLHMucHVzaChlKSx1PW4rZS5sZW5ndGgsZX0pLHMucHVzaCh1P2krci50ZXh0LnNsaWNlKHUsci50ZXh0Lmxlbmd0aCk6ci50ZXh0KSxzfX0se2tleTpcIl9wcm9jZXNzXCIsdmFsdWU6ZnVuY3Rpb24odCl7dC50ZXh0PXRoaXMuX3JlbW92ZUNSKHQudGV4dCksdGhpcy5fZXhlY3V0ZVJ1bGVzKHQsXCJzdGFydFwiKSx0aGlzLl9zYWZlVGFncy5oaWRlKHQsXCJvd25cIiksdGhpcy5fZXhlY3V0ZVJ1bGVzKHQsXCJoaWRlLXNhZmUtdGFncy1vd25cIiksdGhpcy5fc2FmZVRhZ3MuaGlkZSh0LFwiaHRtbFwiKSx0aGlzLl9leGVjdXRlUnVsZXModCxcImhpZGUtc2FmZS10YWdzLWh0bWxcIik7dmFyIGU9dC5pc0hUTUwsYT1uZXcgUmVnRXhwKGwuX3ByaXZhdGVTZXBhcmF0ZUxhYmVsLFwiZ1wiKTtyZXR1cm4gdC50ZXh0PXRoaXMuX3NwbGl0QnlTZXBhcmF0ZVBhcnRzKHQpLm1hcChmdW5jdGlvbihlKXtyZXR1cm4gdC50ZXh0PWUsdC5pc0hUTUw9dGhpcy5faXNIVE1MKGUpLHRoaXMuX3NhZmVUYWdzLmhpZGVIVE1MVGFncyh0KSx0aGlzLl9zYWZlVGFncy5oaWRlKHQsXCJ1cmxcIiksdGhpcy5fZXhlY3V0ZVJ1bGVzKHQsXCJoaWRlLXNhZmUtdGFncy11cmxcIiksdGhpcy5fZXhlY3V0ZVJ1bGVzKHQsXCJoaWRlLXNhZmUtdGFnc1wiKSxsLkh0bWxFbnRpdGllcy50b1V0Zih0KSx0aGlzLl9wcmVmcy5saXZlJiYodC50ZXh0PWwuX3JlcGxhY2VOYnNwKHQudGV4dCkpLHRoaXMuX2V4ZWN1dGVSdWxlcyh0LFwidXRmXCIpLHRoaXMuX2V4ZWN1dGVSdWxlcyh0KSxsLkh0bWxFbnRpdGllcy5yZXN0b3JlKHQpLHRoaXMuX2V4ZWN1dGVSdWxlcyh0LFwiaHRtbC1lbnRpdGllc1wiKSx0aGlzLl9zYWZlVGFncy5zaG93KHQsXCJ1cmxcIiksdGhpcy5fZXhlY3V0ZVJ1bGVzKHQsXCJzaG93LXNhZmUtdGFncy11cmxcIiksdC50ZXh0LnJlcGxhY2UoYSxcIlwiKX0sdGhpcykuam9pbihcIlwiKSx0LmlzSFRNTD1lLHRoaXMuX3NhZmVUYWdzLnNob3codCxcImh0bWxcIiksdGhpcy5fZXhlY3V0ZVJ1bGVzKHQsXCJzaG93LXNhZmUtdGFncy1odG1sXCIpLHRoaXMuX3NhZmVUYWdzLnNob3codCxcIm93blwiKSx0aGlzLl9leGVjdXRlUnVsZXModCxcInNob3ctc2FmZS10YWdzLW93blwiKSx0aGlzLl9leGVjdXRlUnVsZXModCxcImVuZFwiKSx0aGlzLl9maXhMaW5lRW5kaW5nKHQudGV4dCx0LnByZWZzLmxpbmVFbmRpbmcpfX0se2tleTpcImdldFNldHRpbmdcIix2YWx1ZTpmdW5jdGlvbihlLHQpe3JldHVybiB0aGlzLl9zZXR0aW5nc1tlXSYmdGhpcy5fc2V0dGluZ3NbZV1bdF19fSx7a2V5Olwic2V0U2V0dGluZ1wiLHZhbHVlOmZ1bmN0aW9uKGUsdCxhKXtyZXR1cm4gdGhpcy5fc2V0dGluZ3NbZV09dGhpcy5fc2V0dGluZ3NbZV18fHt9LHRoaXMuX3NldHRpbmdzW2VdW3RdPWEsdGhpc319LHtrZXk6XCJpc0VuYWJsZWRSdWxlXCIsdmFsdWU6ZnVuY3Rpb24oZSl7cmV0dXJuIHRoaXMuX2VuYWJsZWRSdWxlc1tlXX19LHtrZXk6XCJpc0Rpc2FibGVkUnVsZVwiLHZhbHVlOmZ1bmN0aW9uKGUpe3JldHVybiF0aGlzLl9lbmFibGVkUnVsZXNbZV19fSx7a2V5OlwiZW5hYmxlUnVsZVwiLHZhbHVlOmZ1bmN0aW9uKGUpe3JldHVybiB0aGlzLl9lbmFibGUoZSwhMCl9fSx7a2V5OlwiZGlzYWJsZVJ1bGVcIix2YWx1ZTpmdW5jdGlvbihlKXtyZXR1cm4gdGhpcy5fZW5hYmxlKGUsITEpfX0se2tleTpcImFkZFNhZmVUYWdcIix2YWx1ZTpmdW5jdGlvbihlLHQsYSl7dmFyIG49ZSBpbnN0YW5jZW9mIFJlZ0V4cD9lOltlLHQsYV07cmV0dXJuIHRoaXMuX3NhZmVUYWdzLmFkZChuKSx0aGlzfX0se2tleTpcIl9leGVjdXRlUnVsZXNcIix2YWx1ZTpmdW5jdGlvbih0LGUpe2U9ZXx8XCJkZWZhdWx0XCI7dmFyIGE9dGhpcy5fcnVsZXNCeVF1ZXVlc1tlXSxuPXRoaXMuX2lubmVyUnVsZXNCeVF1ZXVlc1tlXTtuJiZuLmZvckVhY2goZnVuY3Rpb24oZSl7dGhpcy5fcnVsZUl0ZXJhdG9yKHQsZSl9LHRoaXMpLGEmJmEuZm9yRWFjaChmdW5jdGlvbihlKXt0aGlzLl9ydWxlSXRlcmF0b3IodCxlKX0sdGhpcyl9fSx7a2V5OlwiX3J1bGVJdGVyYXRvclwiLHZhbHVlOmZ1bmN0aW9uKGUsdCl7dmFyIGE9dC5fbG9jYWxlLG49dGhpcy5fcHJlZnMubGl2ZTtpZighKCEwPT09biYmITE9PT10LmxpdmV8fCExPT09biYmITA9PT10LmxpdmUpJiYoXCJjb21tb25cIj09PWF8fGE9PT1lLnByZWZzLmxvY2FsZVswXSkmJnRoaXMuaXNFbmFibGVkUnVsZSh0Lm5hbWUpKXtpZihlLnByZWZzLnJ1bGVGaWx0ZXImJiFlLnByZWZzLnJ1bGVGaWx0ZXIodCkpcmV0dXJuO3RoaXMuX29uQmVmb3JlUnVsZSYmdGhpcy5fb25CZWZvcmVSdWxlKHQubmFtZSxlLnRleHQsZSksZS50ZXh0PXQuaGFuZGxlci5jYWxsKHRoaXMsZS50ZXh0LHRoaXMuX3NldHRpbmdzW3QubmFtZV0sZSksdGhpcy5fb25BZnRlclJ1bGUmJnRoaXMuX29uQWZ0ZXJSdWxlKHQubmFtZSxlLnRleHQsZSl9fX0se2tleTpcIl9yZW1vdmVDUlwiLHZhbHVlOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoL1xcclxcbj8vZyxcIlxcblwiKX19LHtrZXk6XCJfZml4TGluZUVuZGluZ1wiLHZhbHVlOmZ1bmN0aW9uKGUsdCl7cmV0dXJuXCJDUkxGXCI9PT10P2UucmVwbGFjZSgvXFxuL2csXCJcXHJcXG5cIik6XCJDUlwiPT09dD9lLnJlcGxhY2UoL1xcbi9nLFwiXFxyXCIpOmV9fSx7a2V5OlwiX3ByZXBhcmVSdWxlXCIsdmFsdWU6ZnVuY3Rpb24oZSl7dmFyIHQ9ZS5uYW1lLGE9cihlLnNldHRpbmdzKSxuPXt9O1wib2JqZWN0XCI9PT1hP249bC5kZWVwQ29weShlLnNldHRpbmdzKTpcImZ1bmN0aW9uXCI9PT1hJiYobj1lLnNldHRpbmdzKGUpKSx0aGlzLl9zZXR0aW5nc1t0XT1uLHRoaXMuX2VuYWJsZWRSdWxlc1t0XT1lLl9lbmFibGVkfX0se2tleTpcIl9lbmFibGVcIix2YWx1ZTpmdW5jdGlvbihlLHQpe3JldHVybiBBcnJheS5pc0FycmF5KGUpP2UuZm9yRWFjaChmdW5jdGlvbihlKXt0aGlzLl9lbmFibGVCeU1hc2soZSx0KX0sdGhpcyk6dGhpcy5fZW5hYmxlQnlNYXNrKGUsdCksdGhpc319LHtrZXk6XCJfZW5hYmxlQnlNYXNrXCIsdmFsdWU6ZnVuY3Rpb24oZSxhKXtpZihlKWlmKC0xIT09ZS5zZWFyY2goL1xcKi8pKXt2YXIgbj1uZXcgUmVnRXhwKGUucmVwbGFjZSgvXFwvL2csXCJcXFxcL1wiKS5yZXBsYWNlKC9cXCovZyxcIi4qXCIpKTt0aGlzLl9ydWxlcy5mb3JFYWNoKGZ1bmN0aW9uKGUpe3ZhciB0PWUubmFtZTtuLnRlc3QodCkmJih0aGlzLl9lbmFibGVkUnVsZXNbdF09YSl9LHRoaXMpfWVsc2UgdGhpcy5fZW5hYmxlZFJ1bGVzW2VdPWF9fSx7a2V5OlwiX2dldFJ1bGVcIix2YWx1ZTpmdW5jdGlvbih0KXt2YXIgYT1udWxsO3JldHVybiB0aGlzLl9ydWxlcy5zb21lKGZ1bmN0aW9uKGUpe3JldHVybiBlLm5hbWU9PT10JiYoYT1lLCEwKX0pLGF9fV0sW3trZXk6XCJhZGRSdWxlXCIsdmFsdWU6ZnVuY3Rpb24oZSl7dmFyIHQ9aShlLm5hbWUuc3BsaXQoXCIvXCIpLDMpLGE9dFswXSxuPXRbMV0scj10WzJdO3JldHVybiBlLl9lbmFibGVkPSEwIT09ZS5kaXNhYmxlZCxlLl9sb2NhbGU9YSxlLl9ncm91cD1uLGUuX25hbWU9cix0aGlzLmFkZExvY2FsZShlLl9sb2NhbGUpLHRoaXMuX3NldEluZGV4KGUpLHRoaXMucHJvdG90eXBlLl9ydWxlcy5wdXNoKGUpLHRoaXMuX3NvcnRSdWxlcyh0aGlzLnByb3RvdHlwZS5fcnVsZXMpLHRoaXN9fSx7a2V5OlwiYWRkSW5uZXJSdWxlXCIsdmFsdWU6ZnVuY3Rpb24oZSl7cmV0dXJuIHRoaXMucHJvdG90eXBlLl9pbm5lclJ1bGVzLnB1c2goZSksZS5fbG9jYWxlPWUubmFtZS5zcGxpdChcIi9cIilbMF0sdGhpc319LHtrZXk6XCJkZWVwQ29weVwiLHZhbHVlOmZ1bmN0aW9uKGUpe3JldHVyblwib2JqZWN0XCI9PT1yKGUpP0pTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZSkpOmV9fSx7a2V5OlwiX3JlcGVhdFwiLHZhbHVlOmZ1bmN0aW9uKGUsdCl7Zm9yKHZhciBhPVwiXCI7MT09KDEmdCkmJihhKz1lKSwwIT09KHQ+Pj49MSk7KWUrPWU7cmV0dXJuIGF9fSx7a2V5OlwiX3JlcGxhY2VcIix2YWx1ZTpmdW5jdGlvbihlLHQpe2Zvcih2YXIgYT0wO2E8dC5sZW5ndGg7YSsrKWU9ZS5yZXBsYWNlKHRbYV1bMF0sdFthXVsxXSk7cmV0dXJuIGV9fSx7a2V5OlwiX3JlcGxhY2VOYnNwXCIsdmFsdWU6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvXFx1MDBBMC9nLFwiIFwiKX19LHtrZXk6XCJfc2V0SW5kZXhcIix2YWx1ZTpmdW5jdGlvbihlKXt2YXIgdD1lLmluZGV4LGE9cih0KSxuPXRoaXMuZ3JvdXBJbmRleGVzW2UuX2dyb3VwXTtcInVuZGVmaW5lZFwiPT09YT90PW46XCJzdHJpbmdcIj09PWEmJih0PW4rcGFyc2VJbnQoZS5pbmRleCwxMCkpLGUuX2luZGV4PXR9fSx7a2V5OlwiX3NvcnRSdWxlc1wiLHZhbHVlOmZ1bmN0aW9uKGUpe2Uuc29ydChmdW5jdGlvbihlLHQpe3JldHVybiBlLl9pbmRleD50Ll9pbmRleD8xOi0xfSl9fSx7a2V5OlwiX21peFwiLHZhbHVlOmZ1bmN0aW9uKHQsYSl7T2JqZWN0LmtleXMoYSkuZm9yRWFjaChmdW5jdGlvbihlKXt0W2VdPWFbZV19KX19XSksbH0oKTtmdW5jdGlvbiBjKGUsdCxhLG4pe3JldHVybiB0K2EucmVwbGFjZSgvKFteXFx1MDBBMF0pXFx1MDBBMChbXlxcdTAwQTBdKS9nLFwiJDEgJDJcIikrbn1mLl9taXgoZix7dmVyc2lvbjpcIjYuOC4yXCIsaW5saW5lRWxlbWVudHM6cyxibG9ja0VsZW1lbnRzOltcImFkZHJlc3NcIixcImFydGljbGVcIixcImFzaWRlXCIsXCJibG9ja3F1b3RlXCIsXCJjYW52YXNcIixcImRkXCIsXCJkaXZcIixcImRsXCIsXCJmaWVsZHNldFwiLFwiZmlnY2FwdGlvblwiLFwiZmlndXJlXCIsXCJmb290ZXJcIixcImZvcm1cIixcImgxXCIsXCJoMlwiLFwiaDNcIixcImg0XCIsXCJoNVwiLFwiaDZcIixcImhlYWRlclwiLFwiaGdyb3VwXCIsXCJoclwiLFwibGlcIixcIm1haW5cIixcIm5hdlwiLFwibm9zY3JpcHRcIixcIm9sXCIsXCJvdXRwdXRcIixcInBcIixcInByZVwiLFwic2VjdGlvblwiLFwidGFibGVcIixcInRmb290XCIsXCJ1bFwiLFwidmlkZW9cIl0sZ3JvdXBJbmRleGVzOntzeW1ib2xzOjExMCxzcGFjZToyMTAsZGFzaDozMTAscHVuY3R1YXRpb246NDEwLG5ic3A6NTEwLG51bWJlcjo2MTAsbW9uZXk6NzEwLGRhdGU6ODEwLG90aGVyOjkxMCxvcHRhbGlnbjoxMDEwLHR5cG86MTExMCxodG1sOjEyMTB9LEh0bWxFbnRpdGllczplLF9yZVVybDpuZXcgUmVnRXhwKFwiKGh0dHBzP3xmaWxlfGZ0cCk6Ly8oW2EtekEtWjAtOS8rLT0lJjpfLn4/XStbYS16QS1aMC05IytdKilcIixcImdcIiksX3ByaXZhdGVMYWJlbDpcIlxcdWYwMDBcIixfcHJpdmF0ZVNlcGFyYXRlTGFiZWw6XCJcXHVmMDAxXCJ9KSxmLl9taXgoZi5wcm90b3R5cGUse19ydWxlczpbXSxfaW5uZXJSdWxlczpbXX0pLGYuX21peChmLHtnZXREYXRhOmZ1bmN0aW9uKGUpe3JldHVybiB0aGlzLl9kYXRhW2VdfSxzZXREYXRhOmZ1bmN0aW9uKHQsZSl7XCJzdHJpbmdcIj09dHlwZW9mIHQ/KHRoaXMuYWRkTG9jYWxlKHQpLHRoaXMuX2RhdGFbdF09ZSk6XCJvYmplY3RcIj09PXIodCkmJk9iamVjdC5rZXlzKHQpLmZvckVhY2goZnVuY3Rpb24oZSl7dGhpcy5hZGRMb2NhbGUoZSksdGhpcy5fZGF0YVtlXT10W2VdfSx0aGlzKX0sX2RhdGE6e319KSxmLl9taXgoZix7YWRkTG9jYWxlOmZ1bmN0aW9uKGUpe3ZhciB0PShlfHxcIlwiKS5zcGxpdChcIi9cIilbMF07dCYmXCJjb21tb25cIiE9PXQmJiF0aGlzLmhhc0xvY2FsZSh0KSYmKHRoaXMuX2xvY2FsZXMucHVzaCh0KSx0aGlzLl9sb2NhbGVzLnNvcnQoKSl9LGdldExvY2FsZXM6ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5fbG9jYWxlc30saGFzTG9jYWxlOmZ1bmN0aW9uKGUpe3JldHVyblwiY29tbW9uXCI9PT1lfHwtMSE9PXRoaXMuX2xvY2FsZXMuaW5kZXhPZihlKX0sX3ByZXBhcmVMb2NhbGU6ZnVuY3Rpb24oZSx0KXt2YXIgYT1lfHx0LG49YTtyZXR1cm4gQXJyYXkuaXNBcnJheShhKXx8KG49W2FdKSxufSxfbG9jYWxlczpbXX0pLGYuc2V0RGF0YShcImJlL2NoYXJcIixcIlxcdTA0MzBcXHUwNDMxXFx1MDQzMlxcdTA0MzNcXHUwNDM0XFx1MDQzNVxcdTA0MzZcXHUwNDM3XFx1MDQzOVxcdTA0M2FcXHUwNDNiXFx1MDQzY1xcdTA0M2RcXHUwNDNlXFx1MDQzZlxcdTA0NDBcXHUwNDQxXFx1MDQ0MlxcdTA0NDNcXHUwNDQ0XFx1MDQ0NVxcdTA0NDZcXHUwNDQ3XFx1MDQ0OFxcdTA0NGJcXHUwNDRjXFx1MDQ0ZFxcdTA0NGVcXHUwNDRmXFx1MDQ1MVxcdTA0NTZcXHUwNDVlXFx1MDQ5MVwiKSxmLnNldERhdGEoXCJiZS9xdW90ZVwiLHtsZWZ0OlwiXFx4YWJcXHUyMDFjXCIscmlnaHQ6XCJcXHhiYlxcdTIwMWRcIn0pLGYuc2V0RGF0YShcImJnL2NoYXJcIixcIlxcdTA0MzBcXHUwNDMxXFx1MDQzMlxcdTA0MzNcXHUwNDM0XFx1MDQzNVxcdTA0MzZcXHUwNDM3XFx1MDQzOFxcdTA0MzlcXHUwNDNhXFx1MDQzYlxcdTA0M2NcXHUwNDNkXFx1MDQzZVxcdTA0M2ZcXHUwNDQwXFx1MDQ0MVxcdTA0NDJcXHUwNDQzXFx1MDQ0NFxcdTA0NDVcXHUwNDQ2XFx1MDQ0N1xcdTA0NDhcXHUwNDQ5XFx1MDQ0YVxcdTA0NGNcXHUwNDRlXFx1MDQ0ZlwiKSxmLnNldERhdGEoXCJiZy9xdW90ZVwiLHtsZWZ0OlwiXFx1MjAxZVxcdTIwMTlcIixyaWdodDpcIlxcdTIwMWNcXHUyMDE5XCJ9KSxmLnNldERhdGEoXCJjYS9jaGFyXCIsXCJhYmNkZWZnaGlqbG1ub3BxcnN0dXZ4eXpcXHhlMFxceGU3XFx4ZThcXHhlOVxceGVkXFx4ZWZcXHhmMlxceGYzXFx4ZmFcXHhmY1wiKSxmLnNldERhdGEoXCJjYS9xdW90ZVwiLHtsZWZ0OlwiXFx4YWJcXHUyMDFjXCIscmlnaHQ6XCJcXHhiYlxcdTIwMWRcIn0pLGYuc2V0RGF0YShcImNvbW1vbi9jaGFyXCIsXCJhLXpcIiksZi5zZXREYXRhKFwiY29tbW9uL2Rhc2hcIixcIi0tP3xcXHUyMDEyfFxcdTIwMTN8XFx1MjAxNFwiKSxmLnNldERhdGEoXCJjb21tb24vcXVvdGVcIiwnXFx4YWJcXHUyMDM5XFx4YmJcXHUyMDNhXFx1MjAxZVxcdTIwMWNcXHUyMDFmXFx1MjAxZFwiJyksZi5zZXREYXRhKFwiY3MvY2hhclwiLFwiYS16XFx4ZTFcXHhlOVxceGVkXFx4ZjNcXHhmYVxceGZkXFx1MDEwZFxcdTAxMGZcXHUwMTFiXFx1MDE0OFxcdTAxNTlcXHUwMTYxXFx1MDE2NVxcdTAxNmZcXHUwMTdlXCIpLGYuc2V0RGF0YShcImNzL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFlXFx1MjAxYVwiLHJpZ2h0OlwiXFx1MjAxY1xcdTIwMThcIn0pLGYuc2V0RGF0YShcImRhL2NoYXJcIixcImEtelxceGU1XFx4ZTZcXHhmOFwiKSxmLnNldERhdGEoXCJkYS9xdW90ZVwiLHtsZWZ0OlwiXFx4YmJcXHUyMDNhXCIscmlnaHQ6XCJcXHhhYlxcdTIwMzlcIn0pLGYuc2V0RGF0YShcImRlL2NoYXJcIixcImEtelxceGRmXFx4ZTRcXHhmNlxceGZjXCIpLGYuc2V0RGF0YShcImRlL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFlXFx1MjAxYVwiLHJpZ2h0OlwiXFx1MjAxY1xcdTIwMThcIn0pLGYuc2V0RGF0YShcImVsL2NoYXJcIixcIlxcdTAzOTBcXHUwM2FjXFx1MDNhZFxcdTAzYWVcXHUwM2FmXFx1MDNiMFxcdTAzYjFcXHUwM2IyXFx1MDNiM1xcdTAzYjRcXHUwM2I1XFx1MDNiNlxcdTAzYjdcXHUwM2I4XFx1MDNiOVxcdTAzYmFcXHUwM2JiXFx1MDNiY1xcdTAzYmRcXHUwM2JlXFx1MDNiZlxcdTAzYzBcXHUwM2MxXFx1MDNjMlxcdTAzYzNcXHUwM2M0XFx1MDNjNVxcdTAzYzZcXHUwM2M3XFx1MDNjOFxcdTAzYzlcXHUwM2NhXFx1MDNjYlxcdTAzY2NcXHUwM2NkXFx1MDNjZVxcdTAzZjJcXHUxZjcxXFx1MWY3M1xcdTFmNzVcXHUxZjc3XFx1MWY3OVxcdTFmN2JcXHUxZjdkXCIpLGYuc2V0RGF0YShcImVsL3F1b3RlXCIse2xlZnQ6XCJcXHhhYlxcdTIwMWNcIixyaWdodDpcIlxceGJiXFx1MjAxZFwifSksZi5zZXREYXRhKFwiZW4tR0IvY2hhclwiLFwiYS16XCIpLGYuc2V0RGF0YShcImVuLUdCL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDE4XFx1MjAxY1wiLHJpZ2h0OlwiXFx1MjAxOVxcdTIwMWRcIn0pLGYuc2V0RGF0YShcImVuLVVTL2NoYXJcIixcImEtelwiKSxmLnNldERhdGEoXCJlbi1VUy9xdW90ZVwiLHtsZWZ0OlwiXFx1MjAxY1xcdTIwMThcIixyaWdodDpcIlxcdTIwMWRcXHUyMDE5XCJ9KSxmLnNldERhdGEoXCJlby9jaGFyXCIsXCJhYmNkZWZnaGlqa2xtbm9wcnN0dXZ6XFx1MDEwOVxcdTAxMWRcXHUwMTI1XFx1MDEzNVxcdTAxNWRcXHUwMTZkXCIpLGYuc2V0RGF0YShcImVvL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFjXFx1MjAxOFwiLHJpZ2h0OlwiXFx1MjAxZFxcdTIwMTlcIn0pLGYuc2V0RGF0YShcImVzL2NoYXJcIixcImEtelxceGUxXFx4ZTlcXHhlZFxceGYxXFx4ZjNcXHhmYVxceGZjXCIpLGYuc2V0RGF0YShcImVzL3F1b3RlXCIse2xlZnQ6XCJcXHhhYlxcdTIwMWNcIixyaWdodDpcIlxceGJiXFx1MjAxZFwifSksZi5zZXREYXRhKFwiZXQvY2hhclwiLFwiYWJkZWZnaGlqa2xtbm9wcnN0dXZ6XFx4ZTRcXHhmNVxceGY2XFx4ZmNcXHUwMTYxXFx1MDE3ZVwiKSxmLnNldERhdGEoXCJldC9xdW90ZVwiLHtsZWZ0OlwiXFx1MjAxZVxceGFiXCIscmlnaHQ6XCJcXHUyMDFjXFx4YmJcIn0pLGYuc2V0RGF0YShcImZpL2NoYXJcIixcImFiY2RlZmdoaWprbG1ub3BxcnN0dXZ5XFx4ZjZcXHhlNFxceGU1XCIpLGYuc2V0RGF0YShcImZpL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFkXFx1MjAxOVwiLHJpZ2h0OlwiXFx1MjAxZFxcdTIwMTlcIn0pLGYuc2V0RGF0YShcImZyL2NoYXJcIixcImEtelxceGUwXFx4ZTJcXHhlN1xceGU4XFx4ZTlcXHhlYVxceGViXFx4ZWVcXHhlZlxceGY0XFx4ZmJcXHhmY1xcdTAxNTNcXHhlNlwiKSxmLnNldERhdGEoXCJmci9xdW90ZVwiLHtsZWZ0OlwiXFx4YWJcXHUyMDM5XCIscmlnaHQ6XCJcXHhiYlxcdTIwM2FcIixzcGFjaW5nOiEwfSksZi5zZXREYXRhKFwiZ2EvY2hhclwiLFwiYWJjZGVmZ2hpbG1ub3Byc3R1dnd4eXpcXHhlMVxceGU5XFx4ZWRcXHhmM1xceGZhXCIpLGYuc2V0RGF0YShcImdhL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFjXFx1MjAxOFwiLHJpZ2h0OlwiXFx1MjAxZFxcdTIwMTlcIn0pLGYuc2V0RGF0YShcImh1L2NoYXJcIixcImEtelxceGUxXFx4ZTRcXHhlOVxceGVkXFx4ZjNcXHhmNlxceGZhXFx4ZmNcXHUwMTUxXFx1MDE3MVwiKSxmLnNldERhdGEoXCJodS9xdW90ZVwiLHtsZWZ0OlwiXFx1MjAxZVxceGJiXCIscmlnaHQ6XCJcXHUyMDFkXFx4YWJcIn0pLGYuc2V0RGF0YShcIml0L2NoYXJcIixcImEtelxceGUwXFx4ZTlcXHhlOFxceGVjXFx4ZjJcXHhmOVwiKSxmLnNldERhdGEoXCJpdC9xdW90ZVwiLHtsZWZ0OlwiXFx4YWJcXHUyMDFjXCIscmlnaHQ6XCJcXHhiYlxcdTIwMWRcIn0pLGYuc2V0RGF0YShcImx2L2NoYXJcIixcImFiY2RlZmdoaWprbG1ub3BxcnN0dXZ4elxceGU2XFx1MDE1M1wiKSxmLnNldERhdGEoXCJsdi9xdW90ZVwiLHtsZWZ0OlwiXFx4YWJcXHUyMDFlXCIscmlnaHQ6XCJcXHhiYlxcdTIwMWNcIn0pLGYuc2V0RGF0YShcIm5sL2NoYXJcIixcImEtelxceGU0XFx4ZTdcXHhlOFxceGU5XFx4ZWFcXHhlYlxceGVlXFx4ZWZcXHhmMVxceGY2XFx4ZmJcXHhmY1wiKSxmLnNldERhdGEoXCJubC9xdW90ZVwiLHtsZWZ0OlwiXFx1MjAxOFxcdTIwMWNcIixyaWdodDpcIlxcdTIwMTlcXHUyMDFkXCJ9KSxmLnNldERhdGEoXCJuby9jaGFyXCIsXCJhLXpcXHhlNVxceGU2XFx4ZThcXHhlOVxceGVhXFx4ZjJcXHhmM1xceGY0XFx4ZjhcIiksZi5zZXREYXRhKFwibm8vcXVvdGVcIix7bGVmdDpcIlxceGFiXFx1MjAxOVwiLHJpZ2h0OlwiXFx4YmJcXHUyMDE5XCJ9KSxmLnNldERhdGEoXCJwbC9jaGFyXCIsXCJhYmNkZWZnaGlqa2xtbm9wcnN0dXZ3eHl6XFx4ZjNcXHUwMTA1XFx1MDEwN1xcdTAxMTlcXHUwMTQyXFx1MDE0NFxcdTAxNWJcXHUwMTdhXFx1MDE3Y1wiKSxmLnNldERhdGEoXCJwbC9xdW90ZVwiLHtsZWZ0OlwiXFx1MjAxZVxceGFiXCIscmlnaHQ6XCJcXHUyMDFkXFx4YmJcIn0pLGYuc2V0RGF0YShcInJvL2NoYXJcIixcImFiY2RlZmdoaWprbG1ub3Byc3R1dnh6XFx4ZWVcXHUwMTAzXFx1MDIxOVxcdTAyMWJcIiksZi5zZXREYXRhKFwicm8vcXVvdGVcIix7bGVmdDpcIlxcdTIwMWVcXHhhYlwiLHJpZ2h0OlwiXFx1MjAxZFxceGJiXCJ9KSxmLnNldERhdGEoXCJydS9jaGFyXCIsXCJcXHUwNDMwLVxcdTA0NGZcXHUwNDUxXCIpLGYuc2V0RGF0YSh7XCJydS9kYXNoQmVmb3JlXCI6XCIoXnwgfFxcXFxuKVwiLFwicnUvZGFzaEFmdGVyXCI6XCIoPz1bXFx4YTAgLC4/OiFdfCQpXCIsXCJydS9kYXNoQWZ0ZXJEZVwiOlwiKD89WywuPzohXXxbXFx4YTAgXVteXFx1MDQxMC1cXHUwNDJmXFx1MDQwMV18JClcIn0pLGYuc2V0RGF0YSh7XCJydS9sXCI6XCJcXHUwNDMwLVxcdTA0NGZcXHUwNDUxYS16XCIsXCJydS9MXCI6XCJcXHUwNDEwLVxcdTA0MmZcXHUwNDAxQS1aXCJ9KSxmLnNldERhdGEoe1wicnUvbW9udGhcIjpcIlxcdTA0NGZcXHUwNDNkXFx1MDQzMlxcdTA0MzBcXHUwNDQwXFx1MDQ0Y3xcXHUwNDQ0XFx1MDQzNVxcdTA0MzJcXHUwNDQwXFx1MDQzMFxcdTA0M2JcXHUwNDRjfFxcdTA0M2NcXHUwNDMwXFx1MDQ0MFxcdTA0NDJ8XFx1MDQzMFxcdTA0M2ZcXHUwNDQwXFx1MDQzNVxcdTA0M2JcXHUwNDRjfFxcdTA0M2NcXHUwNDMwXFx1MDQzOXxcXHUwNDM4XFx1MDQ0ZVxcdTA0M2RcXHUwNDRjfFxcdTA0MzhcXHUwNDRlXFx1MDQzYlxcdTA0NGN8XFx1MDQzMFxcdTA0MzJcXHUwNDMzXFx1MDQ0M1xcdTA0NDFcXHUwNDQyfFxcdTA0NDFcXHUwNDM1XFx1MDQzZFxcdTA0NDJcXHUwNDRmXFx1MDQzMVxcdTA0NDBcXHUwNDRjfFxcdTA0M2VcXHUwNDNhXFx1MDQ0MlxcdTA0NGZcXHUwNDMxXFx1MDQ0MFxcdTA0NGN8XFx1MDQzZFxcdTA0M2VcXHUwNDRmXFx1MDQzMVxcdTA0NDBcXHUwNDRjfFxcdTA0MzRcXHUwNDM1XFx1MDQzYVxcdTA0MzBcXHUwNDMxXFx1MDQ0MFxcdTA0NGNcIixcInJ1L21vbnRoR2VuQ2FzZVwiOlwiXFx1MDQ0ZlxcdTA0M2RcXHUwNDMyXFx1MDQzMFxcdTA0NDBcXHUwNDRmfFxcdTA0NDRcXHUwNDM1XFx1MDQzMlxcdTA0NDBcXHUwNDMwXFx1MDQzYlxcdTA0NGZ8XFx1MDQzY1xcdTA0MzBcXHUwNDQwXFx1MDQ0MlxcdTA0MzB8XFx1MDQzMFxcdTA0M2ZcXHUwNDQwXFx1MDQzNVxcdTA0M2JcXHUwNDRmfFxcdTA0M2NcXHUwNDMwXFx1MDQ0ZnxcXHUwNDM4XFx1MDQ0ZVxcdTA0M2RcXHUwNDRmfFxcdTA0MzhcXHUwNDRlXFx1MDQzYlxcdTA0NGZ8XFx1MDQzMFxcdTA0MzJcXHUwNDMzXFx1MDQ0M1xcdTA0NDFcXHUwNDQyXFx1MDQzMHxcXHUwNDQxXFx1MDQzNVxcdTA0M2RcXHUwNDQyXFx1MDQ0ZlxcdTA0MzFcXHUwNDQwXFx1MDQ0ZnxcXHUwNDNlXFx1MDQzYVxcdTA0NDJcXHUwNDRmXFx1MDQzMVxcdTA0NDBcXHUwNDRmfFxcdTA0M2RcXHUwNDNlXFx1MDQ0ZlxcdTA0MzFcXHUwNDQwXFx1MDQ0ZnxcXHUwNDM0XFx1MDQzNVxcdTA0M2FcXHUwNDMwXFx1MDQzMVxcdTA0NDBcXHUwNDRmXCIsXCJydS9tb250aFByZUNhc2VcIjpcIlxcdTA0NGZcXHUwNDNkXFx1MDQzMlxcdTA0MzBcXHUwNDQwXFx1MDQzNXxcXHUwNDQ0XFx1MDQzNVxcdTA0MzJcXHUwNDQwXFx1MDQzMFxcdTA0M2JcXHUwNDM1fFxcdTA0M2NcXHUwNDMwXFx1MDQ0MFxcdTA0NDJcXHUwNDM1fFxcdTA0MzBcXHUwNDNmXFx1MDQ0MFxcdTA0MzVcXHUwNDNiXFx1MDQzNXxcXHUwNDNjXFx1MDQzMFxcdTA0MzV8XFx1MDQzOFxcdTA0NGVcXHUwNDNkXFx1MDQzNXxcXHUwNDM4XFx1MDQ0ZVxcdTA0M2JcXHUwNDM1fFxcdTA0MzBcXHUwNDMyXFx1MDQzM1xcdTA0NDNcXHUwNDQxXFx1MDQ0MlxcdTA0MzV8XFx1MDQ0MVxcdTA0MzVcXHUwNDNkXFx1MDQ0MlxcdTA0NGZcXHUwNDMxXFx1MDQ0MFxcdTA0MzV8XFx1MDQzZVxcdTA0M2FcXHUwNDQyXFx1MDQ0ZlxcdTA0MzFcXHUwNDQwXFx1MDQzNXxcXHUwNDNkXFx1MDQzZVxcdTA0NGZcXHUwNDMxXFx1MDQ0MFxcdTA0MzV8XFx1MDQzNFxcdTA0MzVcXHUwNDNhXFx1MDQzMFxcdTA0MzFcXHUwNDQwXFx1MDQzNVwiLFwicnUvc2hvcnRNb250aFwiOlwiXFx1MDQ0ZlxcdTA0M2RcXHUwNDMyfFxcdTA0NDRcXHUwNDM1XFx1MDQzMnxcXHUwNDNjXFx1MDQzMFxcdTA0NDB8XFx1MDQzMFxcdTA0M2ZcXHUwNDQwfFxcdTA0M2NcXHUwNDMwW1xcdTA0MzVcXHUwNDM5XFx1MDQ0Zl18XFx1MDQzOFxcdTA0NGVcXHUwNDNkfFxcdTA0MzhcXHUwNDRlXFx1MDQzYnxcXHUwNDMwXFx1MDQzMlxcdTA0MzN8XFx1MDQ0MVxcdTA0MzVcXHUwNDNkfFxcdTA0M2VcXHUwNDNhXFx1MDQ0MnxcXHUwNDNkXFx1MDQzZVxcdTA0NGZ8XFx1MDQzNFxcdTA0MzVcXHUwNDNhXCJ9KSxmLnNldERhdGEoXCJydS9xdW90ZVwiLHtsZWZ0OlwiXFx4YWJcXHUyMDFlXFx1MjAxYVwiLHJpZ2h0OlwiXFx4YmJcXHUyMDFjXFx1MjAxOFwiLHJlbW92ZUR1cGxpY2F0ZVF1b3RlczohMH0pLGYuc2V0RGF0YShcInJ1L3dlZWtkYXlcIixcIlxcdTA0M2ZcXHUwNDNlXFx1MDQzZFxcdTA0MzVcXHUwNDM0XFx1MDQzNVxcdTA0M2JcXHUwNDRjXFx1MDQzZFxcdTA0MzhcXHUwNDNhfFxcdTA0MzJcXHUwNDQyXFx1MDQzZVxcdTA0NDBcXHUwNDNkXFx1MDQzOFxcdTA0M2F8XFx1MDQ0MVxcdTA0NDBcXHUwNDM1XFx1MDQzNFxcdTA0MzB8XFx1MDQ0N1xcdTA0MzVcXHUwNDQyXFx1MDQzMlxcdTA0MzVcXHUwNDQwXFx1MDQzM3xcXHUwNDNmXFx1MDQ0ZlxcdTA0NDJcXHUwNDNkXFx1MDQzOFxcdTA0NDZcXHUwNDMwfFxcdTA0NDFcXHUwNDQzXFx1MDQzMVxcdTA0MzFcXHUwNDNlXFx1MDQ0MlxcdTA0MzB8XFx1MDQzMlxcdTA0M2VcXHUwNDQxXFx1MDQzYVxcdTA0NDBcXHUwNDM1XFx1MDQ0MVxcdTA0MzVcXHUwNDNkXFx1MDQ0Y1xcdTA0MzVcIiksZi5zZXREYXRhKFwic2svY2hhclwiLFwiYWJjZGVmZ2hpamtsbW5vcHJzdHV2d3h5elxceGUxXFx4ZTRcXHhlOVxceGVkXFx4ZjNcXHhmNFxceGZhXFx4ZmRcXHUwMTBkXFx1MDEwZlxcdTAxM2VcXHUwMTQ4XFx1MDE1NVxcdTAxNjFcXHUwMTY1XFx1MDE3ZVwiKSxmLnNldERhdGEoXCJzay9xdW90ZVwiLHtsZWZ0OlwiXFx1MjAxZVxcdTIwMWFcIixyaWdodDpcIlxcdTIwMWNcXHUyMDE4XCJ9KSxmLnNldERhdGEoXCJzbC9jaGFyXCIsXCJhLXpcXHUwMTBkXFx1MDE2MVxcdTAxN2VcIiksZi5zZXREYXRhKFwic2wvcXVvdGVcIix7bGVmdDpcIlxcdTIwMWVcXHUyMDFhXCIscmlnaHQ6XCJcXHUyMDFjXFx1MjAxOFwifSksZi5zZXREYXRhKFwic3IvY2hhclwiLFwiYWJjZGVmZ2hpamtsbW5vcHJzdHV2elxcdTAxMDdcXHUwMTBkXFx1MDExMVxcdTAxNjFcXHUwMTdlXCIpLGYuc2V0RGF0YShcInNyL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFlXFx1MjAxOVwiLHJpZ2h0OlwiXFx1MjAxZFxcdTIwMTlcIn0pLGYuc2V0RGF0YShcInN2L2NoYXJcIixcImEtelxceGU0XFx4ZTVcXHhlOVxceGY2XCIpLGYuc2V0RGF0YShcInN2L3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFkXFx1MjAxOVwiLHJpZ2h0OlwiXFx1MjAxZFxcdTIwMTlcIn0pLGYuc2V0RGF0YShcInRyL2NoYXJcIixcImFiY2RlZmdoaWprbG1ub3Byc3R1dnl6XFx4ZTJcXHhlN1xceGVlXFx4ZjZcXHhmYlxceGZjXFx1MDExZlxcdTAxMzFcXHUwMTVmXCIpLGYuc2V0RGF0YShcInRyL3F1b3RlXCIse2xlZnQ6XCJcXHUyMDFjXFx1MjAxOFwiLHJpZ2h0OlwiXFx1MjAxZFxcdTIwMTlcIn0pLGYuc2V0RGF0YShcInVrL2NoYXJcIixcIlxcdTA0MzBcXHUwNDMxXFx1MDQzMlxcdTA0MzNcXHUwNDM0XFx1MDQzNVxcdTA0MzZcXHUwNDM3XFx1MDQzOFxcdTA0MzlcXHUwNDNhXFx1MDQzYlxcdTA0M2NcXHUwNDNkXFx1MDQzZVxcdTA0M2ZcXHUwNDQwXFx1MDQ0MVxcdTA0NDJcXHUwNDQzXFx1MDQ0NFxcdTA0NDVcXHUwNDQ2XFx1MDQ0N1xcdTA0NDhcXHUwNDQ5XFx1MDQ0Y1xcdTA0NGVcXHUwNDRmXFx1MDQ1NFxcdTA0NTZcXHUwNDU3XFx1MDQ5MVwiKSxmLnNldERhdGEoXCJ1ay9xdW90ZVwiLHtsZWZ0OlwiXFx4YWJcXHUyMDFlXCIscmlnaHQ6XCJcXHhiYlxcdTIwMWNcIn0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9odG1sL2UtbWFpbFwiLHF1ZXVlOlwiZW5kXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQsYSl7cmV0dXJuIGEuaXNIVE1MP2U6ZS5yZXBsYWNlKC8oXnxbXFxzOyhdKShbXFx3XFwtLl17Miw2NH0pQChbXFx3XFwtLl17Miw2NH0pXFwuKFthLXpdezIsNjR9KShbKVxccy4sIT9dfCQpL2dpLCckMTxhIGhyZWY9XCJtYWlsdG86JDJAJDMuJDRcIj4kMkAkMy4kNDwvYT4kNScpfSxkaXNhYmxlZDohMCxodG1sQXR0cnM6ITF9KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vaHRtbC9lc2NhcGVcIixpbmRleDpcIisxMDBcIixxdWV1ZTpcImVuZFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9e1wiJlwiOlwiJmFtcDtcIixcIjxcIjpcIiZsdDtcIixcIj5cIjpcIiZndDtcIiwnXCInOlwiJnF1b3Q7XCIsXCInXCI6XCImIzM5O1wiLFwiL1wiOlwiJiN4MkY7XCJ9O3JldHVybiBlLnJlcGxhY2UoL1smPD5cIicvXS9nLGZ1bmN0aW9uKGUpe3JldHVybiB0W2VdfSl9LGRpc2FibGVkOiEwfSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL2h0bWwvbmJyXCIsaW5kZXg6XCIrMTBcIixxdWV1ZTpcImVuZFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvKFteXFxuPl0pXFxuKD89W15cXG5dKS9nLFwiJDE8YnIvPlxcblwiKX0sZGlzYWJsZWQ6ITAsaHRtbEF0dHJzOiExfSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL2h0bWwvcFwiLGluZGV4OlwiKzVcIixxdWV1ZTpcImVuZFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIG49bmV3IFJlZ0V4cChcIjwoXCIrZi5ibG9ja0VsZW1lbnRzLmpvaW4oXCJ8XCIpK1wiKVs+XFxcXHNdXCIpLHQ9ZS5zcGxpdChcIlxcblxcblwiKTtyZXR1cm4gdC5mb3JFYWNoKGZ1bmN0aW9uKGUsdCxhKXtlLnRyaW0oKSYmKG4udGVzdChlKXx8KGFbdF09ZS5yZXBsYWNlKC9eKFxccyopLyxcIiQxPHA+XCIpLnJlcGxhY2UoLyhcXHMqKSQvLFwiPC9wPiQxXCIpKSl9KSx0LmpvaW4oXCJcXG5cXG5cIil9LGRpc2FibGVkOiEwLGh0bWxBdHRyczohMX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9odG1sL3Byb2Nlc3NpbmdBdHRyc1wiLHF1ZXVlOlwiaGlkZS1zYWZlLXRhZ3Mtb3duXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQsYSl7dmFyIHU9dGhpcyxuPW5ldyBSZWdFeHAoXCIoXnxcXFxccykoXCIrdC5hdHRycy5qb2luKFwifFwiKStcIik9KFxcXCJbXlxcXCJdKj9cXFwifCdbXiddKj8nKVwiLFwiZ2lcIiksbD1mLmRlZXBDb3B5KGEucHJlZnMpO3JldHVybiBsLnJ1bGVGaWx0ZXI9ZnVuY3Rpb24oZSl7cmV0dXJuITEhPT1lLmh0bWxBdHRyc30sZS5yZXBsYWNlKC8oPFstXFx3XStcXHMpKFtePl0rPykoPz0+KS9nLGZ1bmN0aW9uKGUsdCxhKXtyZXR1cm4gdCthLnJlcGxhY2UobixmdW5jdGlvbihlLHQsYSxuKXt2YXIgcj1uWzBdLHM9bltuLmxlbmd0aC0xXSxpPW4uc2xpY2UoMSwtMSk7cmV0dXJuIHQrYStcIj1cIityK3UuZXhlY3V0ZShpLGwpK3N9KX0pfSxzZXR0aW5nczp7YXR0cnM6W1widGl0bGVcIixcInBsYWNlaG9sZGVyXCJdfSxkaXNhYmxlZDohMCxodG1sQXR0cnM6ITF9KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vaHRtbC9xdW90XCIscXVldWU6XCJoaWRlLXNhZmUtdGFnc1wiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvJnF1b3Q7L2csJ1wiJyl9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL2h0bWwvc3RyaXBUYWdzXCIsaW5kZXg6XCIrOTlcIixxdWV1ZTpcImVuZFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvPFtePl0rPi9nLFwiXCIpfSxkaXNhYmxlZDohMH0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9odG1sL3VybFwiLHF1ZXVlOlwiZW5kXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQsYSl7cmV0dXJuIGEuaXNIVE1MP2U6ZS5yZXBsYWNlKGYuX3JlVXJsLGZ1bmN0aW9uKGUsdCxhKXthPWEucmVwbGFjZSgvKFteL10rXFwvPykoXFw/fCMpJC8sXCIkMVwiKS5yZXBsYWNlKC9eKFteL10rKVxcLyQvLFwiJDFcIiksXCJodHRwXCI9PT10P2E9YS5yZXBsYWNlKC9eKFteL10rKSg6ODApKFteXFxkXXxcXC98JCkvLFwiJDEkM1wiKTpcImh0dHBzXCI9PT10JiYoYT1hLnJlcGxhY2UoL14oW14vXSspKDo0NDMpKFteXFxkXXxcXC98JCkvLFwiJDEkM1wiKSk7dmFyIG49YSxyPXQrXCI6Ly9cIithLHM9JzxhIGhyZWY9XCInK3IrJ1wiPic7cmV0dXJuXCJodHRwXCI9PT10fHxcImh0dHBzXCI9PT10PyhuPW4ucmVwbGFjZSgvXnd3d1xcLi8sXCJcIikscysoXCJodHRwXCI9PT10P246dCtcIjovL1wiK24pK1wiPC9hPlwiKTpzK3IrXCI8L2E+XCJ9KX0sZGlzYWJsZWQ6ITAsaHRtbEF0dHJzOiExfSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL25ic3AvYWZ0ZXJOdW1iZXJcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1cIihefFxcXFxEKShcXFxcZHsxLDV9KSAoW1wiK2EuZ2V0RGF0YShcImNoYXJcIikrXCJdKylcIjtyZXR1cm4gZS5yZXBsYWNlKG5ldyBSZWdFeHAobixcImdpXCIpLFwiJDEkMlxceGEwJDNcIil9LGRpc2FibGVkOiEwfSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL25ic3AvYWZ0ZXJQYXJhZ3JhcGhNYXJrXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC9cXHhiNiA/KD89XFxkKS9nLFwiXFx4YjZcXHhhMFwiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vbmJzcC9hZnRlclNlY3Rpb25NYXJrXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQsYSl7dmFyIG49YS5wcmVmcy5sb2NhbGVbMF07cmV0dXJuIGUucmVwbGFjZSgvXFx4YTdbIFxcdTAwQTBcXHUyMDA5XT8oPz1cXGR8SXxWfFgpL2csXCJydVwiPT09bj9cIlxceGE3XFx1MjAyZlwiOlwiXFx4YTdcXHhhMFwiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vbmJzcC9hZnRlclNob3J0V29yZFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSx0LGEpe3ZhciBuPXQubGVuZ3RoU2hvcnRXb3JkLHI9XCIoXnxbXCIrKFwiIFxceGEwKFwiK2YuX3ByaXZhdGVMYWJlbCtmLmdldERhdGEoXCJjb21tb24vcXVvdGVcIikpK1wiXSkoW1wiK2EuZ2V0RGF0YShcImNoYXJcIikrXCJdezEsXCIrbitcIn0pIFwiLHM9bmV3IFJlZ0V4cChyLFwiZ2ltXCIpO3JldHVybiBlLnJlcGxhY2UocyxcIiQxJDJcXHhhMFwiKS5yZXBsYWNlKHMsXCIkMSQyXFx4YTBcIil9LHNldHRpbmdzOntsZW5ndGhTaG9ydFdvcmQ6Mn19KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vbmJzcC9iZWZvcmVTaG9ydExhc3ROdW1iZXJcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1hLmdldERhdGEoXCJjaGFyXCIpLHI9bi50b1VwcGVyQ2FzZSgpLHM9bmV3IFJlZ0V4cChcIihbXCIrbityK1wiXSkgKD89XFxcXGR7MSxcIit0Lmxlbmd0aExhc3ROdW1iZXIrXCJ9Wy0rXFx1MjIxMiUnXFxcIlwiK2EuZ2V0RGF0YShcInF1b3RlXCIpLnJpZ2h0K1wiXT8oWy4hP1xcdTIwMjZdKCBbXCIrcitcIl18JCl8JCkpXCIsXCJnbVwiKTtyZXR1cm4gZS5yZXBsYWNlKHMsXCIkMVxceGEwXCIpfSxsaXZlOiExLHNldHRpbmdzOntsZW5ndGhMYXN0TnVtYmVyOjJ9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL25ic3AvYmVmb3JlU2hvcnRMYXN0V29yZFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSx0LGEpe3ZhciBuPWEuZ2V0RGF0YShcImNoYXJcIikscj1uLnRvVXBwZXJDYXNlKCkscz1uZXcgUmVnRXhwKFwiKFtcIituK1wiXFxcXGRdKSAoW1wiK24rcitcIl17MSxcIit0Lmxlbmd0aExhc3RXb3JkK1wifVsuIT9cXHUyMDI2XSkoIFtcIityK1wiXXwkKVwiLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKHMsXCIkMVxceGEwJDIkM1wiKX0sc2V0dGluZ3M6e2xlbmd0aExhc3RXb3JkOjN9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL25ic3AvZHBpXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8oXFxkKSA/KGxwaXxkcGkpKD8hXFx3KS8sXCIkMVxceGEwJDJcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL25ic3Avbm93cmFwXCIscXVldWU6XCJlbmRcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyg8bm93cmFwPikoLio/KSg8XFwvbm93cmFwPikvZyxjKS5yZXBsYWNlKC8oPG5vYnI+KSguKj8pKDxcXC9ub2JyPikvZyxjKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vbmJzcC9yZXBsYWNlTmJzcFwiLHF1ZXVlOlwidXRmXCIsbGl2ZTohMSxoYW5kbGVyOmYuX3JlcGxhY2VOYnNwLGRpc2FibGVkOiEwfSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL251bWJlci9mcmFjdGlvblwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvKF58XFxEKTFcXC8yKFxcRHwkKS9nLFwiJDFcXHhiZCQyXCIpLnJlcGxhY2UoLyhefFxcRCkxXFwvNChcXER8JCkvZyxcIiQxXFx4YmMkMlwiKS5yZXBsYWNlKC8oXnxcXEQpM1xcLzQoXFxEfCQpL2csXCIkMVxceGJlJDJcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL251bWJlci9tYXRoU2lnbnNcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBmLl9yZXBsYWNlKGUsW1svIT0vZyxcIlxcdTIyNjBcIl0sWy88PS9nLFwiXFx1MjI2NFwiXSxbLyhefFtePV0pPj0vZyxcIiQxXFx1MjI2NVwiXSxbLzw9Pi9nLFwiXFx1MjFkNFwiXSxbLzw8L2csXCJcXHUyMjZhXCJdLFsvPj4vZyxcIlxcdTIyNmJcIl0sWy9+PS9nLFwiXFx1MjI0NVwiXSxbLyhefFteK10pXFwrLS9nLFwiJDFcXHhiMVwiXV0pfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9udW1iZXIvdGltZXNcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyhcXGQpWyBcXHUwMEEwXT9beFxcdTA0NDVdWyBcXHUwMEEwXT8oXFxkKS9nLFwiJDFcXHhkNyQyXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9vdGhlci9kZWxCT01cIixxdWV1ZTpcInN0YXJ0XCIsaW5kZXg6LTEsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gNjUyNzk9PT1lLmNoYXJDb2RlQXQoMCk/ZS5zbGljZSgxKTplfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9vdGhlci9yZXBlYXRXb3JkXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQsYSl7dmFyIG49XCJbOzosLj8hIFxcblwiK2YuZ2V0RGF0YShcImNvbW1vbi9xdW90ZVwiKStcIl1cIixyPW5ldyBSZWdFeHAoXCIoXCIrbitcInxeKShbXCIrYS5nZXREYXRhKFwiY2hhclwiKStcIl17XCIrdC5taW4rXCIsfSkgXFxcXDIoXCIrbitcInwkKVwiLFwiZ2lcIik7cmV0dXJuIGUucmVwbGFjZShyLFwiJDEkMiQzXCIpfSxzZXR0aW5nczp7bWluOjJ9LGRpc2FibGVkOiEwfSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL3B1bmN0dWF0aW9uL2Fwb3N0cm9waGVcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1cIihbXCIrYS5nZXREYXRhKFwiY2hhclwiKStcIl0pXCIscj1uZXcgUmVnRXhwKG4rXCInXCIrbixcImdpXCIpO3JldHVybiBlLnJlcGxhY2UocixcIiQxXFx1MjAxOSQyXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9wdW5jdHVhdGlvbi9kZWxEb3VibGVQdW5jdHVhdGlvblwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvKF58W14sXSksLCg/ISwpL2csXCIkMSxcIikucmVwbGFjZSgvKF58W146XSk6Oig/ITopL2csXCIkMTpcIikucmVwbGFjZSgvKF58W14hPy5dKVxcLlxcLig/IVxcLikvZyxcIiQxLlwiKS5yZXBsYWNlKC8oXnxbXjtdKTs7KD8hOykvZyxcIiQxO1wiKS5yZXBsYWNlKC8oXnxbXj9dKVxcP1xcPyg/IVxcPykvZyxcIiQxP1wiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vcHVuY3R1YXRpb24vaGVsbGlwXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQsYSl7cmV0dXJuXCJydVwiPT09YS5wcmVmcy5sb2NhbGVbMF0/ZS5yZXBsYWNlKC8oXnxbXi5dKVxcLnszLDR9KD89W14uXXwkKS9nLFwiJDFcXHUyMDI2XCIpOmUucmVwbGFjZSgvKF58W14uXSlcXC57M30oXFwuPykoPz1bXi5dfCQpL2csXCIkMVxcdTIwMjYkMlwiKX19KTt2YXIgZCxwLGcsaCxtLHYsUiwkLGIsXz17YnVmZmVyUXVvdGVzOntsZWZ0OlwiXFx1ZjAwNVxcdWYwMDZcXHVmMDA3XCIscmlnaHQ6XCJcXHVmMDA4XFx1ZjAwOVxcdWYwYTBcIn0sbWF4TGV2ZWw6MyxiZWZvcmVMZWZ0OlwiIFxcblxcdFxceGEwWyhcIixhZnRlclJpZ2h0OlwiIFxcblxcdFxceGEwIT8uOjsjKixcXHUyMDI2KVwiLHByb2Nlc3M6ZnVuY3Rpb24oZSl7dmFyIHQ9ZS5jb250ZXh0LnRleHQ7aWYoIXRoaXMuY291bnQodCkudG90YWwpcmV0dXJuIHQ7dmFyIGE9ZS5zZXR0aW5ncyxuPWUuc2V0dGluZ3MubGVmdFswXT09PWUuc2V0dGluZ3MucmlnaHRbMF07cmV0dXJuIG4mJihlLnNldHRpbmdzPWYuZGVlcENvcHkoZS5zZXR0aW5ncyksZS5zZXR0aW5ncy5sZWZ0PXRoaXMuYnVmZmVyUXVvdGVzLmxlZnQuc2xpY2UoMCxlLnNldHRpbmdzLmxlZnQubGVuZ3RoKSxlLnNldHRpbmdzLnJpZ2h0PXRoaXMuYnVmZmVyUXVvdGVzLnJpZ2h0LnNsaWNlKDAsZS5zZXR0aW5ncy5yaWdodC5sZW5ndGgpKSxlLnNldHRpbmdzLnNwYWNpbmcmJih0PXRoaXMucmVtb3ZlU3BhY2luZyh0LGUuc2V0dGluZ3MpKSx0PXRoaXMuc2V0KHQsZSksZS5zZXR0aW5ncy5zcGFjaW5nJiYodD10aGlzLnNldFNwYWNpbmcodCxlLnNldHRpbmdzKSksZS5zZXR0aW5ncy5yZW1vdmVEdXBsaWNhdGVRdW90ZXMmJih0PXRoaXMucmVtb3ZlRHVwbGljYXRlcyh0LGUuc2V0dGluZ3MpKSxuJiYodD10aGlzLnJldHVybk9yaWdpbmFsUXVvdGVzKHQsYSxlLnNldHRpbmdzKSxlLnNldHRpbmdzPWEpLHR9LHJldHVybk9yaWdpbmFsUXVvdGVzOmZ1bmN0aW9uKGUsdCxhKXtmb3IodmFyIG49e30scj0wO3I8YS5sZWZ0Lmxlbmd0aDtyKyspblthLmxlZnRbcl1dPXQubGVmdFtyXSxuW2EucmlnaHRbcl1dPXQucmlnaHRbcl07cmV0dXJuIGUucmVwbGFjZShuZXcgUmVnRXhwKFwiW1wiK2EubGVmdCthLnJpZ2h0K1wiXVwiLFwiZ1wiKSxmdW5jdGlvbihlKXtyZXR1cm4gbltlXX0pfSxjb3VudDpmdW5jdGlvbihlKXt2YXIgdD17dG90YWw6MH07cmV0dXJuIGUucmVwbGFjZShuZXcgUmVnRXhwKFwiW1wiK2YuZ2V0RGF0YShcImNvbW1vbi9xdW90ZVwiKStcIl1cIixcImdcIiksZnVuY3Rpb24oZSl7cmV0dXJuIHRbZV18fCh0W2VdPTApLHRbZV0rKyx0LnRvdGFsKyssZX0pLHR9LHJlbW92ZUR1cGxpY2F0ZXM6ZnVuY3Rpb24oZSx0KXt2YXIgYT10LmxlZnRbMF0sbj10LmxlZnRbMV18fGEscj10LnJpZ2h0WzBdO3JldHVybiBhIT09bj9lOmUucmVwbGFjZShuZXcgUmVnRXhwKGErYSxcImdcIiksYSkucmVwbGFjZShuZXcgUmVnRXhwKHIrcixcImdcIikscil9LHJlbW92ZVNwYWNpbmc6ZnVuY3Rpb24oZSx0KXtmb3IodmFyIGE9MCxuPXQubGVmdC5sZW5ndGg7YTxuO2ErKyl7dmFyIHI9dC5sZWZ0W2FdLHM9dC5yaWdodFthXTtlPWUucmVwbGFjZShuZXcgUmVnRXhwKHIrXCIoWyBcXHUyMDJmXFx4YTBdKVwiLFwiZ1wiKSxyKS5yZXBsYWNlKG5ldyBSZWdFeHAoXCIoWyBcXHUyMDJmXFx4YTBdKVwiK3MsXCJnXCIpLHMpfXJldHVybiBlfSxzZXRTcGFjaW5nOmZ1bmN0aW9uKGUsdCl7Zm9yKHZhciBhPTAsbj10LmxlZnQubGVuZ3RoO2E8bjthKyspe3ZhciByPXQubGVmdFthXSxzPXQucmlnaHRbYV07ZT1lLnJlcGxhY2UobmV3IFJlZ0V4cChyK1wiKFteXFx1MjAyZl0pXCIsXCJnXCIpLHIrXCJcXHUyMDJmJDFcIikucmVwbGFjZShuZXcgUmVnRXhwKFwiKFteXFx1MjAyZl0pXCIrcyxcImdcIiksXCIkMVxcdTIwMmZcIitzKX1yZXR1cm4gZX0sc2V0OmZ1bmN0aW9uKGUsdCl7dmFyIGE9Zi5fcHJpdmF0ZUxhYmVsLG49Zi5nZXREYXRhKFwiY29tbW9uL3F1b3RlXCIpLHI9dC5zZXR0aW5ncy5sZWZ0WzBdLHM9dC5zZXR0aW5ncy5sZWZ0WzFdfHxyLGk9dC5zZXR0aW5ncy5yaWdodFswXSx1PW5ldyBSZWdFeHAoXCIoXnxbXCIrdGhpcy5iZWZvcmVMZWZ0K1wiXSkoW1wiK24rXCJdezEsXCIrdGhpcy5tYXhMZXZlbCtcIn0pKD89W15cXFxcc1wiK2ErXCJdKVwiLFwiZ2ltXCIpLGw9bmV3IFJlZ0V4cChcIihbXlxcXFxzXCIrYStcIl0pKFtcIituK1wiXXsxLFwiK3RoaXMubWF4TGV2ZWwrXCJ9KSg/PVtcIit0aGlzLmFmdGVyUmlnaHQrXCJdfCQpXCIsXCJnaW1cIik7cmV0dXJuIGU9ZS5yZXBsYWNlKHUsZnVuY3Rpb24oZSx0LGEpe3JldHVybiB0K2YuX3JlcGVhdChyLGEubGVuZ3RoKX0pLnJlcGxhY2UobCxmdW5jdGlvbihlLHQsYSl7cmV0dXJuIHQrZi5fcmVwZWF0KGksYS5sZW5ndGgpfSksZT10aGlzLnNldEFib3ZlVGFncyhlLHQpLHIhPT1zJiYoZT10aGlzLnNldElubmVyKGUsdC5zZXR0aW5ncykpLGV9LHNldEFib3ZlVGFnczpmdW5jdGlvbihvLGMpe3ZhciBkPXRoaXMscD1mLl9wcml2YXRlTGFiZWwsZT1mLmdldERhdGEoXCJjb21tb24vcXVvdGVcIiksZz1jLnNldHRpbmdzLmxlZnRbMF0saD1jLnNldHRpbmdzLnJpZ2h0WzBdO3JldHVybiBvLnJlcGxhY2UobmV3IFJlZ0V4cChcIihefC4pKFtcIitlK1wiXSkoLnwkKVwiLFwiZ21cIiksZnVuY3Rpb24oZSx0LGEsbixyKXtpZih0IT09cCYmbiE9PXApcmV0dXJuIGU7aWYodD09PXAmJm49PT1wKXJldHVybidcIic9PT1hP3QrZC5nZXRBYm92ZVR3b1RhZ3MobyxyKzEsYykrbjplO2lmKHQ9PT1wKXt2YXIgcz0tMTxkLmFmdGVyUmlnaHQuaW5kZXhPZihuKSxpPWQuZ2V0UHJldlRhZ0luZm8obyxyLTEsYyk7cmV0dXJuIHMmJmkmJlwiaHRtbFwiPT09aS5ncm91cD90KyhpLmlzQ2xvc2luZz9oOmcpK246dCsoIW58fHM/aDpnKStufXZhciB1PS0xPGQuYmVmb3JlTGVmdC5pbmRleE9mKHQpLGw9ZC5nZXROZXh0VGFnSW5mbyhvLHIrMSxjKTtyZXR1cm4gdSYmbCYmXCJodG1sXCI9PT1sLmdyb3VwP3QrKGwuaXNDbG9zaW5nP2g6Zykrbjp0KyghdHx8dT9nOmgpK259KX0sZ2V0QWJvdmVUd29UYWdzOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj10aGlzLmdldFByZXZUYWdJbmZvKGUsdCxhKSxyPXRoaXMuZ2V0TmV4dFRhZ0luZm8oZSx0LGEpO2lmKG4mJlwiaHRtbFwiPT09bi5ncm91cCl7aWYoIW4uaXNDbG9zaW5nKXJldHVybiBhLnNldHRpbmdzLmxlZnRbMF07aWYociYmci5pc0Nsb3NpbmcmJm4uaXNDbG9zaW5nKXJldHVybiBhLnNldHRpbmdzLnJpZ2h0WzBdfXJldHVybiBlW3RdfSxnZXRQcmV2VGFnSW5mbzpmdW5jdGlvbihlLHQsYSl7dmFyIG49YS5zYWZlVGFncy5nZXRQcmV2TGFiZWwoZSx0LTEpO2lmKG4pe3ZhciByPWEuc2FmZVRhZ3MuZ2V0VGFnQnlMYWJlbChhLmNvbnRleHQsbik7aWYocilyZXR1cm4gYS5zYWZlVGFncy5nZXRUYWdJbmZvKHIpfXJldHVybiBudWxsfSxnZXROZXh0VGFnSW5mbzpmdW5jdGlvbihlLHQsYSl7dmFyIG49YS5zYWZlVGFncy5nZXROZXh0TGFiZWwoZSx0KzEpO2lmKG4pe3ZhciByPWEuc2FmZVRhZ3MuZ2V0VGFnQnlMYWJlbChhLmNvbnRleHQsbik7aWYocilyZXR1cm4gYS5zYWZlVGFncy5nZXRUYWdJbmZvKHIpfXJldHVybiBudWxsfSxzZXRJbm5lcjpmdW5jdGlvbihlLHQpe2Zvcih2YXIgYT1bXSxuPVtdLHI9MDtyPHQubGVmdC5sZW5ndGg7cisrKWEucHVzaCh0LmxlZnRbcl0pLG4ucHVzaCh0LnJpZ2h0W3JdKTtmb3IodmFyIHM9dC5sZWZ0WzBdLGk9dC5yaWdodFswXSx1PWEubGVuZ3RoLTEsbD0tMSxvPVwiXCIsYz0wLGQ9ZS5sZW5ndGg7YzxkO2MrKyl7dmFyIHA9ZVtjXTtwPT09cz8odTwrK2wmJihsPXUpLG8rPWFbbF0pOnA9PT1pP2w8PS0xP28rPW5bbD0wXToobys9bltsXSwtLWw8LTEmJihsPS0xKSk6KCdcIic9PT1wJiYobD0tMSksbys9cCl9dmFyIGc9dGhpcy5jb3VudChvLHQpO3JldHVybiBnW3NdIT09Z1tpXT9lOm99fTtmdW5jdGlvbiB4KGUpe3ZhciB0LGEsbj1lWzBdLHI9XCJcIjtpZihlLmxlbmd0aDw4KXJldHVybiB5KGUpO2lmKDEwPGUubGVuZ3RoKWlmKFwiK1wiPT09bil7aWYoXCI3XCIhPT1lWzFdKXJldHVybiBlO3Q9ITAsZT1lLnN1YnN0cigyKX1lbHNlXCI4XCI9PT1uJiYoYT0hMCxlPWUuc3Vic3RyKDEpKTtmb3IodmFyIHM9ODsyPD1zO3MtLSl7dmFyIGk9K2Uuc3Vic3RyKDAscyk7aWYoLTE8Ui5pbmRleE9mKGkpKXtyPWUuc3Vic3RyKDAscyksZT1lLnN1YnN0cihzKTticmVha319cmV0dXJuIHJ8fChyPWUuc3Vic3RyKDAsNSksZT1lLnN1YnN0cig1KSksKHQ/XCIrN1xceGEwXCI6XCJcIikrKGE/XCI4XFx4YTBcIjpcIlwiKStmdW5jdGlvbihlKXt2YXIgdD0rZSxhPWUubGVuZ3RoLG49W2VdLHI9ITE7aWYoMzxhKXN3aXRjaChhKXtjYXNlIDQ6bj1bZS5zdWJzdHIoMCwyKSxlLnN1YnN0cigyLDIpXTticmVhaztjYXNlIDU6bj1bZS5zdWJzdHIoMCwzKSxlLnN1YnN0cigzLDMpXTticmVhaztjYXNlIDY6bj1bZS5zdWJzdHIoMCwyKSxlLnN1YnN0cigyLDIpLGUuc3Vic3RyKDQsMildfWVsc2Ugcj05MDA8dCYmdDw9OTk5fHw0OTU9PXR8fDQ5OT09dDtyZXR1cm4gbj1uLmpvaW4oXCItXCIpLHI/bjpcIihcIituK1wiKVwifShyKStcIlxceGEwXCIreShlKX1mdW5jdGlvbiB5KGUpe3ZhciB0PVwiXCI7cmV0dXJuIGUubGVuZ3RoJTImJih0PWVbMF0sdCs9ZS5sZW5ndGg8PTU/XCItXCI6XCJcIixlPWUuc3Vic3RyKDEsZS5sZW5ndGgtMSkpLHQrZS5zcGxpdCgvKD89KD86XFxkXFxkKSskKS8pLmpvaW4oXCItXCIpfWZ1bmN0aW9uIEUoZSl7cmV0dXJuIGUucmVwbGFjZSgvW15cXGQrXS9nLFwiXCIpfXJldHVybiBmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vcHVuY3R1YXRpb24vcXVvdGVcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj10W2EucHJlZnMubG9jYWxlWzBdXTtyZXR1cm4gbj9fLnByb2Nlc3Moe2NvbnRleHQ6YSxzZXR0aW5nczpuLHNhZmVUYWdzOnRoaXMuX3NhZmVUYWdzfSk6ZX0sc2V0dGluZ3M6ZnVuY3Rpb24oKXt2YXIgdD17fTtyZXR1cm4gZi5nZXRMb2NhbGVzKCkuZm9yRWFjaChmdW5jdGlvbihlKXt0W2VdPWYuZGVlcENvcHkoZi5nZXREYXRhKGUrXCIvcXVvdGVcIikpfSksdH19KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vcHVuY3R1YXRpb24vcXVvdGVMaW5rXCIscXVldWU6XCJzaG93LXNhZmUtdGFncy1odG1sXCIsaW5kZXg6XCIrNVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSx0LGEpe3ZhciBuPXRoaXMuZ2V0U2V0dGluZyhcImNvbW1vbi9wdW5jdHVhdGlvbi9xdW90ZVwiLGEucHJlZnMubG9jYWxlWzBdKTtpZighbilyZXR1cm4gZTt2YXIgcj1mLkh0bWxFbnRpdGllcyxzPXIuZ2V0QnlVdGYobi5sZWZ0WzBdKSxpPXIuZ2V0QnlVdGYobi5yaWdodFswXSksdT1yLmdldEJ5VXRmKG4ubGVmdFsxXSksbD1yLmdldEJ5VXRmKG4ucmlnaHRbMV0pO3U9dT9cInxcIit1OlwiXCIsbD1sP1wifFwiK2w6XCJcIjt2YXIgbz1uZXcgUmVnRXhwKFwiKDxbYUFdXFxcXHNbXj5dKj8+KShcIitzK3UrXCIpKFteXSo/KShcIitpK2wrXCIpKDwvW2FBXT4pXCIsXCJnXCIpO3JldHVybiBlLnJlcGxhY2UobyxcIiQyJDEkMyQ1JDRcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL3N5bWJvbHMvYXJyb3dcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBmLl9yZXBsYWNlKGUsW1svKF58W14tXSktPig/IT4pL2csXCIkMVxcdTIxOTJcIl0sWy8oXnxbXjxdKTwtKD8hLSkvZyxcIiQxXFx1MjE5MFwiXV0pfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zeW1ib2xzL2NmXCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1uZXcgUmVnRXhwKCcoXnxbXFxcXHMoXFxcXFsrXFx1MjI0OFxceGIxXFx1MjIxMlxcdTIwMTRcXHUyMDEzXFxcXC1dKShcXFxcZCsoPzpbLixdXFxcXGQrKT8pWyBcXHhhMFxcdTIwMDldPyhDfEYpKFtcXFxcV1xcXFxzLiw6IT9cIilcXFxcXV18JCknLFwibWdcIik7cmV0dXJuIGUucmVwbGFjZSh0LFwiJDEkMlxcdTIwMDlcXHhiMCQzJDRcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL3N5bWJvbHMvY29weVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGYuX3JlcGxhY2UoZSxbWy9cXChyXFwpL2dpLFwiXFx4YWVcIl0sWy8oY29weXJpZ2h0ICk/XFwoKGN8XFx1MDQ0MSlcXCkvZ2ksXCJcXHhhOVwiXSxbL1xcKHRtXFwpL2dpLFwiXFx1MjEyMlwiXV0pfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS9hZnRlclB1bmN0dWF0aW9uXCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1mLl9wcml2YXRlTGFiZWwsYT1uZXcgUmVnRXhwKFwiKCF8O3xcXFxcPykoW14pLlxcdTIwMjYhOz9cXFxcc1tcXFxcXSlcIit0K2YuZ2V0RGF0YShcImNvbW1vbi9xdW90ZVwiKStcIl0pXCIsXCJnXCIpLG49bmV3IFJlZ0V4cCgnKFxcXFxEKSgsfDopKFteKVwiLDouP1xcXFxzXFxcXC9cXFxcXFxcXCcrdCtcIl0pXCIsXCJnXCIpO3JldHVybiBlLnJlcGxhY2UoYSxcIiQxICQyXCIpLnJlcGxhY2UobixcIiQxJDIgJDNcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL3NwYWNlL2JlZm9yZUJyYWNrZXRcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1uZXcgUmVnRXhwKFwiKFtcIithLmdldERhdGEoXCJjaGFyXCIpK1wiLiE/LDtcXHUyMDI2KV0pXFxcXChcIixcImdpXCIpO3JldHVybiBlLnJlcGxhY2UobixcIiQxIChcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL3NwYWNlL2JyYWNrZXRcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyhcXCgpICsvZyxcIihcIikucmVwbGFjZSgvICtcXCkvZyxcIilcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL3NwYWNlL2RlbEJlZm9yZVBlcmNlbnRcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyhcXGQpKCB8XFx1MDBBMCkoJXxcXHUyMDMwfFxcdTIwMzEpL2csXCIkMSQzXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS9kZWxCZWZvcmVQdW5jdHVhdGlvblwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvKFshP10pICg/PVshP10pL2csXCIkMVwiKS5yZXBsYWNlKC8oXnxbXiE/OjssLlxcdTIwMjZdKSAoWyE/OjssLl0pKD8hXFwpKS9nLFwiJDEkMlwiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJjb21tb24vc3BhY2UvZGVsTGVhZGluZ0JsYW5rc1wiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvXFxuWyBcXHRdKy9nLFwiXFxuXCIpfSxkaXNhYmxlZDohMH0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS9kZWxSZXBlYXROXCIsaW5kZXg6XCItMVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvXFxuezMsfS9nLFwiXFxuXFxuXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS9kZWxSZXBlYXRTcGFjZVwiLGluZGV4OlwiLTFcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyhbXlxcbiBcXHRdKVsgXFx0XXsyLH0oPyFbXFxuIFxcdF0pL2csXCIkMSBcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiY29tbW9uL3NwYWNlL2RlbFRyYWlsaW5nQmxhbmtzXCIsaW5kZXg6XCItM1wiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvWyBcXHRdK1xcbi9nLFwiXFxuXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS9yZXBsYWNlVGFiXCIsaW5kZXg6XCItNVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvXFx0L2csXCIgICAgXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS9zcXVhcmVCcmFja2V0XCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8oXFxbKSArL2csXCJbXCIpLnJlcGxhY2UoLyArXFxdL2csXCJdXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS90cmltTGVmdFwiLGluZGV4OlwiLTRcIixoYW5kbGVyOlN0cmluZy5wcm90b3R5cGUudHJpbUxlZnQ/ZnVuY3Rpb24oZSl7cmV0dXJuIGUudHJpbUxlZnQoKX06ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvXltcXHNcXHVGRUZGXFx4QTBdKy9nLFwiXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcImNvbW1vbi9zcGFjZS90cmltUmlnaHRcIixpbmRleDpcIi0zXCIsbGl2ZTohMSxoYW5kbGVyOlN0cmluZy5wcm90b3R5cGUudHJpbVJpZ2h0P2Z1bmN0aW9uKGUpe3JldHVybiBlLnRyaW1SaWdodCgpfTpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC9bXFxzXFx1RkVGRlxceEEwXSskL2csXCJcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwiZW4tVVMvZGFzaC9tYWluXCIsaW5kZXg6XCItNVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9Zi5nZXREYXRhKFwiY29tbW9uL2Rhc2hcIiksYT1cIlsgXCIuY29uY2F0KFwiXFx4YTBcIixcIl1cIiksbj1cIlsgXCIuY29uY2F0KFwiXFx4YTBcIixcIlxcbl1cIikscj1uZXcgUmVnRXhwKFwiXCIuY29uY2F0KGEsXCIoXCIpLmNvbmNhdCh0LFwiKShcIikuY29uY2F0KG4sXCIpXCIpLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKHIsXCJcIi5jb25jYXQoXCJcXHhhMFwiKS5jb25jYXQoXCJcXHUyMDE0XCIsXCIkMlwiKSl9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGF0ZS9mcm9tSVNPXCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1cIigtfFxcXFwufFxcXFwvKVwiLGE9XCIoLXxcXFxcLylcIixuPW5ldyBSZWdFeHAoXCIoXnxcXFxcRCkoXFxcXGR7NH0pXCIrdCtcIihcXFxcZHsyfSlcIit0K1wiKFxcXFxkezJ9KShcXFxcRHwkKVwiLFwiZ2lcIikscj1uZXcgUmVnRXhwKFwiKF58XFxcXEQpKFxcXFxkezJ9KVwiK2ErXCIoXFxcXGR7Mn0pXCIrYStcIihcXFxcZHs0fSkoXFxcXER8JClcIixcImdpXCIpO3JldHVybiBlLnJlcGxhY2UobixcIiQxJDYuJDQuJDIkN1wiKS5yZXBsYWNlKHIsXCIkMSQ0LiQyLiQ2JDdcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGF0ZS93ZWVrZGF5XCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1mLmdldERhdGEoXCJydS9tb250aEdlbkNhc2VcIiksYT1mLmdldERhdGEoXCJydS93ZWVrZGF5XCIpLG49bmV3IFJlZ0V4cChcIihcXFxcZCkoIHxcXHhhMCkoXCIrdCtcIiksKCB8XFx4YTApKFwiK2ErXCIpXCIsXCJnaVwiKTtyZXR1cm4gZS5yZXBsYWNlKG4sZnVuY3Rpb24oKXt2YXIgZT1hcmd1bWVudHM7cmV0dXJuIGVbMV0rZVsyXStlWzNdLnRvTG93ZXJDYXNlKCkrXCIsXCIrZVs0XStlWzVdLnRvTG93ZXJDYXNlKCl9KX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9kYXNoL2NlbnR1cmllc1wiLGhhbmRsZXI6ZnVuY3Rpb24oZSx0KXt2YXIgYT1cIihcIitmLmdldERhdGEoXCJjb21tb24vZGFzaFwiKStcIilcIixuPW5ldyBSZWdFeHAoXCIoWHxJfFYpWyB8XFx4YTBdP1wiK2ErXCJbIHxcXHhhMF0/KFh8SXxWKVwiLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKG4sXCIkMVwiK3QuZGFzaCtcIiQzXCIpfSxzZXR0aW5nczp7ZGFzaDpcIlxcdTIwMTNcIn19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9kYXNoL2RheXNNb250aFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSx0KXt2YXIgYT1uZXcgUmVnRXhwKFwiKF58XFxcXHMpKFsxMjNdP1xcXFxkKShcIitmLmdldERhdGEoXCJjb21tb24vZGFzaFwiKStcIikoWzEyM10/XFxcXGQpWyBcXHhhMF0oXCIrZi5nZXREYXRhKFwicnUvbW9udGhHZW5DYXNlXCIpK1wiKVwiLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKGEsXCIkMSQyXCIrdC5kYXNoK1wiJDRcXHhhMCQ1XCIpfSxzZXR0aW5nczp7ZGFzaDpcIlxcdTIwMTNcIn19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9kYXNoL2RlXCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1uZXcgUmVnRXhwKFwiKFthLVxcdTA0NGZcXHUwNDUxXSspIFxcdTA0MzRcXHUwNDM1XCIrZi5nZXREYXRhKFwicnUvZGFzaEFmdGVyRGVcIiksXCJnXCIpO3JldHVybiBlLnJlcGxhY2UodCxcIiQxLVxcdTA0MzRcXHUwNDM1XCIpfSxkaXNhYmxlZDohMH0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L2Rhc2gvZGVjYWRlXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQpe3ZhciBhPW5ldyBSZWdFeHAoXCIoXnxcXFxccykoXFxcXGR7M318XFxcXGQpMChcIitmLmdldERhdGEoXCJjb21tb24vZGFzaFwiKStcIikoXFxcXGR7M318XFxcXGQpMCgtXFx1MDQzNVsgXFx4YTBdKSg/PVxcdTA0MzNcXFxcLj9bIFxceGEwXT9cXHUwNDMzfFxcdTA0MzNcXHUwNDNlXFx1MDQzNClcIixcImdcIik7cmV0dXJuIGUucmVwbGFjZShhLFwiJDEkMjBcIit0LmRhc2grXCIkNDAkNVwiKX0sc2V0dGluZ3M6e2Rhc2g6XCJcXHUyMDEzXCJ9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGFzaC9kaXJlY3RTcGVlY2hcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PWYuZ2V0RGF0YShcImNvbW1vbi9kYXNoXCIpLGE9bmV3IFJlZ0V4cCgnKFtcIlxceGJiXFx1MjAxOFxcdTIwMWMsXSlbIHxcXHhhMF0/KCcrdCtcIilbIHxcXHhhMF1cIixcImdcIiksbj1uZXcgUmVnRXhwKFwiKF58XCIrZi5fcHJpdmF0ZUxhYmVsK1wiKShcIit0K1wiKSggfFxceGEwKVwiLFwiZ21cIikscj1uZXcgUmVnRXhwKFwiKFsuXFx1MjAyNj8hXSlbIFxceGEwXShcIit0K1wiKVsgXFx4YTBdXCIsXCJnXCIpO3JldHVybiBlLnJlcGxhY2UoYSxcIiQxXFx4YTBcXHUyMDE0IFwiKS5yZXBsYWNlKG4sXCIkMVxcdTIwMTRcXHhhMFwiKS5yZXBsYWNlKHIsXCIkMSBcXHUyMDE0XFx4YTBcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGFzaC9penBvZFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChmLmdldERhdGEoXCJydS9kYXNoQmVmb3JlXCIpK1wiKFxcdTA0MTh8XFx1MDQzOClcXHUwNDM3IFxcdTA0M2ZcXHUwNDNlXFx1MDQzNFwiK2YuZ2V0RGF0YShcInJ1L2Rhc2hBZnRlclwiKSxcImdcIik7cmV0dXJuIGUucmVwbGFjZSh0LFwiJDEkMlxcdTA0MzctXFx1MDQzZlxcdTA0M2VcXHUwNDM0XCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L2Rhc2gvaXp6YVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChmLmdldERhdGEoXCJydS9kYXNoQmVmb3JlXCIpK1wiKFxcdTA0MTh8XFx1MDQzOClcXHUwNDM3IFxcdTA0MzdcXHUwNDMwXCIrZi5nZXREYXRhKFwicnUvZGFzaEFmdGVyXCIpLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKHQsXCIkMSQyXFx1MDQzNy1cXHUwNDM3XFx1MDQzMFwiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9kYXNoL2thXCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1uZXcgUmVnRXhwKFwiKFthLVxcdTA0NGZcXHUwNDUxXSspIFxcdTA0M2FcXHUwNDMwKFxcdTA0NDFcXHUwNDRjKT9cIitmLmdldERhdGEoXCJydS9kYXNoQWZ0ZXJcIiksXCJnXCIpO3JldHVybiBlLnJlcGxhY2UodCxcIiQxLVxcdTA0M2FcXHUwNDMwJDJcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGFzaC9rb2VcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PW5ldyBSZWdFeHAoZi5nZXREYXRhKFwicnUvZGFzaEJlZm9yZVwiKStcIihbXFx1MDQxYVxcdTA0M2FdXFx1MDQzZVtcXHUwNDM1XFx1MDQzOV0pXFxcXHMoW1xcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFdezMsfSlcIitmLmdldERhdGEoXCJydS9kYXNoQWZ0ZXJcIiksXCJnXCIpO3JldHVybiBlLnJlcGxhY2UodCxcIiQxJDItJDNcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGFzaC9tYWluXCIsaW5kZXg6XCItNVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9Zi5nZXREYXRhKFwiY29tbW9uL2Rhc2hcIiksYT1uZXcgUmVnRXhwKFwiKFsgXFx4YTBdKShcIit0K1wiKShbIFxceGEwXFxcXG5dKVwiLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKGEsXCJcXHhhMFxcdTIwMTQkM1wiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9kYXNoL21vbnRoXCIsaGFuZGxlcjpmdW5jdGlvbihlLHQpe3ZhciBhPVwiKFwiK2YuZ2V0RGF0YShcInJ1L21vbnRoXCIpK1wiKVwiLG49XCIoXCIrZi5nZXREYXRhKFwicnUvbW9udGhQcmVDYXNlXCIpK1wiKVwiLHI9Zi5nZXREYXRhKFwiY29tbW9uL2Rhc2hcIikscz1uZXcgUmVnRXhwKGErXCIgPyhcIityK1wiKSA/XCIrYSxcImdpXCIpLGk9bmV3IFJlZ0V4cChuK1wiID8oXCIrcitcIikgP1wiK24sXCJnaVwiKSx1PVwiJDFcIit0LmRhc2grXCIkM1wiO3JldHVybiBlLnJlcGxhY2Uocyx1KS5yZXBsYWNlKGksdSl9LHNldHRpbmdzOntkYXNoOlwiXFx1MjAxM1wifX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L2Rhc2gvc3VybmFtZVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChcIihbXFx1MDQxMC1cXHUwNDJmXFx1MDQwMV1bXFx1MDQzMC1cXHUwNDRmXFx1MDQ1MV0rKVxcXFxzLShbXFx1MDQzMC1cXHUwNDRmXFx1MDQ1MV17MSwzfSkoPyFbXlxcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFdfCQpXCIsXCJnXCIpO3JldHVybiBlLnJlcGxhY2UodCxcIiQxXFx4YTBcXHUyMDE0JDJcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGFzaC90YWtpXCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1uZXcgUmVnRXhwKFwiKFxcdTA0MzJcXHUwNDM1XFx1MDQ0MFxcdTA0M2RcXHUwNDNlfFxcdTA0MzRcXHUwNDNlXFx1MDQzMlxcdTA0M2VcXHUwNDNiXFx1MDQ0Y1xcdTA0M2RcXHUwNDNlfFxcdTA0M2VcXHUwNDNmXFx1MDQ0ZlxcdTA0NDJcXHUwNDRjfFxcdTA0M2ZcXHUwNDQwXFx1MDQ0ZlxcdTA0M2NcXHUwNDNlfFxcdTA0NDJcXHUwNDMwXFx1MDQzYXxcXHUwNDMyXFx1MDQ0MVtcXHUwNDM1XFx1MDQ1MV18XFx1MDQzNFxcdTA0MzVcXHUwNDM5XFx1MDQ0MVxcdTA0NDJcXHUwNDMyXFx1MDQzOFxcdTA0NDJcXHUwNDM1XFx1MDQzYlxcdTA0NGNcXHUwNDNkXFx1MDQzZXxcXHUwNDNkXFx1MDQzNVxcdTA0NDNcXHUwNDM2XFx1MDQzNVxcdTA0M2JcXHUwNDM4KVxcXFxzKFxcdTA0NDJcXHUwNDMwXFx1MDQzYVxcdTA0MzgpXCIrZi5nZXREYXRhKFwicnUvZGFzaEFmdGVyXCIpLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKHQsXCIkMS0kMlwiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9kYXNoL3RpbWVcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCl7dmFyIGE9bmV3IFJlZ0V4cChmLmdldERhdGEoXCJydS9kYXNoQmVmb3JlXCIpK1wiKFxcXFxkP1xcXFxkOlswLTVdXFxcXGQpXCIrZi5nZXREYXRhKFwiY29tbW9uL2Rhc2hcIikrXCIoXFxcXGQ/XFxcXGQ6WzAtNV1cXFxcZClcIitmLmdldERhdGEoXCJydS9kYXNoQWZ0ZXJcIiksXCJnXCIpO3JldHVybiBlLnJlcGxhY2UoYSxcIiQxJDJcIit0LmRhc2grXCIkM1wiKX0sc2V0dGluZ3M6e2Rhc2g6XCJcXHUyMDEzXCJ9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvZGFzaC90b1wiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChcIihcIitbXCJcXHUwNDNlXFx1MDQ0MlxcdTA0M2FcXHUwNDQzXFx1MDQzNFxcdTA0MzBcIixcIlxcdTA0M2FcXHUwNDQzXFx1MDQzNFxcdTA0MzBcIixcIlxcdTA0MzNcXHUwNDM0XFx1MDQzNVwiLFwiXFx1MDQzYVxcdTA0M2VcXHUwNDMzXFx1MDQzNFxcdTA0MzBcIixcIlxcdTA0MzdcXHUwNDMwXFx1MDQ0N1xcdTA0MzVcXHUwNDNjXCIsXCJcXHUwNDNmXFx1MDQzZVxcdTA0NDdcXHUwNDM1XFx1MDQzY1xcdTA0NDNcIixcIlxcdTA0M2FcXHUwNDMwXFx1MDQzYVwiLFwiXFx1MDQzYVxcdTA0MzBcXHUwNDNhXFx1MDQzZVtcXHUwNDM1XFx1MDQzOVxcdTA0M2NdXCIsXCJcXHUwNDNhXFx1MDQzMFxcdTA0M2FcXHUwNDMwXFx1MDQ0ZlwiLFwiXFx1MDQzYVxcdTA0MzBcXHUwNDNhXFx1MDQzOFtcXHUwNDM1XFx1MDQzY1xcdTA0NDVdXCIsXCJcXHUwNDNhXFx1MDQzMFxcdTA0M2FcXHUwNDM4XFx1MDQzY1xcdTA0MzhcIixcIlxcdTA0M2FcXHUwNDMwXFx1MDQzYVxcdTA0NDNcXHUwNDRlXCIsXCJcXHUwNDQ3XFx1MDQ0MlxcdTA0M2VcIixcIlxcdTA0NDdcXHUwNDM1XFx1MDQzM1xcdTA0M2VcIixcIlxcdTA0NDdcXHUwNDM1W1xcdTA0MzlcXHUwNDNjXVwiLFwiXFx1MDQ0N1xcdTA0NGNcXHUwNDM4XFx1MDQzYz9cIixcIlxcdTA0M2FcXHUwNDQyXFx1MDQzZVwiLFwiXFx1MDQzYVxcdTA0M2VcXHUwNDMzXFx1MDQzZVwiLFwiXFx1MDQzYVxcdTA0M2VcXHUwNDNjXFx1MDQ0M1wiLFwiXFx1MDQzYVxcdTA0MzVcXHUwNDNjXCJdLmpvaW4oXCJ8XCIpK1wiKSggfCAtfC0gKShcXHUwNDQyXFx1MDQzZXxcXHUwNDNiXFx1MDQzOFxcdTA0MzFcXHUwNDNlfFxcdTA0M2RcXHUwNDM4XFx1MDQzMVxcdTA0NDNcXHUwNDM0XFx1MDQ0YylcIitmLmdldERhdGEoXCJydS9kYXNoQWZ0ZXJcIiksXCJnaVwiKTtyZXR1cm4gZS5yZXBsYWNlKHQsXCIkMS0kM1wiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9kYXNoL3dlZWtkYXlcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCl7dmFyIGE9XCIoXCIrZi5nZXREYXRhKFwicnUvd2Vla2RheVwiKStcIilcIixuPW5ldyBSZWdFeHAoYStcIiA/KFwiK2YuZ2V0RGF0YShcImNvbW1vbi9kYXNoXCIpK1wiKSA/XCIrYSxcImdpXCIpO3JldHVybiBlLnJlcGxhY2UobixcIiQxXCIrdC5kYXNoK1wiJDNcIil9LHNldHRpbmdzOntkYXNoOlwiXFx1MjAxM1wifX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L2Rhc2gveWVhcnNcIixoYW5kbGVyOmZ1bmN0aW9uKGUscyl7dmFyIHQ9Zi5nZXREYXRhKFwiY29tbW9uL2Rhc2hcIiksYT1uZXcgUmVnRXhwKFwiKFxcXFxEfF4pKFxcXFxkezR9KVsgXFx4YTBdPyhcIit0K1wiKVsgXFx4YTBdPyhcXFxcZHs0fSkoPz1bIFxceGEwXT9cXHUwNDMzKVwiLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKGEsZnVuY3Rpb24oZSx0LGEsbixyKXtyZXR1cm4gcGFyc2VJbnQoYSwxMCk8cGFyc2VJbnQociwxMCk/dCthK3MuZGFzaCtyOmV9KX0sc2V0dGluZ3M6e2Rhc2g6XCJcXHUyMDEzXCJ9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvbW9uZXkvY3VycmVuY3lcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PVwiKFskXFx1MjBhY1xceGE1XFx1MDRiMFxceGEzXFx1MjBhNFxcdTIwYmRdKVwiLGE9bmV3IFJlZ0V4cChcIihefFtcXFxcRF17Mn0pXCIrdCtcIiA/KFtcXFxcZC4sXSsoWyBcXHhhMFxcdTIwMDlcXHUyMDJmXVxcXFxkezN9KSopKFsgXFx4YTBcXHUyMDA5XFx1MjAyZl0/KFxcdTA0NDJcXHUwNDRiXFx1MDQ0MVxcXFwufFxcdTA0M2NcXHUwNDNiXFx1MDQzZHxcXHUwNDNjXFx1MDQzYlxcdTA0NDBcXHUwNDM0fFxcdTA0NDJcXHUwNDQwXFx1MDQzYlxcdTA0M2QpKT9cIixcImdtXCIpLG49bmV3IFJlZ0V4cChcIihefFtcXFxcRF0pKFtcXFxcZC4sXSspID9cIit0LFwiZ21cIik7cmV0dXJuIGUucmVwbGFjZShhLGZ1bmN0aW9uKGUsdCxhLG4scixzLGkpe3JldHVybiB0K24rKGk/XCJcXHhhMFwiK2k6XCJcIikrXCJcXHhhMFwiK2F9KS5yZXBsYWNlKG4sXCIkMSQyXFx4YTAkM1wiKX0sZGlzYWJsZWQ6ITB9KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9tb25leS9ydWJsZVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9XCIkMVxceGEwXFx1MjBiZFwiLGE9XCIoXFxcXGQrKSggfFxceGEwKT8oXFx1MDQ0MHxcXHUwNDQwXFx1MDQ0M1xcdTA0MzEpXFxcXC5cIixuPW5ldyBSZWdFeHAoXCJeXCIrYStcIiRcIixcImdcIikscj1uZXcgUmVnRXhwKGErXCIoPz1bIT8sOjtdKVwiLFwiZ1wiKSxzPW5ldyBSZWdFeHAoYStcIig/PVxcXFxzK1tBLVxcdTA0MmZcXHUwNDAxXSlcIixcImdcIik7cmV0dXJuIGUucmVwbGFjZShuLHQpLnJlcGxhY2Uocix0KS5yZXBsYWNlKHMsdCtcIi5cIil9LGRpc2FibGVkOiEwfSksZi5hZGRSdWxlKHtuYW1lOlwicnUvbnVtYmVyL2NvbW1hXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8oXnxcXHMpKFxcZCspXFwuKFxcZCtbXFx1MDBBMFxcdTIwMDlcXHUyMDJGIF0qP1slXFx1MjAzMFxceGIwXFx4ZDd4XSkvZ2ltLFwiJDEkMiwkM1wiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9udW1iZXIvb3JkaW5hbHNcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1uZXcgUmVnRXhwKFwiKFxcXFxkWyVcXHUyMDMwXT8pLShcXHUwNDRiXFx1MDQzOXxcXHUwNDNlXFx1MDQzOXxcXHUwNDMwXFx1MDQ0ZnxcXHUwNDNlXFx1MDQzNXxcXHUwNDRiXFx1MDQzNXxcXHUwNDRiXFx1MDQzY3xcXHUwNDNlXFx1MDQzY3xcXHUwNDRiXFx1MDQ0NXxcXHUwNDNlXFx1MDQzM1xcdTA0M2V8XFx1MDQzZVxcdTA0M2NcXHUwNDQzfFxcdTA0NGJcXHUwNDNjXFx1MDQzOCkoPyFbXCIrYS5nZXREYXRhKFwiY2hhclwiKStcIl0pXCIsXCJnXCIpO3JldHVybiBlLnJlcGxhY2UobixmdW5jdGlvbihlLHQsYSl7cmV0dXJuIHQrXCItXCIre1wiXFx1MDQzZVxcdTA0MzlcIjpcIlxcdTA0MzlcIixcIlxcdTA0NGJcXHUwNDM5XCI6XCJcXHUwNDM5XCIsXCJcXHUwNDMwXFx1MDQ0ZlwiOlwiXFx1MDQ0ZlwiLFwiXFx1MDQzZVxcdTA0MzVcIjpcIlxcdTA0MzVcIixcIlxcdTA0NGJcXHUwNDM1XCI6XCJcXHUwNDM1XCIsXCJcXHUwNDRiXFx1MDQzY1wiOlwiXFx1MDQzY1wiLFwiXFx1MDQzZVxcdTA0M2NcIjpcIlxcdTA0M2NcIixcIlxcdTA0NGJcXHUwNDQ1XCI6XCJcXHUwNDQ1XCIsXCJcXHUwNDNlXFx1MDQzM1xcdTA0M2VcIjpcIlxcdTA0MzNcXHUwNDNlXCIsXCJcXHUwNDNlXFx1MDQzY1xcdTA0NDNcIjpcIlxcdTA0M2NcXHUwNDQzXCIsXCJcXHUwNDRiXFx1MDQzY1xcdTA0MzhcIjpcIlxcdTA0M2NcXHUwNDM4XCJ9W2FdfSl9fSksZD1bXCJ0eXBvZ3JhZi1vYS1sYnJhY2tldFwiLFwidHlwb2dyYWYtb2Etbi1sYnJhY2tldFwiLFwidHlwb2dyYWYtb2Etc3AtbGJyYWNrZXRcIl0scD1cInJ1L29wdGFsaWduL2JyYWNrZXRcIixmLmFkZFJ1bGUoe25hbWU6cCxoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyggfFxcdTAwQTApXFwoL2csJzxzcGFuIGNsYXNzPVwidHlwb2dyYWYtb2Etc3AtbGJyYWNrZXRcIj4kMTwvc3Bhbj48c3BhbiBjbGFzcz1cInR5cG9ncmFmLW9hLWxicmFja2V0XCI+KDwvc3Bhbj4nKS5yZXBsYWNlKC9eXFwoL2dtLCc8c3BhbiBjbGFzcz1cInR5cG9ncmFmLW9hLW4tbGJyYWNrZXRcIj4oPC9zcGFuPicpfSxkaXNhYmxlZDohMCxodG1sQXR0cnM6ITF9KS5hZGRJbm5lclJ1bGUoe25hbWU6cCxxdWV1ZTpcInN0YXJ0XCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZi5fcmVtb3ZlT3B0QWxpZ25UYWdzKGUsZCl9fSkuYWRkSW5uZXJSdWxlKHtuYW1lOnAscXVldWU6XCJlbmRcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBmLl9yZW1vdmVPcHRBbGlnblRhZ3NGcm9tVGl0bGUoZSxkKX19KSxnPVtcInR5cG9ncmFmLW9hLWNvbW1hXCIsXCJ0eXBvZ3JhZi1vYS1jb21tYS1zcFwiXSxoPVwicnUvb3B0YWxpZ24vY29tbWFcIixmLmFkZFJ1bGUoe25hbWU6aCxoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1uZXcgUmVnRXhwKFwiKFtcIithLmdldERhdGEoXCJjaGFyXCIpK1wiXFxcXGRcXHUwMzAxXSspLCBcIixcImdpXCIpO3JldHVybiBlLnJlcGxhY2UobiwnJDE8c3BhbiBjbGFzcz1cInR5cG9ncmFmLW9hLWNvbW1hXCI+LDwvc3Bhbj48c3BhbiBjbGFzcz1cInR5cG9ncmFmLW9hLWNvbW1hLXNwXCI+IDwvc3Bhbj4nKX0sZGlzYWJsZWQ6ITAsaHRtbEF0dHJzOiExfSkuYWRkSW5uZXJSdWxlKHtuYW1lOmgscXVldWU6XCJzdGFydFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGYuX3JlbW92ZU9wdEFsaWduVGFncyhlLGcpfX0pLmFkZElubmVyUnVsZSh7bmFtZTpoLHF1ZXVlOlwiZW5kXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZi5fcmVtb3ZlT3B0QWxpZ25UYWdzRnJvbVRpdGxlKGUsZyl9fSksZi5fcmVtb3ZlT3B0QWxpZ25UYWdzPWZ1bmN0aW9uKGUsdCl7dmFyIGE9bmV3IFJlZ0V4cCgnPHNwYW4gY2xhc3M9XCIoJyt0LmpvaW4oXCJ8XCIpKycpXCI+KFteXSo/KTwvc3Bhbj4nLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKGEsXCIkMlwiKX0sZi5fcmVtb3ZlT3B0QWxpZ25UYWdzRnJvbVRpdGxlPWZ1bmN0aW9uKGUsdCl7cmV0dXJuIGUucmVwbGFjZSgvPHRpdGxlPlteXSo/PFxcL3RpdGxlPi9pLGZ1bmN0aW9uKGUpe3JldHVybiBmLl9yZW1vdmVPcHRBbGlnblRhZ3MoZSx0KX0pfSxtPVtcInR5cG9ncmFmLW9hLWxxdW90ZVwiLFwidHlwb2dyYWYtb2Etbi1scXVvdGVcIixcInR5cG9ncmFmLW9hLXNwLWxxdW90ZVwiXSx2PVwicnUvb3B0YWxpZ24vcXVvdGVcIixmLmFkZFJ1bGUoe25hbWU6dixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PXRoaXMuZ2V0U2V0dGluZyhcImNvbW1vbi9wdW5jdHVhdGlvbi9xdW90ZVwiLFwicnVcIiksYT1cIihbXCIrdC5sZWZ0WzBdKyh0LmxlZnRbMV18fFwiXCIpK1wiXSlcIixuPW5ldyBSZWdFeHAoXCIoXnxcXG5cXG58XCIrZi5fcHJpdmF0ZUxhYmVsK1wiKShcIithK1wiKVwiLFwiZ1wiKSxyPW5ldyBSZWdFeHAoXCIoW15cXG5cIitmLl9wcml2YXRlTGFiZWwrXCJdKShbIFxceGEwXFxuXSkoXCIrYStcIilcIixcImdpXCIpO3JldHVybiBlLnJlcGxhY2UobiwnJDE8c3BhbiBjbGFzcz1cInR5cG9ncmFmLW9hLW4tbHF1b3RlXCI+JDI8L3NwYW4+JykucmVwbGFjZShyLCckMTxzcGFuIGNsYXNzPVwidHlwb2dyYWYtb2Etc3AtbHF1b3RlXCI+JDI8L3NwYW4+PHNwYW4gY2xhc3M9XCJ0eXBvZ3JhZi1vYS1scXVvdGVcIj4kMzwvc3Bhbj4nKX0sZGlzYWJsZWQ6ITAsaHRtbEF0dHJzOiExfSkuYWRkSW5uZXJSdWxlKHtuYW1lOnYscXVldWU6XCJzdGFydFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGYuX3JlbW92ZU9wdEFsaWduVGFncyhlLG0pfX0pLmFkZElubmVyUnVsZSh7bmFtZTp2LHF1ZXVlOlwiZW5kXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZi5fcmVtb3ZlT3B0QWxpZ25UYWdzRnJvbVRpdGxlKGUsbSl9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvbmJzcC9hYmJyXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtmdW5jdGlvbiB0KGUsdCxhLG4pe3JldHVyblwiXFx1MDQzNFxcdTA0MzRcIj09PWEmJlwiXFx1MDQzY1xcdTA0M2NcIj09PW4/ZTotMTxbXCJcXHUwNDQwXFx1MDQ0NFwiLFwiXFx1MDQ0MFxcdTA0NDNcIixcIlxcdTA0NDBcXHUwNDQzXFx1MDQ0MVwiLFwiXFx1MDQzZVxcdTA0NDBcXHUwNDMzXCIsXCJcXHUwNDQzXFx1MDQzYVxcdTA0NDBcIixcIlxcdTA0MzFcXHUwNDMzXCIsXCJcXHUwNDQxXFx1MDQ0MFxcdTA0MzFcIl0uaW5kZXhPZihuKT9lOnQrYStcIi5cXHhhMFwiK24rXCIuXCJ9dmFyIGE9bmV3IFJlZ0V4cChcIihefFxcXFxzfFwiK2YuX3ByaXZhdGVMYWJlbCtcIikoW1xcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFdezEsM30pXFxcXC4gPyhbXFx1MDQzMC1cXHUwNDRmXFx1MDQ1MV17MSwzfSlcXFxcLlwiLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKGEsdCkucmVwbGFjZShhLHQpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AvYWRkclwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvKFxcc3xeKShcXHUwNDM0XFx1MDQzZVxcdTA0M2N8XFx1MDQzNFxcLnxcXHUwNDNhXFx1MDQzMlxcLnxcXHUwNDNmXFx1MDQzZVxcdTA0MzRcXC58XFx1MDQzZi1cXHUwNDM0KSAqKFxcZCspL2dpLFwiJDEkMlxceGEwJDNcIikucmVwbGFjZSgvKFxcc3xeKShcXHUwNDNjXFx1MDQzYVxcdTA0NDAtXFx1MDQzZHxcXHUwNDNjXFx1MDQzYS1cXHUwNDNkfFxcdTA0M2NcXHUwNDNhXFx1MDQ0MFxcLnxcXHUwNDNjXFx1MDQzYVxcdTA0NDBcXHUwNDNkKVxccy9naSxcIiQxJDJcXHhhMFwiKS5yZXBsYWNlKC8oXFxzfF4pKFxcdTA0NGRcXHUwNDQyXFwuKSAqKC0/XFxkKykvZ2ksXCIkMSQyXFx4YTAkM1wiKS5yZXBsYWNlKC8oXFxzfF4pKFxcZCspICtcXHUwNDRkXFx1MDQ0MlxcdTA0MzBcXHUwNDM2KFteXFx1MDQzMC1cXHUwNDRmXFx1MDQ1MV18JCkvZ2ksXCIkMSQyXFx4YTBcXHUwNDRkXFx1MDQ0MlxcdTA0MzBcXHUwNDM2JDNcIikucmVwbGFjZSgvKFxcc3xeKVxcdTA0M2JcXHUwNDM4XFx1MDQ0MlxcdTA0MzVcXHUwNDQwXFxzKFtcXHUwNDEwLVxcdTA0MmZdfCQpL2dpLFwiJDFcXHUwNDNiXFx1MDQzOFxcdTA0NDJcXHUwNDM1XFx1MDQ0MFxceGEwJDJcIikucmVwbGFjZSgvKFxcc3xeKShcXHUwNDNlXFx1MDQzMVxcdTA0M2J8XFx1MDQzYVxcdTA0NDB8XFx1MDQ0MVxcdTA0NDJ8XFx1MDQzZlxcdTA0M2VcXHUwNDQxfFxcdTA0NDF8XFx1MDQzNHxcXHUwNDQzXFx1MDQzYnxcXHUwNDNmXFx1MDQzNVxcdTA0NDB8XFx1MDQzZlxcdTA0NDB8XFx1MDQzZlxcdTA0NDAtXFx1MDQ0MnxcXHUwNDNmXFx1MDQ0MFxcdTA0M2VcXHUwNDQxXFx1MDQzZnxcXHUwNDNmXFx1MDQzYnxcXHUwNDMxXFx1MDQ0M1xcdTA0M2J8XFx1MDQzMS1cXHUwNDQwfFxcdTA0M2RcXHUwNDMwXFx1MDQzMXxcXHUwNDQ4fFxcdTA0NDJcXHUwNDQzXFx1MDQzZnxcXHUwNDNlXFx1MDQ0NHxcXHUwNDNhXFx1MDQzZVxcdTA0M2NcXHUwNDNkP3xcXHUwNDQzXFx1MDQ0N3xcXHUwNDMyXFx1MDQzYnxcXHUwNDMyXFx1MDQzYlxcdTA0MzBcXHUwNDM0fFxcdTA0NDFcXHUwNDQyXFx1MDQ0MHxcXHUwNDNhXFx1MDQzZVxcdTA0NDApXFwuICooW1xcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFhLXpcXGRdKykvZ2ksXCIkMSQyLlxceGEwJDNcIikucmVwbGFjZSgvKFxcRFsgXFx1MDBBMF18XilcXHUwNDMzXFwuID8oW1xcdTA0MTAtXFx1MDQyZlxcdTA0MDFdKS9nbSxcIiQxXFx1MDQzMy5cXHhhMCQyXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AvYWZ0ZXJOdW1iZXJTaWduXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC9cXHUyMTE2WyBcXHUwMEEwXFx1MjAwOV0/KFxcZHxcXHUwNDNmXFwvXFx1MDQzZikvZyxcIlxcdTIxMTZcXHUyMDJmJDFcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvbmJzcC9iZWZvcmVQYXJ0aWNsZVwiLGluZGV4OlwiKzVcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PVwiKFxcdTA0M2JcXHUwNDM4fFxcdTA0M2JcXHUwNDRjfFxcdTA0MzZcXHUwNDM1fFxcdTA0MzZ8XFx1MDQzMVxcdTA0NGJ8XFx1MDQzMSlcIixhPW5ldyBSZWdFeHAoXCIoW1xcdTA0MTAtXFx1MDQyZlxcdTA0MDFcXHUwNDMwLVxcdTA0NGZcXHUwNDUxXSkgXCIrdCsnKD89Wyw7Oj8hXCJcXHUyMDE4XFx1MjAxY1xceGJiXSknLFwiZ1wiKSxuPW5ldyBSZWdFeHAoXCIoW1xcdTA0MTAtXFx1MDQyZlxcdTA0MDFcXHUwNDMwLVxcdTA0NGZcXHUwNDUxXSlbIFxceGEwXVwiK3QrXCJbIFxceGEwXVwiLFwiZ1wiKTtyZXR1cm4gZS5yZXBsYWNlKGEsXCIkMVxceGEwJDJcIikucmVwbGFjZShuLFwiJDFcXHhhMCQyIFwiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9uYnNwL2NlbnR1cmllc1wiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9Zi5nZXREYXRhKFwiY29tbW9uL2Rhc2hcIiksYT1cIihefFxcXFxzKShbVklYXSspXCIsbj0nKD89Wyw7Oj8hXCJcXHUyMDE4XFx1MjAxY1xceGJiXXwkKScscj1uZXcgUmVnRXhwKGErXCJbIFxceGEwXT9cXHUwNDMyXFxcXC4/XCIrbixcImdtXCIpLHM9bmV3IFJlZ0V4cChhK1wiKFwiK3QrXCIpKFtWSVhdKylbIFxceGEwXT9cXHUwNDMyXFxcXC4/KFsgXFx4YTBdP1xcdTA0MzJcXFxcLj8pP1wiK24sXCJnbVwiKTtyZXR1cm4gZS5yZXBsYWNlKHIsXCIkMSQyXFx4YTBcXHUwNDMyLlwiKS5yZXBsYWNlKHMsXCIkMSQyJDMkNFxceGEwXFx1MDQzMlxcdTA0MzIuXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AvZGF5TW9udGhcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PW5ldyBSZWdFeHAoXCIoXFxcXGR7MSwyfSkgKFwiK2YuZ2V0RGF0YShcInJ1L3Nob3J0TW9udGhcIikrXCIpXCIsXCJnaVwiKTtyZXR1cm4gZS5yZXBsYWNlKHQsXCIkMVxceGEwJDJcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvbmJzcC9ncm91cE51bWJlcnNcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PW5ldyBSZWdFeHAoXCIoXiA/fFxcXFxEIHxcIi5jb25jYXQoZi5fcHJpdmF0ZUxhYmVsLFwiKShcXFxcZHsxLDN9KFsgXFx4YTBcXHUyMDJmXFx1MjAwOV1cXFxcZHszfSkrKSg/ISA/W1xcXFxkLV0pXCIpLFwiZ21cIik7cmV0dXJuIGUucmVwbGFjZSh0LGZ1bmN0aW9uKGUsdCxhKXtyZXR1cm4gdCthLnJlcGxhY2UoL1xccy9nLFwiXFx1MjAyZlwiKX0pfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AvaW5pdGlhbHNcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PWYuZ2V0RGF0YShcInJ1L3F1b3RlXCIpLGE9bmV3IFJlZ0V4cChcIihefFtcXHhhMFxcdTIwMmYgXCIrdC5sZWZ0K2YuX3ByaXZhdGVMYWJlbCsnXCJdKShbXFx1MDQxMC1cXHUwNDJmXFx1MDQwMV0pXFxcXC5bXFx4YTBcXHUyMDJmIF0/KFtcXHUwNDEwLVxcdTA0MmZcXHUwNDAxXSlcXFxcLltcXHhhMFxcdTIwMmYgXT8oW1xcdTA0MTAtXFx1MDQyZlxcdTA0MDFdW1xcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFdKykoPz1bXFxcXHMuLDs6PyFcIicrdC5yaWdodCtcIl18JClcIixcImdtXCIpO3JldHVybiBlLnJlcGxhY2UoYSxcIiQxJDIuXFx4YTAkMy5cXHhhMCQ0XCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AvbVwiLGluZGV4OlwiKzVcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PWYuX3ByaXZhdGVMYWJlbCxhPW5ldyBSZWdFeHAoXCIoXnxbXFxcXHMsLlwiK3QrXCJdKShcXFxcZCspWyBcXHhhMF0/KFxcdTA0M2NcXHUwNDNjP3xcXHUwNDQxXFx1MDQzY3xcXHUwNDNhXFx1MDQzY3xcXHUwNDM0XFx1MDQzY3xcXHUwNDMzXFx1MDQzY3xtbT98a218Y218ZG0pKFsyM1xceGIyXFx4YjNdKT8oW1xcXFxzLiE/LDtcIit0K1wiXXwkKVwiLFwiZ21cIik7cmV0dXJuIGUucmVwbGFjZShhLGZ1bmN0aW9uKGUsdCxhLG4scixzKXtyZXR1cm4gdCthK1wiXFx4YTBcIituK3syOlwiXFx4YjJcIixcIlxceGIyXCI6XCJcXHhiMlwiLDM6XCJcXHhiM1wiLFwiXFx4YjNcIjpcIlxceGIzXCIsXCJcIjpcIlwifVtyfHxcIlwiXSsoXCJcXHhhMFwiPT09cz9cIiBcIjpzKX0pfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AvbWxuXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8oXFxkKSA/KFxcdTA0NDJcXHUwNDRiXFx1MDQ0MXxcXHUwNDNjXFx1MDQzYlxcdTA0M2R8XFx1MDQzY1xcdTA0M2JcXHUwNDQwXFx1MDQzNHxcXHUwNDQyXFx1MDQ0MFxcdTA0M2JcXHUwNDNkKShcXC58XFxzfCQpL2dpLFwiJDFcXHhhMCQyJDNcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvbmJzcC9vb29cIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyhefFteYS1cXHUwNDRmXFx1MDQ1MUEtXFx1MDQyZlxcdTA0MDFdKShcXHUwNDFlXFx1MDQxZVxcdTA0MWV8XFx1MDQxZVxcdTA0MTBcXHUwNDFlfFxcdTA0MTdcXHUwNDEwXFx1MDQxZXxcXHUwNDFkXFx1MDQxOFxcdTA0MTh8XFx1MDQxZlxcdTA0MTFcXHUwNDFlXFx1MDQyZVxcdTA0MWIpIC9nLFwiJDEkMlxceGEwXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AvcGFnZVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChcIihefFspXFxcXHNcIitmLl9wcml2YXRlTGFiZWwrXCJdKShcXHUwNDQxXFx1MDQ0MlxcdTA0NDB8XFx1MDQzM1xcdTA0M2J8XFx1MDQ0MFxcdTA0MzhcXHUwNDQxfFxcdTA0MzhcXHUwNDNiXFx1MDQzYj98XFx1MDQ0MVxcdTA0NDJ8XFx1MDQzZnxjKVxcXFwuICooXFxcXGQrKShbXFxcXHMuLD8hOzpdfCQpXCIsXCJnaW1cIik7cmV0dXJuIGUucmVwbGFjZSh0LFwiJDEkMi5cXHhhMCQzJDRcIil9fSksZi5hZGRSdWxlKHtuYW1lOlwicnUvbmJzcC9wc1wiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChcIihefFxcXFxzfFwiK2YuX3ByaXZhdGVMYWJlbCtcIilbcFxcdTA0MzddXFxcXC5bIFxceGEwXT8oW3BcXHUwNDM3XVxcXFwuWyBcXHhhMF0/KT9bc1xcdTA0NGJdXFxcXC46PyBcIixcImdpbVwiKTtyZXR1cm4gZS5yZXBsYWNlKHQsZnVuY3Rpb24oZSx0LGEpe3JldHVybiB0KyhhP1wiUC5cXHhhMFAuXFx4YTBTLiBcIjpcIlAuXFx4YTBTLiBcIil9KX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9uYnNwL3J1YmxlS29wZWtcIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoLyhcXGQpID8oPz0oXFx1MDQ0MFxcdTA0NDNcXHUwNDMxfFxcdTA0M2FcXHUwNDNlXFx1MDQzZilcXC4pL2csXCIkMVxceGEwXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3Avc2VlXCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1uZXcgUmVnRXhwKFwiKF58XFxcXHN8XCIrZi5fcHJpdmF0ZUxhYmVsK1wifFxcXFwoKShcXHUwNDQxXFx1MDQzY3xcXHUwNDM4XFx1MDQzYylcXFxcLlsgXFx4YTBdPyhbXFx1MDQzMC1cXHUwNDRmXFx1MDQ1MTAtOWEtel0rKShbXFxcXHMuLD8hXXwkKVwiLFwiZ2lcIik7cmV0dXJuIGUucmVwbGFjZSh0LGZ1bmN0aW9uKGUsdCxhLG4scil7cmV0dXJuKFwiXFx4YTBcIj09PXQ/XCIgXCI6dCkrYStcIi5cXHhhMFwiK24rcn0pfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AveWVhclwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvKF58XFxEKShcXGR7NH0pID9cXHUwNDMzKFsgLDsuXFxuXXwkKS9nLFwiJDEkMlxceGEwXFx1MDQzMyQzXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L25ic3AveWVhcnNcIixpbmRleDpcIis1XCIsaGFuZGxlcjpmdW5jdGlvbihlKXt2YXIgdD1mLmdldERhdGEoXCJjb21tb24vZGFzaFwiKSxhPW5ldyBSZWdFeHAoXCIoXnxcXFxcRCkoXFxcXGR7NH0pKFwiK3QrJykoXFxcXGR7NH0pWyBcXHhhMF0/XFx1MDQzM1xcXFwuPyhbIFxceGEwXT9cXHUwNDMzXFxcXC4pPyg/PVssOzo/IVwiXFx1MjAxOFxcdTIwMWNcXHhiYlxcXFxzXXwkKScsXCJnbVwiKTtyZXR1cm4gZS5yZXBsYWNlKGEsXCIkMSQyJDMkNFxceGEwXFx1MDQzM1xcdTA0MzMuXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L290aGVyL2FjY2VudFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7cmV0dXJuIGUucmVwbGFjZSgvKFtcXHUwNDMwLVxcdTA0NGZcXHUwNDUxXSkoW1xcdTA0MTBcXHUwNDE1XFx1MDQwMVxcdTA0MThcXHUwNDFlXFx1MDQyM1xcdTA0MmJcXHUwNDJkXFx1MDQyZVxcdTA0MmZdKShbXlxcdTA0MTAtXFx1MDQyZlxcdTA0MDFcXHddfCQpL2csZnVuY3Rpb24oZSx0LGEsbil7cmV0dXJuIHQrYS50b0xvd2VyQ2FzZSgpK1wiXFx1MDMwMVwiK259KX0sZGlzYWJsZWQ6ITB9KSxSPVtdLFs0MTYyLDQxNjMzMiw4NTEyLDg1MTExMSw0NzIyLDQ3MjUsMzkxMzc5LDg0NDIsNDczMiw0MTUyLDQxNTQ0NTEsNDE1NDQ1OSw0MTU0NDU1LDQxNTQ0NTEzLDgxNDIsODMzMiw4NjEyLDg2MjIsMzUyNSw4MTIsODM0Miw4MTUyLDM4MTIsNDg2MiwzNDIyLDM0MjYzMyw4MTEyLDkxNDIsODQ1MiwzNDMyLDM0MzQsMzQzNSw0ODEyLDg0MzIsODQzOSwzODIyLDQ4NzIsMzQxMiwzNTExLDM1MTIsMzAyMiw0MTEyLDQ4NTIsNDg1NSwzODUyLDM4NTQsODE4Miw4MTgsOTAsMzQ3Miw0NzQxLDQ3NjQsNDgzMiw0OTIyLDgxNzIsODIwMiw4NzIyLDQ5MzIsNDkzLDM5NTIsMzk1MSwzOTUzLDQxMTUzMyw0ODQyLDM4NDIsMzg0Myw4MjEyLDQ5NDIsXCIzOTEzMS0zOTE3OVwiLFwiMzkxOTAtMzkxOTlcIiwzOTEsNDcxMiw0NzQyLDgzNjIsNDk1LDQ5OSw0OTY2LDQ5NjQsNDk2Nyw0OTgsODMxMiw4MzEzLDM4MzIsMzgzNjEyLDM1MzIsODQxMiw0MjMyLDQyMzM3MCw0MjM2MzAsODYzMiw4NjQyLDg0ODIsNDI0Miw4NjcyLDg2NTIsNDc1Miw0ODIyLDQ4MjUwMiw0ODI2MzAwLDM0NTIsODQyMiw0MjEyLDM0NjYsMzQ2Miw4NzEyLDgzNTIsXCI5MDEtOTM0XCIsXCI5MzYtOTM5XCIsXCI5NTAtOTUzXCIsOTU4LFwiOTYwLTk2OVwiLFwiOTc3LTk4OVwiLFwiOTkxLTk5N1wiLDk5OV0uZm9yRWFjaChmdW5jdGlvbihlKXtpZihcInN0cmluZ1wiPT10eXBlb2YgZSlmb3IodmFyIHQ9ZS5zcGxpdChcIi1cIiksYT0rdFswXTthPD0rdFsxXTthKyspUi5wdXNoKGEpO2Vsc2UgUi5wdXNoKGUpfSksZi5hZGRSdWxlKHtuYW1lOlwicnUvb3RoZXIvcGhvbmUtbnVtYmVyXCIsbGl2ZTohMSxoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PWYuX3ByaXZhdGVMYWJlbCxhPW5ldyBSZWdFeHAoXCIoXnwsfCB8XCIrdCtcIikoXFxcXCs3W1xcXFxkXFxcXChcXFxcKSBcXHhhMC1dezEwLDE4fSkoPz0sfDt8XCIrdCtcInwkKVwiLFwiZ21cIik7cmV0dXJuIGUucmVwbGFjZShhLGZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1FKGEpO3JldHVybiAxMj09PW4ubGVuZ3RoP3QreChuKTplfSkucmVwbGFjZSgvKF58W15cXHUwNDMwLVxcdTA0NGZcXHUwNDUxXSkoW1xcdTI2MGVcXHUyNjBmXFx1MjcwNlxcdWQ4M2RcXHVkY2UwXFx1ZDgzZFxcdWRjZGVcXHVkODNkXFx1ZGNmMV18XFx1MDQ0MlxcLnxcXHUwNDQyXFx1MDQzNVxcdTA0M2JcXC58XFx1MDQ0NFxcLnxcXHUwNDNjXFx1MDQzZVxcdTA0MzFcXC58XFx1MDQ0NFxcdTA0MzBcXHUwNDNhXFx1MDQ0MXxcXHUwNDQxXFx1MDQzZVxcdTA0NDJcXHUwNDNlXFx1MDQzMlxcdTA0NGJcXHUwNDM5fFxcdTA0M2NcXHUwNDNlXFx1MDQzMVxcdTA0MzhcXHUwNDNiXFx1MDQ0Y1xcdTA0M2RcXHUwNDRiXFx1MDQzOXxcXHUwNDQyXFx1MDQzNVxcdTA0M2JcXHUwNDM1XFx1MDQ0NFxcdTA0M2VcXHUwNDNkKSg6P1xccyo/KShbK1xcZChdW1xcZCBcXHUwMEEwXFwtKCldezMsfVxcZCkvZ2ksZnVuY3Rpb24oZSx0LGEsbixyKXt2YXIgcz1FKHIpO3JldHVybiA1PD1zLmxlbmd0aD90K2Erbit4KHMpOmV9KX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9wdW5jdHVhdGlvbi9hbm9cIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3ZhciB0PW5ldyBSZWdFeHAoXCIoW14hPyw6O1xcXFwtXFx1MjAxMlxcdTIwMTNcXHUyMDE0XFxcXHNdKShcXFxccyspKFxcdTA0MzB8XFx1MDQzZFxcdTA0M2UpKD89IHxcXHhhMHxcXFxcbilcIixcImdcIik7cmV0dXJuIGUucmVwbGFjZSh0LFwiJDEsJDIkM1wiKX0scXVldWU6XCJoaWRlLXNhZmUtdGFncy1odG1sXCJ9KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9wdW5jdHVhdGlvbi9leGNsYW1hdGlvblwiLGxpdmU6ITEsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8oXnxbXiFdKSF7Mn0oJHxbXiFdKS9nbSxcIiQxISQyXCIpLnJlcGxhY2UoLyhefFteIV0pIXs0fSgkfFteIV0pL2dtLFwiJDEhISEkMlwiKX19KSxmLmFkZFJ1bGUoe25hbWU6XCJydS9wdW5jdHVhdGlvbi9leGNsYW1hdGlvblF1ZXN0aW9uXCIsaW5kZXg6XCIrNVwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChcIihefFteIV0pIVxcXFw/KFteP118JClcIixcImdcIik7cmV0dXJuIGUucmVwbGFjZSh0LFwiJDE/ISQyXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L3B1bmN0dWF0aW9uL2hlbGxpcFF1ZXN0aW9uXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8oXnxbXi5dKShcXC5cXC5cXC58XFx1MjAyNiksL2csXCIkMVxcdTIwMjZcIikucmVwbGFjZSgvKCF8XFw/KShcXC5cXC5cXC58XFx1MjAyNikoPz1bXi5dfCQpL2csXCIkMS4uXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L3NwYWNlL2FmdGVySGVsbGlwXCIsaGFuZGxlcjpmdW5jdGlvbihlKXtyZXR1cm4gZS5yZXBsYWNlKC8oW1xcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFdKShcXC5cXC5cXC58XFx1MjAyNikoW1xcdTA0MTAtXFx1MDQyZlxcdTA0MDFdKS9nLFwiJDEkMiAkM1wiKS5yZXBsYWNlKC8oWz8hXVxcLlxcLikoW1xcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFhLXpdKS9naSxcIiQxICQyXCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L3NwYWNlL3llYXJcIixoYW5kbGVyOmZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1uZXcgUmVnRXhwKFwiKF58IHxcXHhhMCkoXFxcXGR7Myw0fSkoXFx1MDQzM1xcdTA0M2VcXHUwNDM0KFtcXHUwNDMwXFx1MDQ0M1xcdTA0MzVdfFxcdTA0M2VcXHUwNDNjKT8pKFteXCIrYS5nZXREYXRhKFwiY2hhclwiKStcIl18JClcIixcImdcIik7cmV0dXJuIGUucmVwbGFjZShuLFwiJDEkMiAkMyQ1XCIpfX0pLGYuYWRkUnVsZSh7bmFtZTpcInJ1L3N5bWJvbHMvTk5cIixoYW5kbGVyOmZ1bmN0aW9uKGUpe3JldHVybiBlLnJlcGxhY2UoL1xcdTIxMTZcXHUyMTE2L2csXCJcXHUyMTE2XCIpfX0pLCQ9e0E6XCJcXHUwNDEwXCIsYTpcIlxcdTA0MzBcIixCOlwiXFx1MDQxMlwiLEU6XCJcXHUwNDE1XCIsZTpcIlxcdTA0MzVcIixLOlwiXFx1MDQxYVwiLE06XCJcXHUwNDFjXCIsSDpcIlxcdTA0MWRcIixPOlwiXFx1MDQxZVwiLG86XCJcXHUwNDNlXCIsUDpcIlxcdTA0MjBcIixwOlwiXFx1MDQ0MFwiLEM6XCJcXHUwNDIxXCIsYzpcIlxcdTA0NDFcIixUOlwiXFx1MDQyMlwiLHk6XCJcXHUwNDQzXCIsWDpcIlxcdTA0MjVcIix4OlwiXFx1MDQ0NVwifSxiPU9iamVjdC5rZXlzKCQpLmpvaW4oXCJcIiksZi5hZGRSdWxlKHtuYW1lOlwicnUvdHlwby9zd2l0Y2hpbmdLZXlib2FyZExheW91dFwiLGhhbmRsZXI6ZnVuY3Rpb24oZSl7dmFyIHQ9bmV3IFJlZ0V4cChcIihbXCIrYitcIl17MSwzfSkoPz1bXFx1MDQxMC1cXHUwNDJmXFx1MDQwMVxcdTA0MzAtXFx1MDQ0ZlxcdTA0NTFdKz8pXCIsXCJnXCIpO3JldHVybiBlLnJlcGxhY2UodCxmdW5jdGlvbihlLHQpe2Zvcih2YXIgYT1cIlwiLG49MDtuPHQubGVuZ3RoO24rKylhKz0kW3Rbbl1dO3JldHVybiBhfSl9fSksZn0pOyIsImltcG9ydCAqIGFzIFR5cG9ncmFmIGZyb20gJy4uL25vZGVfbW9kdWxlcy90eXBvZ3JhZi9kaXN0L3R5cG9ncmFmLm1pbi5qcyc7XG5jb25zdCB0cCA9IG5ldyBUeXBvZ3JhZih7bG9jYWxlOiBbJ3J1JywgJ2VuLVVTJ119KTtcblxuY29uc3QgRGlmZiA9IHJlcXVpcmUoJ3RleHQtZGlmZicpO1xuY29uc3QgZGlmZiA9IG5ldyBEaWZmKCk7XG5cbmZ1bmN0aW9uIGhhdmVNaXhlZFN0eWxlKG9iaiwgc3RhcnQgPSAwLCBlbmQpIHtcbiAgICBpZiAoZW5kID09PSB1bmRlZmluZWQpIHsgXG4gICAgICAgIGVuZCA9IG9iai5jaGFyYWN0ZXJzLmxlbmd0aDtcbiAgICB9XG4gICAgcmV0dXJuIG9iai5nZXRSYW5nZUZvbnROYW1lKHN0YXJ0LCBlbmQpID09PSBmaWdtYS5taXhlZCB8fFxuICAgICAgICAgICBvYmouZ2V0UmFuZ2VGb250U2l6ZShzdGFydCwgZW5kKSA9PT0gZmlnbWEubWl4ZWQgfHwgXG4gICAgICAgICAgIG9iai5nZXRSYW5nZVRleHRDYXNlKHN0YXJ0LCBlbmQpID09PSBmaWdtYS5taXhlZCB8fCBcbiAgICAgICAgICAgb2JqLmdldFJhbmdlVGV4dERlY29yYXRpb24oc3RhcnQsIGVuZCkgPT09IGZpZ21hLm1peGVkIHx8IFxuICAgICAgICAgICBvYmouZ2V0UmFuZ2VMZXR0ZXJTcGFjaW5nKHN0YXJ0LCBlbmQpID09PSBmaWdtYS5taXhlZCB8fCBcbiAgICAgICAgICAgb2JqLmdldFJhbmdlTGluZUhlaWdodChzdGFydCwgZW5kKSA9PT0gZmlnbWEubWl4ZWQgfHwgXG4gICAgICAgICAgIG9iai5nZXRSYW5nZUZpbGxzKHN0YXJ0LCBlbmQpID09PSBmaWdtYS5taXhlZCB8fFxuICAgICAgICAgICBvYmouZ2V0UmFuZ2VUZXh0U3R5bGVJZChzdGFydCwgZW5kKSA9PT0gZmlnbWEubWl4ZWQgfHxcbiAgICAgICAgICAgb2JqLmdldFJhbmdlRmlsbFN0eWxlSWQoc3RhcnQsIGVuZCkgPT09IGZpZ21hLm1peGVkO1xufVxuXG5mdW5jdGlvbiBnZXRUZXh0bm9kZVN0eWxlKG9iaiwgc3RhcnQgPSAwLCBlbmQpIHtcbiAgICBpZiAoZW5kID09PSB1bmRlZmluZWQpIHsgXG4gICAgICAgIGVuZCA9IG9iai5jaGFyYWN0ZXJzLmxlbmd0aDtcbiAgICB9XG4gICAgbGV0IHN0eWxlID0ge307XG5cbiAgICBzdHlsZS5Gb250TmFtZSA9IG9iai5nZXRSYW5nZUZvbnROYW1lKHN0YXJ0LCBlbmQpO1xuICAgIHN0eWxlLkZvbnRTaXplID0gb2JqLmdldFJhbmdlRm9udFNpemUoc3RhcnQsIGVuZCk7XG4gICAgc3R5bGUuVGV4dENhc2UgPSBvYmouZ2V0UmFuZ2VUZXh0Q2FzZShzdGFydCwgZW5kKTtcbiAgICBzdHlsZS5UZXh0RGVjb3JhdGlvbiA9IG9iai5nZXRSYW5nZVRleHREZWNvcmF0aW9uKHN0YXJ0LCBlbmQpO1xuICAgIHN0eWxlLkxldHRlclNwYWNpbmcgPSBvYmouZ2V0UmFuZ2VMZXR0ZXJTcGFjaW5nKHN0YXJ0LCBlbmQpO1xuICAgIHN0eWxlLkxpbmVIZWlnaHQgPSBvYmouZ2V0UmFuZ2VMaW5lSGVpZ2h0KHN0YXJ0LCBlbmQpO1xuICAgIHN0eWxlLkZpbGxzID0gb2JqLmdldFJhbmdlRmlsbHMoc3RhcnQsIGVuZCk7XG4gICAgc3R5bGUuVGV4dFN0eWxlSWQgPSBvYmouZ2V0UmFuZ2VUZXh0U3R5bGVJZChzdGFydCwgZW5kKTtcbiAgICBzdHlsZS5GaWxsU3R5bGVJZCA9IG9iai5nZXRSYW5nZUZpbGxTdHlsZUlkKHN0YXJ0LCBlbmQpO1xuXG4gICAgcmV0dXJuIHN0eWxlOyAgICBcbn1cblxuZnVuY3Rpb24gZmluZFN0eWxlQm9yZGVyKG9iaiwgc3RhcnQsIGxlZnQsIHJpZ2h0KSB7XG4gICAgaWYgKGhhdmVNaXhlZFN0eWxlKG9iaiwgc3RhcnQsIHJpZ2h0KSkge1xuICAgICAgICBsZXQgbWlkID0gTWF0aC5mbG9vcigobGVmdCArIHJpZ2h0KS8yKTtcbiAgICAgICAgaWYgKGhhdmVNaXhlZFN0eWxlKG9iaiwgc3RhcnQsIG1pZCkgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICBpZiAoaGF2ZU1peGVkU3R5bGUob2JqLCBzdGFydCwgbWlkICsxKSB8fCBtaWQgPT09IHJpZ2h0KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1pZDtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZpbmRTdHlsZUJvcmRlcihvYmosIHN0YXJ0LCBtaWQrMSwgcmlnaHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIGZpbmRTdHlsZUJvcmRlcihvYmosIHN0YXJ0LCBsZWZ0LCBtaWQpO1xuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHJpZ2h0O1xuICAgIH1cbn1cblxuZnVuY3Rpb24gc2F2ZVRleHRub2RlU3R5bGUob2JqKSB7XG4gICAgbGV0IGVuZCA9IG9iai5jaGFyYWN0ZXJzLmxlbmd0aDtcbiAgICBsZXQgc3RhcnQgPSAwO1xuICAgIGxldCBzdHlsZSA9IFtdO1xuXG4gICAgd2hpbGUgKHN0YXJ0IDwgZW5kKSB7XG4gICAgICAgIGxldCBib3JkZXIgPSBmaW5kU3R5bGVCb3JkZXIob2JqLCBzdGFydCwgc3RhcnQsIGVuZCk7XG4gICAgICAgIHN0eWxlLnB1c2goe1xuICAgICAgICAgICAgc3RhcnQ6IHN0YXJ0LFxuICAgICAgICAgICAgZW5kOiBib3JkZXIsXG4gICAgICAgICAgICBzdHlsZTogZ2V0VGV4dG5vZGVTdHlsZShvYmosIHN0YXJ0LCBib3JkZXIpXG4gICAgICAgIH0pO1xuICAgICAgICBzdGFydCA9IGJvcmRlcjtcbiAgICB9XG4gICAgcmV0dXJuIHN0eWxlO1xufVxuXG5mdW5jdGlvbiBhcHBseVRleHRub2RlU3R5bGVzKG9iaiwgc3R5bGVzKSB7XG4gICAgc3R5bGVzLmZvckVhY2goYXN5bmMgZnVuY3Rpb24oc3QpIHtcbiAgICAgICAgLy8g0KTQuNCz0LzQsCDRgtGA0LXQsdGD0LXRgiwg0YfRgtC+0LHRiyDQv9C10YDQtdC0INC70Y7QsdGL0LzQuCDQvtC/0LXRgNCw0YbQuNGP0LzQuCDRgSDRgtC10LrRgdGC0L7QvCwg0L/RgNC+0LjRgdGF0L7QtNC40LvQsCDQsNGB0LjQvdGF0YDQvtC90L3QsNGPINC30LDQs9GA0YPQt9C60LAg0YjRgNC40YTRgtCwIOKAlCBodHRwczovL3d3dy5maWdtYS5jb20vcGx1Z2luLWRvY3MvYXBpL1RleHROb2RlL1xuICAgICAgICBhd2FpdCBmaWdtYS5sb2FkRm9udEFzeW5jKHN0LnN0eWxlLkZvbnROYW1lKTtcbiAgICAgICAgb2JqLnNldFJhbmdlRm9udE5hbWUoc3Quc3RhcnQsIHN0LmVuZCwgc3Quc3R5bGUuRm9udE5hbWUpO1xuICAgICAgICBvYmouc2V0UmFuZ2VGb250U2l6ZShzdC5zdGFydCwgc3QuZW5kLCBzdC5zdHlsZS5Gb250U2l6ZSk7XG4gICAgICAgIG9iai5zZXRSYW5nZVRleHRDYXNlKHN0LnN0YXJ0LCBzdC5lbmQsIHN0LnN0eWxlLlRleHRDYXNlKTtcbiAgICAgICAgb2JqLnNldFJhbmdlVGV4dERlY29yYXRpb24oc3Quc3RhcnQsIHN0LmVuZCwgc3Quc3R5bGUuVGV4dERlY29yYXRpb24pO1xuICAgICAgICBvYmouc2V0UmFuZ2VMZXR0ZXJTcGFjaW5nKHN0LnN0YXJ0LCBzdC5lbmQsIHN0LnN0eWxlLkxldHRlclNwYWNpbmcpO1xuICAgICAgICBvYmouc2V0UmFuZ2VMaW5lSGVpZ2h0KHN0LnN0YXJ0LCBzdC5lbmQsIHN0LnN0eWxlLkxpbmVIZWlnaHQpO1xuICAgICAgICBvYmouc2V0UmFuZ2VGaWxscyhzdC5zdGFydCwgc3QuZW5kLCBzdC5zdHlsZS5GaWxscyk7XG4gICAgICAgIG9iai5zZXRSYW5nZVRleHRTdHlsZUlkKHN0LnN0YXJ0LCBzdC5lbmQsIHN0LnN0eWxlLlRleHRTdHlsZUlkKTtcbiAgICAgICAgb2JqLnNldFJhbmdlRmlsbFN0eWxlSWQoc3Quc3RhcnQsIHN0LmVuZCwgc3Quc3R5bGUuRmlsbFN0eWxlSWQpO1xuICAgIH0pXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGxvYWRGb250c0Zyb21TdHlsZXMoc3R5bGVzKSB7XG4gICAgZm9yIChjb25zdCBzdCBvZiBzdHlsZXMpIHtcbiAgICAgICAgYXdhaXQgZmlnbWEubG9hZEZvbnRBc3luYyhzdC5zdHlsZS5Gb250TmFtZSk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBhZGp1c3RTdHlsZXNQb3NpdGlvbnMoc3R5bGVzLCB0ZXh0RGlmZikge1xuICAgIGNvbnNvbGUubG9nKHRleHREaWZmKVxuICAgIGxldCBwb3NpdGlvbiA9IDA7XG4gICAgbGV0IGNvcnJlY3Rpb24gPSAwO1xuICAgIGxldCBhZGp1c3RlZCA9IFtdO1xuXG4gICAgZm9yIChsZXQgc3Qgb2Ygc3R5bGVzKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdwb3MgJywgcG9zaXRpb24sICdjb3InLCBjb3JyZWN0aW9uLCAnc3QnLCBzdC5zdGFydCwgJ2VuJywgc3QuZW5kKVxuICAgICAgICBzdC5zdGFydCA9IHN0LnN0YXJ0ICsgY29ycmVjdGlvbjtcbiAgICAgICAgd2hpbGUgKHBvc2l0aW9uIDw9IHN0LmVuZCkge1xuICAgICAgICAgICAgbGV0IGQgPSB0ZXh0RGlmZi5zaGlmdCgpO1xuICAgICAgICAgICAgY29uc29sZS5sb2coZClcbiAgICAgICAgICAgIGlmIChkID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvcnJlY3Rpb24gPSBjb3JyZWN0aW9uICsgZFswXSpkWzFdLmxlbmd0aDtcbiAgICAgICAgICAgIHBvc2l0aW9uID0gcG9zaXRpb24gKyAoZFswXSA9PSAwID8gZFsxXS5sZW5ndGggOiBkWzBdKmRbMV0ubGVuZ3RoKTtcbiAgICAgICAgfVxuICAgICAgICBzdC5lbmQgPSBzdC5lbmQgKyBjb3JyZWN0aW9uO1xuICAgICAgICBjb25zb2xlLmxvZygnTmV3IHN0Jywgc3Quc3RhcnQsICdlbicsIHN0LmVuZClcbiAgICAgICAgYWRqdXN0ZWQucHVzaChzdCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGFkanVzdGVkO1xufVxuXG5cbmFzeW5jIGZ1bmN0aW9uIHR5cG9ncmFmVGV4dChvYmopIHtcbiAgICBpZiAob2JqLmhhc01pc3NpbmdGb250ICE9IHRydWUpIHtcbiAgICAgICAgbGV0IHN0eWxlcyA9IHNhdmVUZXh0bm9kZVN0eWxlKG9iaik7XG4gICAgICAgIGF3YWl0IGxvYWRGb250c0Zyb21TdHlsZXMoc3R5bGVzKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRleHQgPSBvYmouY2hhcmFjdGVycztcbiAgICAgICAgICAgIGNvbnN0IG5ld1RleHQgPSB0cC5leGVjdXRlKHRleHQpO1xuICAgICAgICAgICAgbGV0IHRleHREaWZmID0gZGlmZi5tYWluKHRleHQsIG5ld1RleHQpO1xuICAgICAgICAgICAgY29uc3QgbmV3U3R5bGVzID0gYWRqdXN0U3R5bGVzUG9zaXRpb25zKHN0eWxlcywgdGV4dERpZmYpO1xuICAgICAgICAgICAgY29uc29sZS5sb2cobmV3U3R5bGVzKVxuXG4gICAgICAgICAgICBvYmouY2hhcmFjdGVycyA9IG5ld1RleHQ7XG4gICAgICAgICAgICBhcHBseVRleHRub2RlU3R5bGVzKG9iaiwgbmV3U3R5bGVzKTtcbiAgICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgZmlnbWEuY2xvc2VQbHVnaW4oXCJUZXh0IHdpdGggbWlzc2luZyBmb250cyBjYW4ndCBiZSB0eXBvZ3JhZmVkXCIpO1xuICAgIH1cbn1cblxuY29uc3Qgc2VsZWN0aW9uID0gZmlnbWEuY3VycmVudFBhZ2Uuc2VsZWN0aW9uLmZpbHRlcihsYXllciA9PiBsYXllci50eXBlID09PSAnVEVYVCcpO1xuaWYgKHNlbGVjdGlvbi5sZW5ndGggPT09IDApIHtcbiAgICBmaWdtYS5jbG9zZVBsdWdpbihcIlNlbGVjdCBhdCBsZWFzdCAxIHRleHQgbGF5ZXJcIik7XG59IGVsc2Uge1xuICAgIGNvbnN0IHByb21pc2VzID0gc2VsZWN0aW9uLm1hcCh0eXBvZ3JhZlRleHQpO1xuICAgIFByb21pc2UuYWxsKHByb21pc2VzKS50aGVuKHJlc29sdmUgPT4ge1xuICAgICAgICBmaWdtYS5jbG9zZVBsdWdpbigpO1xuICAgIH0pO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==